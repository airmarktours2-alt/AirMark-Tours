export type CustomerReview = {
	id: string;
	quote: string;
	name: string;
	country: string;
};

/** Customer comments supplied for the Testimonials page. Wording kept as given. */
export const customerReviews: CustomerReview[] = [
	{
		id: 'ms-lei',
		name: 'Ms. Lei',
		country: 'Philippines',
		quote:
			'Grateful to Airmark Tour for handling Skeen’s Seoul incentive trip last Jan 26–31, 2026. Managing 135 pax with such care, coordination and dedication… truly an exceptional service. Thank you for making this experience smooth, memorable and worry-free.',
	},
	{
		id: 'ms-miriam',
		name: 'Ms. Miriam',
		country: 'Philippines',
		quote:
			"Very much satisfied although there maybe some concern with one itinerary for the specific garden to view and experiences the blooming cherry blossom. But all in all it's been an amazing travel experience in SOKOR. In all we appreciated the itineraries and Mr. Sunny the tour guide is very energetic, informative and flexible to every concerns of each member of the team. Gamsahmida! We look forward to more bucket list of travels with Airmark 🥰🥰🥰",
	},
	{
		id: 'mr-sojordane',
		name: 'Mr. Sojordane',
		country: 'Philippines',
		quote:
			'Gusto ko yung guide and driver parehas naman sila ok good job naman sila. Ok din naman yung tour value for money din po. Had better trip thistime than lasttime dto sa Korea.',
	},
	{
		id: 'ms-ailyne',
		name: 'Ms. Ailyne',
		country: 'Philippines',
		quote: 'First time to join a group tour and it’s really convenient.',
	},
	{
		id: 'ms-allysa',
		name: 'Ms. Allysa',
		country: 'Philippines',
		quote:
			'Very accommodating and the overall package is worth it. Thank you! We had a great time experiencing South Korea tour / travel.',
	},
	{
		id: 'mr-angelito',
		name: 'Mr. Angelito',
		country: 'Philippines',
		quote:
			'I have a great Experience as a first time traveler, hoping to always have a Sonia or be like as a tour guide. She is great on what she is doing.',
	},
	{
		id: 'mr-adrian',
		name: 'Mr. Adrian',
		country: 'Philippines',
		quote: 'The tour is very good experience.',
	},
	{
		id: 'mr-mrs-mendigo',
		name: 'Mr. and Mrs. Mendigo',
		country: 'Philippines',
		quote:
			"I'm 100% satisfied just make the service consistent and convenient thank you so much Airmark and Jake the tour guide.",
	},
	{
		id: 'ms-kim',
		name: 'Ms. Kim',
		country: 'Philippines',
		quote: 'Overall experience was great!',
	},
	{
		id: 'ms-sheila',
		name: 'Ms. Sheila',
		country: 'Philippines',
		quote:
			'Super! Thank you so much ms jhay💗 Ang bait ni brian. Kaya walang hassle ang trip namin, ang food ang sarap. Di tinipid. Super sulit.',
	},
];
