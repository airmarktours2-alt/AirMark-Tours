export type Destination = {
	name: string;
	code: string;
	region: string;
	price: string;
	image: string;
};

const BASE = 'https://media.base44.com/images/public/6a34dbb2a3effa96085abb37';

export const destinations: Destination[] = [
	{ name: 'South Korea', code: 'ICN', region: 'Korea', price: '₱ 34,199', image: 'https://images.hostinger.com/d2d19f87-fbd9-4f48-ba0f-ac425b9b8044.png' },
	{ name: 'Japan', code: 'HND', region: 'Japan', price: '₱ 90,000', image: 'https://images.hostinger.com/ee62a0a9-f4c6-4f18-ba83-d257ae31b13e.png' },
	{ name: 'China', code: 'PEK', region: 'China', price: '₱ 29,950', image: 'https://images.hostinger.com/ff15c007-b0db-469a-81ed-378a7302793a.png' },
	{ name: 'Vietnam', code: 'HAN', region: 'Vietnam', price: '₱ 37,888', image: 'https://images.hostinger.com/7b7110de-c33a-4cad-b904-c43d0f8733ba.png' },
	{ name: 'Europe', code: 'CDG', region: 'Europe', price: '₱ 161,500', image: 'https://images.hostinger.com/836573f5-87b4-43ea-a327-8bc33908764c.png' },
	{ name: 'Philippines', code: 'MNL', region: 'Philippines', price: '₱ 32,599', image: 'https://images.hostinger.com/0154b4cc-bfec-4077-8eaa-825c8dd1859b.png' },
	{ name: 'Taiwan', code: 'TPE', region: 'Taiwan', price: '₱ 30,000', image: 'https://images.hostinger.com/7dc6a5eb-4f17-457f-ab02-1e0809324712.png' },
	{ name: 'Hong Kong', code: 'HKG', region: 'Hong Kong', price: '₱ 35,000', image: 'https://images.hostinger.com/0355dcbd-ee88-4a2e-8802-8999d3b91746.png' },
	{ name: 'Cruise', code: 'SEA', region: 'Ocean Voyage', price: '₱ 36,000', image: 'https://images.hostinger.com/74fe0509-4633-48a7-8988-8cd0a0f370a6.png' },
];
