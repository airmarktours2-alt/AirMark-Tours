export type HongKongDay = {
	day: string;
	title: string;
	stops: string[];
};

export type HongKongContact = { label: string; value: string; href?: string };

export type HongKongPackage = {
	id: string;
	title: string;
	tagline: string;
	region: string;
	days: string;
	year: string;
	price: string;
	priceNote: string;
	summary: string;
	airline?: string;
	hotel?: string;
	flyer: string;
	dates: string[];
	inclusions: string[];
	exclusions: string[];
	contacts: HongKongContact[];
	itinerary: HongKongDay[];
};

const shopFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/8a80ad96daba67837fae6a8e3fd026a6.png';
const macauFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/cdb453b8717351ddf10950b491c2c3d5.png';

export const hongKongHero = 'https://images.hostinger.com/0355dcbd-ee88-4a2e-8802-8999d3b91746.png';

const desk: HongKongContact[] = [
	{ label: 'Email', value: 'jhayram.airmark@gmail.com', href: 'mailto:jhayram.airmark@gmail.com' },
	{ label: 'Mobile', value: '0956 8518 768', href: 'tel:09568518768' },
];

export const hongKongPackages: HongKongPackage[] = [
	{
		id: 'shop-and-play',
		title: 'Hong Kong Shop & Play',
		tagline: 'Endless experiences. One unforgettable journey.',
		region: 'Victoria Harbour · Disneyland · Lantau · Ocean Park',
		days: '4 days & 3 nights',
		year: '2026',
		price: '$488',
		priceNote: 'For as low as · per pax · quad rate on the earliest dates',
		summary:
			'A 4-day, 3-night Cebu Pacific departure from Manila, staying at the 5-star Nina Hotel Tsuen Wan West. The flyer prices it from $488 per person on quad sharing for the May and June dates, with higher twin, triple, and later-season rates printed beside each departure.',
		airline: 'Cebu Pacific',
		hotel: '5-star Nina Hotel Tsuen Wan West',
		flyer: shopFlyer,
		dates: [
			'May 06–09 · $528 twin / $508 trp / $488 quad',
			'May 15–18 · $528 twin / $508 trp / $488 quad',
			'May 21–24 · $528 twin / $508 trp / $488 quad',
			'Jun 10–13 · $528 twin / $508 trp / $488 quad',
			'Aug 20–23 · $558 twin / $528 trp / $508 quad',
			'Sep 11–14 · $558 twin / $528 trp / $508 quad',
			'Oct 28–31 · $588 twin / $558 trp / $538 quad',
			'Nov 28 – Dec 01 · $588 twin / $558 trp / $538 quad',
			'Dec 22–25 · $648 twin / $608 trp / $588 quad',
			'Dec 23–26 · $648 twin / $608 trp / $588 quad',
			'Dec 25–28 · $648 twin / $608 trp / $588 quad',
			'Dec 26–29 · $648 twin / $608 trp / $588 quad',
			'Dec 27–30 · $648 twin / $608 trp / $588 quad',
		],
		inclusions: [
			'Roundtrip airfare via Cebu Pacific',
			'7kg hand carry',
			'3 nights hotel accommodation',
			'Private coach',
			'Hotel breakfast',
			'Guided walking tour',
		],
		exclusions: ['PH travel tax', 'Tipping', 'Travel insurance', 'Check-in baggage'],
		contacts: desk,
		itinerary: [
			{
				day: '1',
				title: 'Arrival in HK',
				stops: [
					'Departure from Manila',
					'Arrival in Hong Kong',
					'Check-in at the hotel',
					'1.5-hour English guided walking tour with street food tasting',
				],
			},
			{
				day: '2',
				title: 'Free time',
				stops: [
					'Breakfast',
					'Free time, or join an optional tour such as Hong Kong Disneyland or Lantau',
				],
			},
			{
				day: '3',
				title: 'Free time',
				stops: [
					'Breakfast',
					'Free time, or join an optional tour such as Ocean Park or a Macau day tour',
				],
			},
			{
				day: '4',
				title: 'Departure',
				stops: [
					'Breakfast',
					'Hong Kong city tour',
					'Top of Victoria Park, Nan Lian Garden, and Chi Lin Nunnery',
					'Souvenir shop and Wan Chai Harbourfront',
					'Transfer to the airport for departure to Manila',
				],
			},
		],
	},
	{
		id: 'hong-kong-macau',
		title: 'Hong Kong & Macau',
		tagline: 'Hong Kong and Macau, 2026',
		region: 'West Kowloon · Victoria Harbour · Macau',
		days: '4 days as printed',
		year: '2026',
		price: '$555',
		priceNote: 'For as low as · per person · quad rate',
		summary:
			'A 2026 Cebu Pacific departure covering Hong Kong and a Macau city tour on day 4. The flyer prices it from $555 per person on quad sharing ($595 twin / $575 triple), with a +$50 note on Oct 29 – Dec 02 and a separate Dec 25–28 rate of $695 twin / $675 triple / $655 quad, marked +$100.',
		airline: 'Cebu Pacific',
		flyer: macauFlyer,
		dates: [
			'$595 twin / $575 trp / $555 quad · Jul 23–26, Aug 28–31, Sep 17–20',
			'Oct 29 – Dec 02 · +$50, as printed',
			'$695 twin / $675 trp / $655 quad · Dec 25–28 · +$100',
		],
		inclusions: [
			'Roundtrip airfare via Cebu Pacific',
			'7kg hand carry',
			'3 nights hotel accommodation',
			'Private coach',
			'Guided city tours',
			'Hotel breakfast',
		],
		exclusions: ['PH travel tax', 'Tipping', 'Travel insurance', 'Check-in baggage'],
		contacts: desk,
		itinerary: [
			{
				day: '1',
				title: 'Arrival in Hong Kong',
				stops: [
					'Departure from Manila',
					'Arrival in Hong Kong',
					'Half-day city tour',
					'West Kowloon Cultural District',
					'Photo stop at M+ Museum, Hong Kong Palace Museum, and Victoria Harbour',
					'Jewelry shop and souvenir shop',
					'Avenue of Stars',
					'Clock Tower',
				],
			},
			{
				day: '2',
				title: 'Free time',
				stops: ['Breakfast', 'Free time, or join an optional tour'],
			},
			{
				day: '3',
				title: 'Free time',
				stops: ['Breakfast', 'Free time, or join an optional tour'],
			},
			{
				day: '4',
				title: 'Macau and departure',
				stops: [
					'Proceed to Macau',
					'Macau city tour',
					"Ruins of St. Paul's, Senado Square, Na Tcha Temple, and A-Ma Temple",
					'Photo stop at Nam Van Lake',
					'Souvenir shop',
					'Casino at Venetian Macau',
					'Transfer to the airport',
					'Departure to Manila',
				],
			},
		],
	},
];
