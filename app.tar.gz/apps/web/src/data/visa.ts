export type VisaDestination = {
	code: string;
	name: string;
	price: string;
	image: string;
	alt: string;
	href?: string;
};

export type VisaFaqItem = {
	question: string;
	answer: string;
};

export const visaHero =
	'https://images.hostinger.com/1ad1275f-76e1-4898-9818-7437cf9b3bf5.png';

export const visaDestinations: VisaDestination[] = [
	{
		code: 'ICN',
		name: 'Korea Visa',
		price: '₱1,900',
		image: 'https://images.hostinger.com/b7cad738-17ee-40d9-ac39-e47a1c3f36e8.png',
		alt: 'Gyeongbokgung Palace courtyard in Seoul',
		href: '/visa/korea',
	},
	{
		code: 'PEK',
		name: 'China Visa',
		price: '₱4,400',
		image: 'https://images.hostinger.com/5ed4835b-5059-4177-b3f1-acbe06c69210.png',
		alt: 'The Great Wall of China across green mountains',
		href: '/visa/china',
	},
	{
		code: 'DXB',
		name: 'Dubai Visa',
		price: '₱7,900',
		image: 'https://images.hostinger.com/c32c2826-c7ac-4331-9bbb-225a29e1d59d.png',
		alt: 'Dubai skyline and Burj Khalifa at sunset',
		href: '/visa/dubai',
	},
	{
		code: 'JFK',
		name: 'US Visa',
		price: '₱18,500',
		image: 'https://images.hostinger.com/c5ae850c-7479-4355-9303-fbc5be9528e8.png',
		alt: 'Statue of Liberty with the New York skyline',
		href: '/visa/us',
	},
	{
		code: 'HND',
		name: 'Japan Visa',
		price: '₱2,500',
		image: 'https://images.hostinger.com/13afbd94-2afa-4457-bc01-24f1bf5ba8ab.png',
		alt: 'Mount Fuji with cherry blossoms in the foreground',
		href: '/visa/japan',
	},
	{
		code: 'SCH',
		name: 'Schengen Visa',
		price: '₱11,500',
		image: 'https://images.hostinger.com/08fccc67-2395-4166-bd3b-807779bb1a5c.png',
		alt: 'Pont Alexandre III in Paris at dusk',
		href: '/visa/schengen',
	},
];

export const visaFaqs: VisaFaqItem[] = [
	{
		question: 'Which countries can Airmark help me get a visa for?',
		answer:
			'This page lists visa assistance for Korea, China, Dubai, the US, Japan, and Schengen. Whether Airmark can assist, and whether you are eligible, depends on the specific destination and your circumstances. Confirm current service availability with Airmark before you start an application.',
	},
	{
		question: 'What documents do I need to prepare?',
		answer:
			'Requirements vary by destination and by applicant. Airmark can provide a current checklist for the specific visa application. Submit only the documents requested for that application.',
	},
	{
		question: 'How long does visa processing take?',
		answer:
			'Processing time varies by destination, the application itself, and the embassy or consulate workload. Apply early, and confirm the current estimate with Airmark and the relevant authority before you lock travel dates.',
	},
	{
		question: 'How much does visa assistance cost?',
		answer:
			'Starting rates shown on this page are Korea ₱1,900, China ₱4,400, Dubai ₱7,900, US ₱18,500, Japan ₱2,500, and Schengen ₱11,500. These are starting rates only. Final fees depend on the destination, visa type, and current requirements. Confirm the total with Airmark before booking or paying.',
	},
	{
		question: 'Can you submit my application on my behalf, or do I need to appear in person?',
		answer:
			'Submission and attendance requirements depend on the destination’s rules and the particular application. Confirm with Airmark whether submission assistance is available, and whether you must attend an appointment or biometrics. The relevant authority makes the final decision.',
	},
	{
		question: 'Is my visa fee refundable if I get denied?',
		answer:
			'Refund terms depend on the fee and the service terms agreed before the application. Embassy and government fees may be non-refundable. Confirm the applicable written terms with Airmark before payment. A denial does not by itself guarantee a refund.',
	},
];
