export type DeskContact = {
	regions: string;
	name: string;
	phone: string;
	email: string;
};

export const office = {
	label: 'Makati Office',
	address: 'Unit 407, SEDCCO I Building, 120 Rada Street, Legaspi Village, Makati City.',
};

/** Same directory printed in the site footer. Do not add names that are not listed there. */
export const deskContacts: DeskContact[] = [
	{
		regions: 'Korea | Europe | Thailand | China | Indonesia',
		name: 'Ms. Gelai',
		phone: '09691044577',
		email: 'gelai.airmark@gmail.com',
	},
	{
		regions: 'Korea | Japan | Hong Kong | Singapore | Cruise',
		name: 'Ms. Jhay',
		phone: '09568518768',
		email: 'jhayram.airmark@gmail.com',
	},
	{
		regions: 'Korea | Japan | Dubai',
		name: 'Ms. Cheng',
		phone: '09650322657',
		email: 'rachel.airmarksales@gmail.com',
	},
	{
		regions: 'Korea | Vietnam',
		name: 'Ms. Kylle',
		phone: '09675038880',
		email: 'kylle.airmarksales@gmail.com',
	},
	{
		regions: 'Korea | Taiwan | China',
		name: 'Ms. Cha',
		phone: '09171006026',
		email: 'salescha.airmark@gmail.com',
	},
	{
		regions: 'Domestic Packages',
		name: 'Sir Arn',
		phone: '09171744488',
		email: 'arn.airmark@gmail.com',
	},
];
