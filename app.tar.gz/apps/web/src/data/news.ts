export type NewsItem = {
	slug: string;
	category: string;
	status: string;
	title: string;
	summary: string;
	points: string[];
	image: string;
	imageAlt: string;
	accent: string;
	accentSoft: string;
	icon: 'plane' | 'fuel' | 'at';
	imageSide: 'left' | 'right';
};

export const newsItems: NewsItem[] = [
	{
		slug: 'aero-k-weekly-bulletin',
		category: 'Airline Update',
		status: 'Ongoing',
		title: 'Aero K Weekly Bulletin',
		summary:
			'A weekly roundup of Aero K flight schedules, route changes, seat availability, and fare alerts that affect our Korea and Asia departures.',
		points: [
			'Latest Aero K route openings and seasonal flight additions for Manila–Seoul and beyond.',
			'Promotional fare windows and early-bird rates exclusive to Airmark passengers.',
			'Weekly seat availability snapshots so you can plan bookings during peak pilgrimage and tour seasons.',
			'Schedule adjustments, cancellations, and rebooking advisories posted every Monday.',
		],
		image: 'https://images.hostinger.com/fa8ae359-b16d-438c-aa3f-96a642f23c24.png',
		imageAlt: 'Passenger jet flying above golden clouds at sunset',
		accent: '#f3a000',
		accentSoft: 'rgba(243, 160, 0, 0.18)',
		icon: 'plane',
		imageSide: 'left',
	},
	{
		slug: 'fuel-surcharge-updates',
		category: 'Fare Advisory',
		status: 'Ongoing',
		title: 'Fuel Surcharge Updates',
		summary:
			'Current fuel surcharge rates from partner airlines and how they influence your total package price, with guidance on timing your booking.',
		points: [
			'Updated fuel surcharge tables per carrier, refreshed as airlines publish revisions.',
			'Booking-window recommendations to lock in fares ahead of expected surcharge hikes.',
			'Breakdown of how surcharges are applied to base fares across Korea, Japan, China, and Europe routes.',
			'Notifications whenever a major carrier adjusts its fuel component mid-season.',
		],
		image: 'https://images.hostinger.com/37d9b2f9-3619-4b4d-99cb-b0f2a721e30f.png',
		imageAlt: 'Ground crew refueling an aircraft on the airport apron at golden hour',
		accent: '#2ec4b6',
		accentSoft: 'rgba(46, 196, 182, 0.18)',
		icon: 'fuel',
		imageSide: 'right',
	},
	{
		slug: 'travel-industry-news',
		category: 'Industry Insight',
		status: 'Ongoing',
		title: 'Travel Industry News',
		summary:
			'Curated headlines shaping the travel industry — visa policy changes, tourism trends, and airline developments relevant to your journeys.',
		points: [
			'Visa-free entry updates, new e-visa rollouts, and Schengen processing changes for Philippine travelers.',
			'Airline fleet news, new long-haul routes, and code-share agreements that expand travel options.',
			'Tourism board announcements and destination reopenings across our covered regions.',
			'Seasonal travel advisories and demand forecasts to help you plan smarter departures.',
		],
		image: 'https://images.hostinger.com/8d2db167-cbb9-4384-8c25-63affb71b6c0.png',
		imageAlt: 'Travel desk with a world map, camera, compass, and journal',
		accent: '#8b6cff',
		accentSoft: 'rgba(139, 108, 255, 0.2)',
		icon: 'at',
		imageSide: 'left',
	},
];
