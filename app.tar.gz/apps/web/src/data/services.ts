import {
	Map,
	BedDouble,
	Car,
	FileText,
	PlaneTakeoff,
	Headphones,
	type LucideIcon,
} from 'lucide-react';

export type Service = {
	icon: LucideIcon;
	title: string;
	description: string;
};

export const services: Service[] = [
	{
		icon: Map,
		title: 'Customized Tours',
		description:
			"We don't just plan vacations — we create bespoke journeys tailored to your preferences, budget, and travel style.",
	},
	{
		icon: BedDouble,
		title: 'Premium Hotel Accommodations',
		description:
			'Partnered with the finest hotels from chic boutique properties to full-service resorts across Asia and Europe.',
	},
	{
		icon: Car,
		title: 'Airport Transfers / Seat-in-Coach',
		description:
			'Seamless, comfortable transfers from airport to hotel. A great trip begins with convenience and comfort.',
	},
	{
		icon: FileText,
		title: 'Visa Assistance',
		description:
			'Expert visa processing for Korea, Japan, China, Dubai, and more. We guide you through every document requirement.',
	},
	{
		icon: PlaneTakeoff,
		title: 'Flight Booking',
		description:
			'Competitive airfares from Manila to your chosen destination. We handle bookings so you can focus on the adventure.',
	},
	{
		icon: Headphones,
		title: '24/7 Consultant Support',
		description:
			'Our dedicated travel consultants are always available — before, during, and after your journey.',
	},
];
