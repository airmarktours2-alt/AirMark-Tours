export type VietnamDay = {
	day: string;
	title: string;
	meals?: string;
	stops: string[];
};

export type VietnamContact = { label: string; value: string; href?: string };

export type VietnamPackage = {
	id: string;
	title: string;
	tagline: string;
	region: string;
	days: string;
	year: string;
	price: string;
	priceNote: string;
	airline: string;
	flyer: string;
	dates: string[];
	flights: string[];
	highlights: string[];
	inclusions: string[];
	exclusions: string[];
	hotel: string;
	contacts: VietnamContact[];
	itinerary: VietnamDay[];
};

export const vietnamPackages: VietnamPackage[] = [
	{
		id: 'vietnam-premium-escape',
		title: 'Vietnam Premium Escape',
		tagline: 'Hanoi · Sapa',
		region: 'Hanoi · Sapa · Cat Cat Village · Fansipan',
		days: '4D / 3N',
		year: '2026',
		price: '₱37,888',
		priceNote: 'Rate starts at · per pax · special promo · 10 slots left',
		airline: 'Vietnam Airlines',
		flyer:
			'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/ffa581ae4aab6b0339dc1bd0f5a98aa3.png',
		dates: ['Oct 29 – Nov 02, 2026 +₱1,000', 'December 17–21, 2026'],
		flights: ['VN 646 MNL–HAN 05:30–07:35', 'VN 647 HAN–MNL 00:20–04:30'],
		highlights: [
			'Full-service Vietnam Airlines — premium flying experience',
			'In-flight meals included',
			'23 kg check-in baggage',
			'10 kg carry-on',
			'All-in premium package: hotels, tours, meals and transfers',
			'Airport private transfer',
		],
		inclusions: [
			'Roundtrip airfare via Vietnam Airlines',
			'23 kg check-in baggage',
			'10 kg hand carry',
			'In-flight meals',
			'3 nights at 3★ hotel accommodation based on twin/double sharing',
			'Roundtrip airport–hotel transfer',
			'Tours and meals based on itinerary',
			'Coach with air conditioner and English-speaking guide',
		],
		exclusions: [
			'Applicable airline taxes',
			'Philippine travel tax',
			'Travel insurance',
			'Tipping: $5/pax/day',
			'Any service not mentioned in the itinerary',
		],
		hotel: 'Vista Hotel / Thang Long Espana — Hanoi. Sapa Village Hotel — Sapa.',
		contacts: [
			{ label: 'Email', value: 'kylie.airmarktours@gmail.com', href: 'mailto:kylie.airmarktours@gmail.com' },
			{ label: 'Mobile', value: '0967 503 8680', href: 'tel:09675038680' },
		],
		itinerary: [
			{
				day: 'Day 1',
				title: 'Hanoi – Sapa – Cat Cat Village',
				meals: 'L/D',
				stops: [
					'Arrival at Noi Bai International Airport',
					'Transfer to Sapa',
					'2 short breaks (30 minutes each)',
					'Arrival in Sapa',
					'Visit Cat Cat Village',
					'Check in at the hotel in Sapa',
				],
			},
			{
				day: 'Day 2',
				title: 'Fansipan – Moana Cafe',
				meals: 'B/L',
				stops: [
					'Breakfast at the hotel',
					'Transfer to Fansipan',
					'Fansipan Cable Car Station',
					'Explore Fansipan',
					'Buffet lunch on Fansipan mountain',
					'Visit Moana Cafe',
					'Visit Moana View Sapa',
				],
			},
			{
				day: 'Day 3',
				title: 'Hanoi – free day',
				meals: 'B/L',
				stops: [
					'Breakfast at the hotel',
					'Sapa hotel check-out',
					'Transfer back to Hanoi and check in at the hotel',
					'Visit St. Joseph Cathedral',
					'Free day',
				],
			},
			{
				day: 'Day 4',
				title: 'Hanoi city tour – departure',
				meals: 'B/L/D',
				stops: [
					'Breakfast at the hotel',
					'Visit the Ho Chi Minh complex',
					'Ba Dinh Square',
					'Presidential Palace',
					"Ho Chi Minh's House on stilts",
					'One Pillar Pagoda',
					'Visit Tran Quoc Pagoda',
					'Visit the Temple of Literature',
					'Explore the 36 streets of the Old Quarter',
					'Transfer to Noi Bai Airport for departure',
				],
			},
		],
	},
];
