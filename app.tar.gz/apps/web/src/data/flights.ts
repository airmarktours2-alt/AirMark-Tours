export const flightHero =
	'https://images.hostinger.com/f5e41c0f-3a53-4676-a520-94bdd89b97fd.png';

export const cabinClasses = ['Economy', 'Premium Economy', 'Business', 'First'] as const;

export type CabinClass = (typeof cabinClasses)[number];

export type FlightDestination = {
	code: string;
	city: string;
	country: string;
	label: string;
};

export const flightDestinations: FlightDestination[] = [
	{ code: 'ICN', city: 'Seoul', country: 'South Korea', label: 'Seoul (ICN)' },
	{ code: 'NRT', city: 'Tokyo', country: 'Japan', label: 'Tokyo (NRT)' },
	{ code: 'TPE', city: 'Taipei', country: 'Taiwan', label: 'Taipei (TPE)' },
	{ code: 'HKG', city: 'Hong Kong', country: 'Hong Kong SAR', label: 'Hong Kong (HKG)' },
	{ code: 'SIN', city: 'Singapore', country: 'Singapore', label: 'Singapore (SIN)' },
	{ code: 'BKK', city: 'Bangkok', country: 'Thailand', label: 'Bangkok (BKK)' },
	{ code: 'DXB', city: 'Dubai', country: 'United Arab Emirates', label: 'Dubai (DXB)' },
	{ code: 'CDG', city: 'Paris', country: 'France', label: 'Paris (CDG)' },
	{ code: 'PEK', city: 'Beijing', country: 'China', label: 'Beijing (PEK)' },
	{ code: 'SGN', city: 'Ho Chi Minh', country: 'Vietnam', label: 'Ho Chi Minh (SGN)' },
];

export const flightSteps = [
	{
		title: '1. Send Request',
		body: 'Fill the form with your preferred route, dates, and passengers.',
	},
	{
		title: '2. We Search',
		body: 'Our experts find the best available fares across major airlines.',
	},
	{
		title: '3. Confirm & Fly',
		body: 'We send you options, you pick, we finalize your booking.',
	},
];
