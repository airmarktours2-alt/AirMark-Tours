export type FaqItem = {
	question: string;
	answer: string;
};

export type FaqSection = {
	id: string;
	title: string;
	items: FaqItem[];
};

export const faqSections: FaqSection[] = [
	{
		id: 'booking',
		title: 'Booking & Payments',
		items: [
			{
				question: 'How do I book a tour package with Airmark?',
				answer:
					'Browse the tour packages on this site, then reach Airmark through the contact details on the website. Our team will check availability for your preferred dates and send booking instructions. Exact availability, fares, and final details should always be confirmed with Airmark before you commit.',
			},
			{
				question: 'Is a deposit required to reserve a slot?',
				answer:
					'Deposit requirements and due dates can differ from one package to another, depending on the airline, hotel, and tour operator. Please confirm the current terms with Airmark before booking so you know what is needed to hold a slot.',
			},
			{
				question: 'What payment methods do you accept?',
				answer:
					'Accepted payment methods can vary by package and booking channel. Ask Airmark to confirm the options available for your trip, and follow only the payment instructions they send you before transferring any funds.',
			},
			{
				question: 'What is your cancellation and refund policy?',
				answer:
					'Cancellation and refund terms depend on the specific package and its suppliers. Review the terms provided with your booking, and contact Airmark promptly if your plans change so the team can explain what applies to your reservation.',
			},
		],
	},
	{
		id: 'visa',
		title: 'Visa Assistance',
		items: [
			{
				question: 'Which visas can Airmark help me process?',
				answer:
					'Airmark offers visa documentation and assistance services. The visa types we can help with, and whether you are eligible, depend on the destination and your circumstances. Ask Airmark to confirm whether they handle the specific visa you need.',
			},
			{
				question: 'How long does visa processing take?',
				answer:
					'Processing times vary by destination, the completeness of the application, and the embassy or consulate workload. Apply early, and confirm the current estimate with Airmark and the relevant authority before you lock travel dates.',
			},
			{
				question: 'What documents do I need to submit?',
				answer:
					'Document requirements differ by destination and by applicant. Airmark can provide a current checklist for your specific application. Submit only the documents requested for that application.',
			},
			{
				question: 'Can you submit my visa application on my behalf?',
				answer:
					'Assistance and submission arrangements depend on the destination’s rules and the service you select. Confirm with Airmark whether they can lodge that particular application for you. The final decision always rests with the relevant embassy, consulate, or immigration authority.',
			},
		],
	},
	{
		id: 'packages',
		title: 'Tour Packages',
		items: [
			{
				question: "What's included in a typical tour package?",
				answer:
					'Inclusions vary by package. A listing may cover flights, accommodation, transfers, guided tours, or meals when those items are written into that itinerary. Treat the specific package page — its itinerary and inclusions — as the authoritative list for what you are buying.',
			},
			{
				question: 'What is NOT included in the package price?',
				answer:
					'Exclusions also vary. Check the exclusions listed on each package, and ask Airmark to clarify any fee that is not clearly stated before you book.',
			},
			{
				question: 'Are your tours group tours or private?',
				answer:
					'Airmark offers both package tours and private tours. Each listing states the tour type. Tell the team which arrangement you prefer so they can confirm what is available for your dates.',
			},
			{
				question: 'Can I travel with children, and is there a discount?',
				answer:
					'Child eligibility, pricing, and any discount depend on the package, the airline, and the accommodation. Ask Airmark to confirm the applicable ages and fares for your family before booking — we do not publish a single child rate that applies to every trip.',
			},
		],
	},
];

export const faqHero =
	'https://images.hostinger.com/1a9c9535-3cf7-40f1-bd80-232162708256.png';
