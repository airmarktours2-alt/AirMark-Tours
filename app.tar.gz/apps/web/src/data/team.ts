const BASE = 'https://media.base44.com/images/public/6a34dbb2a3effa96085abb37';

export const heroImage = `${BASE}/e3931a021_generated_d1828c63.png`;

export type HeroSlide = {
	image: string;
	caption: string;
};

export const heroSlides: HeroSlide[] = [
	{ image: heroImage, caption: 'Your Passport to Possibilities' },
	{ image: 'https://images.hostinger.com/23b3b9fc-64a0-4891-8262-1cf904c67274.png', caption: 'Sunsets Over Santorini' },
	{ image: 'https://images.hostinger.com/034b462b-e213-4475-92a2-c31fe1c82ade.png', caption: 'Tokyo & Mount Fuji' },
	{ image: 'https://images.hostinger.com/65b6995f-4675-4c42-bc66-36afbb930158.png', caption: 'Balloons Over Cappadocia' },
	{ image: 'https://images.hostinger.com/d348955d-af09-40d3-a7d8-846c15eb182b.png', caption: 'Escape to the Maldives' },
];

export const aboutImage = `${BASE}/e3931a021_generated_d1828c63.png`;

export type TeamMember = {
	name: string;
	role: string;
	image: string;
};

export const team: TeamMember[] = [
	{
		name: 'Mr. Arn',
		role: 'General Manager',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/99c8cd42c39490117313e0e4027aec5b.png',
	},
	{
		name: 'Ms. Cha',
		role: 'Sales Team Head',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/be49c524cd562c604db08cfecd2fabe3.png',
	},
	{
		name: 'Ms. Leonor',
		role: 'Admin and Finance Manager',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/c9fc115d784570e1071ba6ff5881ef29.png',
	},
	{
		name: 'Mr. Jed',
		role: 'Liaison Officer',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/1bdb1e8f37143a836a6f972a753a4c59.png',
	},
	{
		name: 'Ms. Mc',
		role: 'Visa Officer',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/f386a46a275af1a119cfa3f91c3b50b8.png',
	},
	{
		name: 'Ms. Glenda',
		role: 'Sales and Marketing Executive',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/efa78f07716db0601a696555c160a268.png',
	},
	{
		name: 'Ms. Cheng',
		role: 'Sales Executive',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/855f7654c9391437b350bbfc556d32ed.png',
	},
	{
		name: 'Ms. Gelai',
		role: 'Sales Executive',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/2c7c3134afb5f85fff56e79327ae89fa.png',
	},
	{
		name: 'Ms. Jhay',
		role: 'Sales Executive',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/01f851acd05b297d89bf7bded69a8c3c.png',
	},
	{
		name: 'Ms. Kylle',
		role: 'Sales Executive',
		image: 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/8b40cd8efc6f711bffd4a59aa8b0029d.png',
	},
	{
		name: 'Mr. Icy',
		role: 'President of Airmark',
		image: `${BASE}/87f2c4b94_1.png`,
	},
	{
		name: 'Ms. Jo',
		role: 'Travel Consultant',
		image: `${BASE}/6393cb3eb_2.png`,
	},
];
