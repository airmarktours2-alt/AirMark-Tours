export const domesticHero =
	'https://images.hostinger.com/eff37e3f-50df-413f-aebf-4f3522998174.png';

export const domesticCabinClasses = ['Economy', 'Premium Economy', 'Business', 'First'] as const;

export type DomesticCabinClass = (typeof domesticCabinClasses)[number];

export type DomesticDestination = {
	code: string;
	city: string;
	province: string;
	label: string;
};

export const domesticDestinations: DomesticDestination[] = [
	{ code: 'MPH', city: 'Boracay', province: 'Aklan', label: 'Boracay (MPH)' },
	{ code: 'CEB', city: 'Cebu', province: 'Cebu', label: 'Cebu (CEB)' },
	{ code: 'USU', city: 'Coron', province: 'Palawan', label: 'Coron (USU)' },
	{ code: 'ENI', city: 'El Nido', province: 'Palawan', label: 'El Nido (ENI)' },
	{ code: 'TAG', city: 'Bohol', province: 'Bohol', label: 'Bohol (TAG)' },
	{ code: 'IAO', city: 'Siargao', province: 'Surigao del Norte', label: 'Siargao (IAO)' },
	{ code: 'DVO', city: 'Davao', province: 'Davao del Sur', label: 'Davao (DVO)' },
	{ code: 'ILO', city: 'Iloilo', province: 'Iloilo', label: 'Iloilo (ILO)' },
	{ code: 'PPS', city: 'Puerto Princesa', province: 'Palawan', label: 'Puerto Princesa (PPS)' },
	{ code: 'CRK', city: 'Clark', province: 'Pampanga', label: 'Clark (CRK)' },
];

export const domesticSteps = [
	{
		title: '1. Send Request',
		body: 'Fill the form with your preferred route, dates, and passengers.',
	},
	{
		title: '2. We Search',
		body: 'Our experts find the best available domestic fares across local airlines.',
	},
	{
		title: '3. Confirm & Fly',
		body: 'We send you options, you pick, we finalize your booking.',
	},
];
