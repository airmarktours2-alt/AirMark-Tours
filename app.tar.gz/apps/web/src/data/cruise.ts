export type CruiseDay = {
	day: string;
	title: string;
	stops: string[];
};

export type CruiseContact = { label: string; value: string; href?: string };

export type CruisePackage = {
	id: string;
	title: string;
	tagline: string;
	region: string;
	days: string;
	year: string;
	price: string;
	priceNote: string;
	summary: string;
	ship?: string;
	airline?: string;
	flyer: string;
	dates: string[];
	addOns?: string[];
	inclusions: string[];
	exclusions: string[];
	terms?: string[];
	notes?: string[];
	contacts: CruiseContact[];
	itinerary: CruiseDay[];
};

const kaohsiungFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/920d3f197027662a50715efec4070a88.png';
const keelungFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/7695a249b3f65a4e90464307d4713997.png';
const disneyFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/6e445a1c90b916c492d40d129b7996b6.png';

export const cruiseHero = 'https://images.hostinger.com/74fe0509-4633-48a7-8988-8cd0a0f370a6.png';

const jhayram: CruiseContact[] = [
	{ label: 'Email', value: 'jhayram.airmark@gmail.com', href: 'mailto:jhayram.airmark@gmail.com' },
	{ label: 'Mobile', value: '0956 8518 768', href: 'tel:09568518768' },
];

const jhayramKeelung: CruiseContact[] = [
	{ label: 'Email', value: 'jhayram.airmark@gmail.com', href: 'mailto:jhayram.airmark@gmail.com' },
	{ label: 'Mobile', value: '0956 851 8768', href: 'tel:09568518768' },
];

export const cruisePackages: CruisePackage[] = [
	{
		id: 'kaohsiung-costa-serena',
		title: '4 Nights from Kaohsiung',
		tagline: 'Visa free · Costa Serena',
		region: 'Kaohsiung · Naha · Miyakojima',
		days: '4 nights',
		year: 'June 28 – July 02',
		price: '$330',
		priceNote: '1st & 2nd guest · 3rd & 4th guest $220',
		summary:
			'A visa-free Costa Serena sailing from Kaohsiung to Naha and Miyakojima, returning to Kaohsiung. The flyer prices the cruise fare at $330 for the 1st and 2nd guest and $220 for the 3rd and 4th guest, before the printed add-ons.',
		ship: 'Costa Serena',
		flyer: kaohsiungFlyer,
		dates: ['June 28 – July 02'],
		addOns: ['Port charge $130', 'Gratuities $64', 'Japan Intl Tourist Tax $10 (paid on board)'],
		inclusions: [
			'Accommodation',
			'Full-board meals',
			"Use of ship's facilities",
			'Daily activities',
			'Entertainment each night during the cruise',
		],
		exclusions: [
			'Airfare',
			'Shore excursions',
			'Personal services',
			'Beverage',
			'Wi-Fi',
			'Meals in specialty restaurants',
		],
		notes: ['Visa free, as printed on the flyer'],
		contacts: jhayram,
		itinerary: [
			{ day: '28 June', title: 'Kaohsiung, Taiwan', stops: ['Departure 19:00'] },
			{ day: '29 June', title: 'At sea', stops: ['At sea'] },
			{ day: '30 June', title: 'Naha, Japan', stops: ['Arrival 7:00', 'Departure 19:00'] },
			{ day: '01 July', title: 'Miyakojima, Japan', stops: ['Arrival 7:00', 'Departure 15:00'] },
			{ day: '02 July', title: 'Kaohsiung, Taiwan', stops: ['Arrival 14:00'] },
		],
	},
	{
		id: 'keelung-costa',
		title: '3 Nights from Keelung',
		tagline: 'Taiwan – Japan · inside cabin',
		region: 'Keelung · Okinawa (Naha) · Ishigaki',
		days: '3 nights',
		year: 'August 5–8, 2026',
		price: '$260',
		priceNote: '1st & 2nd guest · inside cabin',
		summary:
			'A Costa cruise from Keelung to Okinawa Island (Naha) and Ishigaki, returning to Keelung. The flyer prices the cruise fare at $260 for the 1st and 2nd guest in an inside cabin, for the August 5–8, 2026 sailing.',
		ship: 'Costa',
		flyer: keelungFlyer,
		dates: ['August 5–8, 2026'],
		addOns: ['Port charge $130', 'Gratuities $64', 'Japan Intl Tourist Tax $20 (paid on board)'],
		inclusions: [
			'Accommodation',
			'Full-board with various meals throughout the day',
			"Use of the ship's facilities",
			'Daily activities',
			'Entertainment each night during the cruise',
		],
		exclusions: [
			'Airfare',
			'Shore excursions',
			'Personal services',
			'Beverage',
			'Wi-Fi',
			'Meals in specialty restaurants',
		],
		contacts: jhayramKeelung,
		itinerary: [
			{ day: '05 August', title: 'Keelung, Taiwan', stops: ['Departure 16:00'] },
			{ day: '06 August', title: 'Okinawa Is. (Naha)', stops: ['Arrival 14:00', 'Departure 22:00'] },
			{ day: '07 August', title: 'Ishigaki', stops: ['Arrival 13:00', 'Departure 21:00'] },
			{ day: '08 August', title: 'Keelung, Taiwan', stops: ['Arrival 07:00'] },
		],
	},
	{
		id: 'disney-adventure',
		title: 'Disney Adventure',
		tagline: 'Fly & cruise via Singapore Airlines',
		region: 'Marina Bay Cruise Centre, Singapore',
		days: '4 days & 3 nights',
		year: '2026–2027',
		price: '₱79,798',
		priceNote: 'Starts from · per guest · minimum of two guests per stateroom',
		summary:
			'A Disney Cruise Line fly-and-cruise from Marina Bay Cruise Centre, Singapore, via Singapore Airlines. The flyer prints two inside-stateroom fares: from ₱79,798 per guest for January 11–14, 2027, and from ₱92,910 per guest for September 28 – October 1, 2026 and February 22–25, 2027.',
		ship: 'Disney Adventure',
		airline: 'Singapore Airlines',
		flyer: disneyFlyer,
		dates: ['Jan 11–14, 2027 · from ₱79,798 per guest', 'Sept 28 – Oct 1, 2026 · from ₱92,910 per guest', 'Feb 22–25, 2027 · from ₱92,910 per guest'],
		inclusions: [
			'Round-trip Economy Class airfare via Singapore Airlines',
			"3 nights' cruise accommodation in an Inside Stateroom",
			'Round-trip airport to cruise terminal transfers',
			'Full board meals',
			'7 themed areas of Disney Adventure',
			'Onboard activities and entertainment',
			'Scheduled character meet-and-greet (via Navigator App)',
		],
		exclusions: [],
		terms: [
			'Rates are subject to change and availability without prior notice.',
			'A 50% deposit is required upon confirmation of booking.',
			'Air tickets and transfers are non-refundable.',
			'Cruise cancellation and schedule applies — refer to the information to be provided in your booking confirmation.',
		],
		notes: [
			'Minimum of two (2) guests per stateroom',
			'Embarkation: Marina Bay Cruise Centre, Singapore',
			'Disney Discovery Reef',
			'Disney Imagination Garden',
			'Marvel Landing',
			'Toy Story Place',
			'San Fransokyo Street',
			'Town Square',
			'Wayfinder Bay',
		],
		contacts: jhayram,
		itinerary: [
			{
				day: 'Sailing',
				title: '4 days & 3 nights',
				stops: ['Embarkation at Marina Bay Cruise Centre, Singapore', 'The flyer does not print a port-by-port day plan'],
			},
		],
	},
];
