export const aboutPhotos = [
	{
		src: 'https://images.hostinger.com/4ec4cbda-1aec-4163-940e-ec1600ad238d.png',
		alt: 'Gyeongbokgung Palace courtyard in Seoul on a clear day',
	},
	{
		src: 'https://images.hostinger.com/05406efb-a89d-40f8-a92c-02f2087e0092.png',
		alt: 'N Seoul Tower seen from a tree-lined path at sunset',
	},
	{
		src: 'https://images.hostinger.com/1667d222-9ec3-402f-9817-63e26f64ec59.png',
		alt: 'A snow-covered Korean palace courtyard in winter',
	},
	{
		src: 'https://images.hostinger.com/522a7b55-f932-4807-ac22-e62abaafca1c.png',
		alt: 'Cherry blossoms beside a Korean palace pond at sunset',
	},
];

export const palaceBackdrop =
	'https://images.hostinger.com/99eb48f2-9275-46a4-b881-58afe422d6e8.png';

export const highlights = [
	'DOT Accredited Travel Agency',
	'Philippine-Based with Makati Office',
	'Specialized in Korea & Japan Tours',
	'Expert Visa Processing',
	'Dedicated Travel Consultants',
	'Thousands of Happy Travelers',
];

export const pillars = [
	{
		title: 'Our Vision',
		body: 'To be your first choice for Korea tours and visa services — delivering exceptional customer service and worry-free travel from start to finish.',
	},
	{
		title: 'Our Expertise',
		body: "Years of experience specializing in Korea, Japan, Vietnam, Thailand, Europe, and domestic travel. We know the complexities so you don't have to.",
	},
	{
		title: 'Our Promise',
		body: 'DOT accredited and Philippine-based. We are committed to providing reliable tour packages and seamless visa assistance every step of the way.',
	},
];

export type CompanyRow = {
	name: string;
	accent: 'navy' | 'gold';
	accreditations: string[];
	services: string[];
};

export const companies: CompanyRow[] = [
	{
		name: "AIRMARK TOUR & DEV'T INC.",
		accent: 'navy',
		accreditations: [
			'Accredited by the Korean Embassy & Ministry of Justice for Visa Applications',
			'Awarded Best Performance of Joint Promotion by Korea Tourism Organization (KTO) (2023, 2024, 2025)',
			'DOT Accredited Travel and Tour Agency',
		],
		services: [
			'Tour Packages / Private Tours',
			'Hotel Reservation',
			'Ticketing & Travel Insurance',
			'Documentation & Visa Processing',
		],
	},
	{
		name: 'AIRMARK AVIATION SERVICES INC.',
		accent: 'gold',
		accreditations: [
			'General Sales Agent of: Aero K, Air Busan, Loong Air, Central Airlines, OKAir',
		],
		services: [
			'Airline Representation Services',
			'Sales & Marketing Support',
			'Passenger & Cargo Airline Promotion',
		],
	},
	{
		name: 'STEADFAST TOURS AND TRAVEL CORP.',
		accent: 'navy',
		accreditations: [
			'IATA Accredited Ticketing Agency',
			'Partners with: Foscon Shipmanagement, TBO, Hyundai Philippines',
		],
		services: ['Travel and Tours', 'Airline Ticketing', 'Corporate Travel Solutions'],
	},
	{
		name: 'BMG LANGUAGE CENTER INC.',
		accent: 'navy',
		accreditations: [
			'Technical Vocational Institute with Registered Program (Korean A1 Level)',
		],
		services: [
			'Language Courses in Korean / Japanese / Mandarin / English',
			'Translation Services',
		],
	},
];

export const tourServices = [
	'Airline Ticketing & Travel Insurance',
	'Hotels / Resort Reservation',
	'Package Tours / FIT',
	'Documentation / Visa Assistance',
];

export const gsaAirlines = ['Aero K', 'Air Busan', 'Loong Air', 'Central Airlines', 'OKAir'];

export const gsaSupport =
	'Airport Ground Handling / Cargo / Landing Permit / Slot Coordination';
