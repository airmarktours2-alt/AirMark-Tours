export type EventDay = {
	label: string;
	route: string;
	meals?: string;
	stops: string[];
	note?: string;
};

export type EventEntry = {
	slug: string;
	title: string;
	kind: string;
	place: string;
	summary: string;
	price?: string;
	priceNote?: string;
	datesLabel: string;
	dates: string[];
	dateNote?: string;
	flights?: { airline: string; legs: string[] };
	inclusions?: string[];
	exclusions?: string[];
	hotel?: string[];
	lineup?: { day: string; artists: string[] }[];
	days?: EventDay[];
	contacts: { label: string; value: string; href?: string }[];
	poster: string;
	posterAlt: string;
};

const grace =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/57770f302a028ac75dea4f6607bfa43a.jpg';
const run =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/1f93b47fb69cbb913bfd74395e1dc2aa.jpg';

export const events: EventEntry[] = [
	{
		slug: 'grace-in-korea',
		title: 'Grace in Korea: Pilgrimage & Leisure',
		kind: 'Pilgrimage and leisure',
		place: 'Incheon, Jecheon, Cheongju, Seoul',
		summary:
			'A four-day Airmark pilgrimage and leisure departure combining holy grounds, shrines, and Seoul sightseeing. Rate starts at ₱46,699 per person. Travel dates below are the 2026 departures printed on the flyer, including the stated date surcharges.',
		price: '₱46,699',
		priceNote: 'Rate starts at, per person',
		datesLabel: '2026 travel dates',
		dates: [
			'July 8–12',
			'July 15–19',
			'Aug 5–9',
			'Aug 19–23',
			'Sep 2–6',
			'Sep 16–20',
			'Sep 30–Oct 4',
			'Oct 14–18',
			'Oct 28–Nov 1 +₱1,000',
			'Nov 11–15',
			'Nov 25–29',
			'Nov 26–30 +₱3,500',
			'Dec 9–13',
			'Dec 23–27 +₱8,800',
		],
		flights: {
			airline: 'Korean Air',
			legs: ['KE 624 MNL ICN 2340 0425+1', 'KE 623 ICN MNL 1905 2225'],
		},
		inclusions: [
			'Roundtrip airfare via Korean Air',
			'Roundtrip airport transfer',
			'1 pc 23KG baggage and 10KG hand carry',
			'In-flight meal',
			'3 nights hotel accommodation (twin/triple sharing)',
			'Tours and meals based on the itinerary',
			'Free visa processing',
			'Free travel insurance (0–59 yrs)',
		],
		exclusions: ['Airline taxes', 'Tipping', 'PH travel tax'],
		hotel: ['1 night in Gloucester Hotel in Cheongju', '2 nights in Baiton Hotel in Deongdaemun'],
		days: [
			{
				label: 'Day 1',
				meals: 'B/L/D',
				route: 'Incheon – Jecheon – Cheongju',
				stops: [
					'Airport arrival',
					'Solmoe Holy Ground',
					'Haemi International Sanctuary',
					'Baeron Holy Ground',
					'Transfer to Cheongju',
					'Hotel check-in',
				],
			},
			{
				label: 'Day 2',
				meals: 'B/L/D',
				route: 'Cheongju – Anseong – Yongin – Seoul',
				stops: [
					'Breakfast at hotel',
					'Transfer to Anseong',
					'Mirinae Holy Site',
					'Everland Theme Park / N Seoul Tower',
					'Gyeongbok Palace + National Folklore Museum',
					'Namsan Hanok Village',
					'Back to the hotel',
				],
			},
			{
				label: 'Day 3',
				meals: 'B/L/D',
				route: 'Seoul – Nami Island – Seoul',
				stops: [
					'Breakfast at hotel',
					'Ginseng outlet',
					'Transfer to Namyang',
					'The Shrine of Our Lady of the Rosary',
					'Nami Island (Winter Sonata)',
					'Transfer to Seoul',
					'Back to the hotel',
				],
			},
			{
				label: 'Day 4',
				meals: 'B/L/X',
				route: 'Seoul – Incheon',
				stops: [
					'Breakfast at the hotel',
					'Red Pine Shop',
					'Cosmetic shop',
					'Jeoldusan Martyrs Shrine',
					'Myeongdong Cathedral Church & Museum',
					'Myeondong Shopping Street',
					'Transfer to Incheon International Airport',
				],
			},
		],
		contacts: [
			{ label: 'Email', value: 'rachel.airmarksales@gmail.com', href: 'mailto:rachel.airmarksales@gmail.com' },
			{ label: 'Viber', value: '09650322657', href: 'tel:09650322657' },
			{ label: 'Phone', value: '09171006026', href: 'tel:09171006026' },
		],
		poster: grace,
		posterAlt: 'Grace in Korea pilgrimage and leisure package flyer',
	},
	{
		slug: 'run-korea-run',
		title: 'Run Korea Run',
		kind: 'Run tour',
		place: 'Seoul and Suwon',
		summary:
			'Explore. Run. Experience Korea. A four-day run tour for as low as ₱48,888 per person, with the published travel date of October 7–11, 2026. The Suwon run is listed on Day 3; the flyer says the guide and bus stand by until the end of the event.',
		price: '₱48,888',
		priceNote: 'For as low as, per person',
		datesLabel: 'Travel date',
		dates: ['October 7–11, 2026'],
		flights: {
			airline: 'Korean Air',
			legs: ['KE 624 7OCT MNL ICN 2340 0425 +1', 'KE 623 11OCT ICN MNL 1905 2225'],
		},
		inclusions: [
			'Roundtrip airfare via Korean Air',
			'3-star hotel accommodation on twin',
			'1 pc 23kg check-in baggage and 10kg hand carry',
			'4-day tours, transfers and meals',
			'Travel insurance',
			'Daily informative tour guide',
			'Run tour ticket',
			'In-flight meals',
			'Free e-visa processing',
		],
		exclusions: ['Philippine travel tax', 'Airline taxes and terminal fee', 'Local tipping'],
		hotel: ['Baiton Dongdaemun Hotel Seoul or SML class'],
		days: [
			{
				label: 'Day 1',
				meals: 'L/D',
				route: 'Arrival',
				stops: [
					'Arrival at Incheon International Airport',
					'Transfer to Nami Island by bus',
					'Nami Island (ticket included)',
					'Transfer to Seoul',
					'COEX Starfield Byeolmadang Library',
					'Cheonggyecheon Stream',
				],
			},
			{
				label: 'Day 2',
				meals: 'B/L/D',
				route: 'Seoul',
				stops: [
					'Ginseng outlet',
					'Gyeongbokgung Palace with hanbok wearing (ticket included)',
					'Cosmetic shop',
					'Namsan Park',
					'N Seoul Tower with love lock by cable car (ticket included)',
					'Myeongdong Street',
				],
			},
			{
				label: 'Day 3',
				meals: 'B',
				route: 'Seoul – Suwon – Seoul',
				stops: [
					'Transfer to Suwon by bus',
					'Run trip: Suwon Hwaseong Haenggung (9:00–13:00)',
					'Back to Seoul and free time',
				],
				note: 'Guide and bus will stand by until the end of the event.',
			},
			{
				label: 'Day 4',
				meals: 'B/L',
				route: 'Seoul',
				stops: [
					'Red Pine Shop',
					'Amethyst showcase',
					'Hangdae Street and Gyeongui Line Forest Park',
					'The Hyundai',
					'Departure, Incheon International Airport',
				],
			},
		],
		contacts: [
			{ label: 'Email', value: 'glenda.airmark@gmail.com', href: 'mailto:glenda.airmark@gmail.com' },
			{ label: 'Phone', value: '09272508487', href: 'tel:09272508487' },
		],
		poster: run,
		posterAlt: 'Run Korea Run package flyer for October 7–11, 2026',
	},
];
