export const japanVisaHero =
	'https://images.hostinger.com/0425ad63-24cd-4123-b4e3-2cbcb36790f3.png';

export const japanVisaPurpose =
	'Visit Japan several times as temporary visitor for tourism, business or visiting relatives, etc. Applicants need to satisfy one of conditions I-V. Each stay must be within 30 days.';

export type JapanVisaRequirement = {
	number: string;
	title: string;
	body: string;
	notes?: string[];
};

export const japanVisaCommon: JapanVisaRequirement[] = [
	{
		number: '1',
		title: 'Passport',
		body: "Holder's signature required.",
	},
	{
		number: '2',
		title: 'Photocopy of Passport',
		body: 'Identification page only.',
	},
	{
		number: '3',
		title: 'Application Form',
		body: 'A facial photo (4.5×3.5cm) must be attached. Downloadable from the embassy website.',
	},
	{
		number: '4',
		title: 'Request for Multiple-Entry Visa',
		body: 'Downloadable from the embassy website.',
	},
	{
		number: '5',
		title: 'PSA Certificates',
		body: 'PSA issued Birth Certificate and Marriage Certificate (for married applicants), issued within 1 year. Unnecessary if there is a used Japan Visa on passport.',
		notes: [
			'If unreadable, submit Birth/Marriage Certificate issued by Local Civil Registrar.',
			'If LATE REGISTRATION, submit Baptismal Certificate and School Record (Form 137).',
			'If no PSA record, submit Birth Certificate from Local Civil Registrar and Negative Certificate from PSA.',
		],
	},
	{
		number: '6',
		title: 'Itinerary in Japan',
		body: 'Downloadable from the embassy website.',
	},
	{
		number: '7',
		title: 'Bank Certificate',
		body: 'Balance within the last six months must be shown.',
		notes: [
			'If ADB is not indicated, bank statement must be submitted to prove transactions within the last six months.',
		],
	},
	{
		number: '8',
		title: 'Tax Payment Certificate',
		body: 'Form 2316, must have signature of the Employer and Employee.',
		notes: [
			'For business owners, proof of actual payment of tax must be submitted in addition to the BIR Tax Payment Certificate Form (copy acceptable).',
		],
	},
	{
		number: '9',
		title: 'Employment Certificate',
		body: 'Must indicate period of employment, salary, and position.',
		notes: [
			"For business owners: DTI Certificate of Business Name Registration and Mayor's Permit.",
			'If unable to submit (7) and (8), a letter of explanation must be submitted.',
			'For students: copy of School ID or Certificate of Enrollment.',
		],
	},
];

export const japanVisaConditions = [
	'Applicant who traveled Japan as temporary visitor in the last 3 years and has financial capacity',
	'Applicant who traveled Japan (as temporary visitor) and G7 countries (several times, except Japan)',
	'Applicant with sufficient financial capacity',
	'Spouse/Child of Condition III (Applicant with sufficient financial capacity)',
];
