export type TaiwanDay = {
	day: string;
	title: string;
	stops: string[];
};

export type TaiwanContact = { label: string; value: string; href?: string };

export type TaiwanPackage = {
	id: string;
	title: string;
	tagline: string;
	region: string;
	days: string;
	year: string;
	price: string;
	priceNote: string;
	summary: string;
	airline?: string;
	hotel?: string;
	flyer: string;
	dates: string[];
	flights?: string[];
	inclusions: string[];
	exclusions: string[];
	contacts: TaiwanContact[];
	itinerary: TaiwanDay[];
};

const loveFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/f970cf8400f309727802ea5b70351dd7.png';
const christmasFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/461a5bc567dfb24f4b37df38a00e234d.png';

export const taiwanHero = 'https://images.hostinger.com/308e7658-f2f5-49ad-bc11-755bb7ceee0f.png';

const desk: TaiwanContact[] = [
	{ label: 'Email', value: 'salescha.airmarkl@gmail.com', href: 'mailto:salescha.airmarkl@gmail.com' },
	{ label: 'Phone', value: '09171006026', href: 'tel:09171006026' },
];

export const taiwanPackages: TaiwanPackage[] = [
	{
		id: 'love-in-taiwan',
		title: 'Love in Taiwan',
		tagline: 'For only $620 per person',
		region: 'Sun Moon Lake · Taichung · Taipei · Yehliu · Shifen',
		days: '4 days',
		year: 'Printed dates',
		price: '$620',
		priceNote: 'Per person · some dates carry a printed surcharge',
		summary:
			'A four-day EVA Air package priced at $620 per person, with 4-star hotels in Taichung and Taipei on twin sharing. The flyer covers Sun Moon Lake, Taichung, Taipei 101 (without observatory), Yehliu, and Shifen, plus a sky lantern for four.',
		airline: 'EVA Air',
		hotel: 'Hotel in Taichung 4* · Hotel in Taipei 4*',
		flyer: loveFlyer,
		dates: [
			'June 12–15 +$40',
			'June 15–18',
			'June 25–28',
			'July 23–26',
			'Aug 19–22',
			'Aug 25–28',
			'Sep 17–20',
			'Oct 15–18',
			'Oct 28–31',
			'Oct 29–Nov 01 +$20',
			'Nov 01–04 +$20',
			'Nov 26–29',
		],
		flights: [
			'BR 262 MNL–TPE 0545–0805',
			'BR 262 MNL–TPE 0340–0600 (Oct 26 onwards)',
			'BR 277 TPE–MNL 1515–1735',
		],
		inclusions: [
			'Roundtrip airfare via EVA Air',
			'23KG check-in baggage and 7KG hand carry baggage',
			'4-star hotel accommodation based on twin sharing',
			'Roundtrip airport–hotel transfer',
			'Tours and meals based on itinerary',
			'English speaking guide',
			'All admission fees',
		],
		exclusions: [
			'Tipping: $5/pax/day',
			'Philippine travel tax: $31/pax',
			'Travel insurance',
			'Child no bed (below 6 yrs and limit height below 1.1 meters): less $30/pax',
			'Single supplement: $159/pax',
			'Additional fuel surcharge: $29/pax RT (effective Apr 01, taxes subject to change)',
		],
		contacts: desk,
		itinerary: [
			{
				day: 'Day 1 · (L) Arrival',
				title: 'Taoyuan to Taichung',
				stops: [
					'Arrival at Taoyuan International Airport',
					'Sun Moon Lake (including boat experience)',
					'Tea agricultural store',
					'Taichung night market',
					'Taichung hotel check-in',
				],
			},
			{
				day: 'Day 2 · (B/L) Taichung – Taipei',
				title: 'Flower market to Taipei',
				stops: [
					'Chungshe Flower Market',
					'Taipei 101 (without observatory)',
					'Pineapple cake shop',
					'Chiang Kai Shek Memorial Hall',
					'Free time in Ximending area',
					'Taipei hotel check-in',
				],
			},
			{
				day: 'Day 3 · (B/L) Yehliu – Shifen',
				title: 'North coast and lanterns',
				stops: [
					'Taipei Jade Handicraft',
					'Yehliu Geopark',
					'Sky lantern (one lantern for 4 pax, included)',
					'Duty free shopping mall',
					'Taipei night market',
					'Back to hotel',
				],
			},
			{
				day: 'Day 4 · (B) Free day in Taipei',
				title: 'Departure',
				stops: ['Hotel check-out', 'Free time until transfer to airport', 'Transfer to airport for departure'],
			},
		],
	},
	{
		id: 'christmas-taiwan',
		title: 'Christmas Adventure in Taiwan',
		tagline: 'For only $610 per person · 2026 travel dates',
		region: 'Taichung · Yehliu · Shifen · Xinyi · Taipei',
		days: '4 days',
		year: '2026',
		price: '$610',
		priceNote: 'Per person · later December dates carry a printed surcharge',
		summary:
			'A 2026 Christmas departure priced at $610 per person on EVA Air, with 3 nights at a 4-star hotel in Taipei on twin sharing. The flyer includes Chungshe Flower Market, Yehliu, Shifen sky lanterns, Christmasland in Xinyi, and free time at Ximending.',
		airline: 'EVA Air',
		hotel: 'Hotel in Taipei 4* · 3 nights, twin sharing',
		flyer: christmasFlyer,
		dates: ['Dec 20–23', 'Dec 23–26 +$30', 'Dec 26–29 +$30', 'Dec 29–Jan 01 +$40'],
		flights: ['BR 262 MNL–TPE 0340–0600', 'BR 277 TPE–MNL 1530–1750'],
		inclusions: [
			'Roundtrip airfare via EVA Air',
			'1PC 23KG check-in baggage and 7KG hand carry baggage',
			'3 nights at 4* hotel accommodation based on twin sharing',
			'Roundtrip airport–hotel transfer',
			'Tours and meals based on itinerary',
			'Based on coach with air conditioner and English speaking guide',
			'All admission fees',
		],
		exclusions: [
			'Tipping: $5/pax/day',
			'Philippine travel tax: $31/pax',
			'Travel insurance',
			'Child no bed (below 6 yrs and limit height below 1.1 meters): less $30/pax',
			'Any service not mentioned in itinerary',
			'Single supplement: $159/pax',
			'Additional fuel surcharge: $29/pax RT (effective Apr 01, taxes subject to change)',
		],
		contacts: desk,
		itinerary: [
			{
				day: 'Day 1 · (L) Arrival',
				title: 'Taoyuan to Taichung',
				stops: [
					'Arrival at Taoyuan airport and meet the tour guide',
					'Transfer to Taichung',
					'Chungshe Flower Market Garden',
					'Taiwan night market',
					'Check in at hotel',
				],
			},
			{
				day: 'Day 2 · (B/L/D) Taipei',
				title: 'Coast, lanterns, and Christmasland',
				stops: [
					'Pineapple cake shop',
					'Yehliu Geopark',
					'Shifen Old Street',
					'Sky lantern (one lantern for 4 pax, included)',
					'Christmasland in Xinyi District',
				],
			},
			{
				day: 'Day 3 · (B/L) Taipei',
				title: 'City landmarks',
				stops: [
					'Taipei Jade Handicraft',
					'Shilin Official Residence',
					'Chiang Kai-Shek Memorial Hall',
					'Free time at Ximending',
				],
			},
			{
				day: 'Day 4 · (B) Departure',
				title: 'Airport transfer',
				stops: ['Hotel check out', 'Free time until transfer to airport', 'Transfer to airport for departure'],
			},
		],
	},
];
