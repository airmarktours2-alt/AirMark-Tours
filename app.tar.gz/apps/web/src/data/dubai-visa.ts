export const dubaiVisaHero =
	'https://images.hostinger.com/abb855ea-7c22-464d-83ae-a78e795378e2.png';

export const dubaiVisaRequirements = [
	'Accomplished Questionnaire',
	"Scanned copy of Passport's Bio Page with at least 12 months validity prior to departure (make sure page 3 is signed)",
	'Scanned copy of Passport Sized Colored Photo (4.5cm x 3.5cm) with white background',
	'Scanned copies of visas & all passport pages with travel stamps of the countries applicant had visited for the past five (5) years',
	'Copy of Confirmed Airline Ticket (departure and return ticket)',
	'Copy of Confirmed Hotel Booking (duration must be visible)',
];

export const dubaiVisaInclusions = [
	'Visa Consultancy',
	'Visa Fee (up to 30 days stay)',
	'Non-appearance Application',
	'UAE Travel Insurance',
];

export const dubaiVisaTerms = [
	"Applicant(s) must have a stable source of income here in the Philippines (Employed, Business Owner or Self-Employed).",
	'Visa approval is at the discretion of the Visa officers. We cannot guarantee 100% approval.',
	'Immigration Working Days: from Sunday to Thursday only.',
	'Visa Extension is not allowed.',
	'All Visa application is for single entry only and valid for up to 30 days stay.',
	'Visa processing takes five (5) to ten (10) working days and will be applied 30 days before the travel date since the validity of the visa is only 60 days. It must be used before it expires.',
	'Once Application is submitted to Immigration Department, the Visa Application Fee is non-refundable.',
	'In any case of delayed results and/or refusal of application, Airmark Tour shall not be held liable for the costs of airline ticket(s) and hotel accommodation(s).',
];
