export const koreaVisaHero =
	'https://images.hostinger.com/b0b164cb-cff2-4d6c-b099-47e3a58e3fe8.png';

export const koreaVisaChecklistPdf =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/bbfcad87adb88421f0a83f4589425662.pdf';

export const koreaVisaGroupNote =
	'This visa is processed and submitted to an Evisa Accredited Travel Agency in the Philippines. All applications must go through an accredited tour operator with a Korean counterpart.';

export const koreaVisaAgencyItems = [
	'Tour Operator Business Permit',
	'Tour Operator Contact Details',
	'Complete Itinerary with Flight details',
	'Guaranteed Letter from the Travel Agency (if the group of passengers are collective or regular tourists)',
];

export const koreaVisaCompanyDocuments = [
	{
		mark: 'a',
		text: "Photocopy of company business permits (latest Mayor's / SEC / DTI).",
	},
	{
		mark: 'b',
		text: 'Guaranteed letter from the company with a list of employees or participants (passport details), on company letterhead, with an original signature, notarized.',
	},
	{
		mark: 'c',
		text: 'Original bank certificate and bank statement, latest 3 months.',
	},
	{
		mark: 'e',
		text: 'Photocopy of ITR.',
	},
];

export const koreaVisaTourLeader = [
	{
		mark: 'a',
		text: 'Passport valid for more than 6 months from the date of travel.',
	},
	{
		mark: 'b',
		text: 'Passport-size picture.',
	},
	{
		mark: 'c',
		text: 'Application form, computerized, printed on A4 paper, 5 pages, with a live-ink signature on the 5th page.',
	},
	{
		mark: 'd',
		text: 'Certificate of employment on company letterhead, with telephone number and email address, full name of the applicant, designation, date started, and compensation. The purpose should be for a tourist visa application to South Korea.',
	},
	{
		mark: 'e',
		text: 'Bank certificate on bank letterhead, strictly with 6 months average daily balance, date opened, and current balance.',
	},
	{
		mark: 'f',
		text: 'Bank statements: last 3 months.',
	},
	{
		mark: 'g',
		text: 'Copy of latest ITR.',
	},
];

export const koreaVisaParticipants = [
	{
		mark: 'a',
		text: 'Original passports.',
	},
	{
		mark: 'b',
		text: 'Passport-size picture.',
	},
	{
		mark: 'c',
		text: 'Original certificate of employment on company letterhead, with telephone number and email address, full name of the applicant, designation, date started, and compensation. The purpose should be for a tourist visa application to South Korea, or a school certificate for an educational tourist.',
	},
];
