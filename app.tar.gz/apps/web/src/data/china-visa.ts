export const chinaVisaHero =
	'https://images.hostinger.com/7605ae01-1798-41f6-878d-c295174decc1.png';

export const chinaVisaBasic = [
	'Application Form (A4 size; typewritten)',
	'Original Passport (with signature)',
	'2 pcs Passport Size Picture',
	'Copy of Passport Biopage and Emergency Page',
	'Day to Day Itinerary',
	'Roundtrip Ticket',
	'Confirmed Hotel Booking',
];

export const chinaVisaFirstTime = [
	'Certificate of Employment (Original)',
	"Business Permits: SEC / DTI / Mayor's Permit (if applicable)",
	'Bank Certificate with 6 months ADB (issued within 1 month)',
	'Bank Statement for 6 months (issued within 1 month)',
	'Original Bank Receipt',
	'Income Tax Return (latest)',
];

export const chinaVisaReapplication = [
	'Original Passport (old and new with previous visa)',
	'2 pcs Passport Size Picture',
	'China Visa Application Form',
	'Photocopy of Passport Biopage and Previous China Visa',
];
