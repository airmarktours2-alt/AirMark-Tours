export const schengenVisaHero =
	'https://images.hostinger.com/08fccc67-2395-4166-bd3b-807779bb1a5c.png';

export const schengenCountries = [
	'Austria',
	'Belgium',
	'Bulgaria',
	'Croatia',
	'Czech Republic',
	'Denmark',
	'Estonia',
	'Finland',
	'France',
	'Germany',
	'Greece',
	'Hungary',
	'Iceland',
	'Italy',
	'Latvia',
	'Liechtenstein',
	'Lithuania',
	'Luxembourg',
	'Malta',
	'Netherlands',
	'Norway',
	'Poland',
	'Portugal',
	'Romania',
	'Slovakia',
	'Slovenia',
	'Spain',
	'Sweden',
	'Switzerland',
] as const;

export const schengenNotes = [
	'If travelling in multiple Schengen destinations, application must be done on the country with the longest stay or where the MAIN PURPOSE of travel (for Business) regardless of days.',
	'If with the same duration of stay, application may be done on the 1st country to visit for Leisure purposes.',
	'Schengen Visa is normally valid only on the declared travel dates on the application form unless otherwise approved with longer validity.',
	'You can apply for a Schengen visa as early as 180 days before your planned entry into the Schengen area, but it is generally recommended to apply around 3 months before your trip.',
];

export const schengenRequirements = [
	{
		title: 'Original Passport with Signature',
		body: 'Including old passport/s with previous Visa. Please remove any passport covers.',
	},
	{
		title: 'Application Form',
		body: 'Accomplished and signed forms.',
	},
	{
		title: 'Photo',
		body: '2 pcs. colored passport size (45mm x 35mm), white background, taken within the last 3 months. Avoid wearing white top. No eyeglasses. Eyebrows and ears must be visible. No jewelry. Teeth should not be visible.',
	},
	{
		title: 'Employed',
		body: 'Employment Certification (state position, date hired, salary and contact details of HR/Signatory in Company letterhead). If you are a doctor, lawyer, etc., please provide a copy of your ID. Must have an Approved Leave of Absence.',
	},
	{
		title: 'Self Employed',
		body: "Mayor's Permit, DTI (Single proprietor), SEC (For Corporation, must submit front copy of SEC and GIS).",
	},
	{
		title: 'ITR',
		body: 'Copy of Latest Income Tax Return (ITR) with BIR Stamp. For Self-employed ITR must include pages with Net income and total revenue.',
	},
	{
		title: 'Bank Documents',
		body: 'Bank Certification with Bank statements for the past 6 months; issued within 1 month of Biometrics schedule. ★ Portugal & Greece: Bank Cert + Bank Statements must be valid WITHIN 7 DAYS OF BIOMETRICS SCHEDULE (Portugal Visa is processed by Greece Embassy).',
	},
	{
		title: 'Travel Insurance',
		body: 'With Php2.5M Medical coverage covering the whole duration of the trip (Additional 15 Days coverage for ITALY). We offer Travel Insurance policies eligible for Schengen Visa applications.',
	},
	{
		title: 'Travel Details',
		body: 'a. Flight reservations/confirmation\nb. Hotel reservations (Confirmed Bookings are required)\nc. Detailed Day-to-Day Itinerary',
	},
	{
		title: 'Inviter / Sponsor',
		body: 'Letter of support / Invitation Letter from host, including contact details of inviter, copy of ID/passport (if any).',
	},
	{
		title: 'PSA Certificate',
		body: 'Marriage Certificate (For married applicants), Birth Certificate (For minor applicants) Issued within 1 year.',
	},
	{
		title: 'Personal Appearance',
		body: 'Required for Biometrics.',
	},
	{
		title: 'For Business Trip',
		body: 'Basic requirements for Tourist Visa + Endorsement letter from the Employer/Company & invitation from counterpart abroad. Travelling with Family: Proof of Ties (e.g. birth certificate of children or marriage certificate).',
	},
	{
		title: 'Additional Documents',
		body: 'Proof of ties in the Philippines, Proof of social security contributions (if relevant), Copy of real estate property — title-deed (if relevant).',
	},
];

export const schengenMinorRequirements = [
	'School registration/proof of enrollment',
	'PSA (Formerly NSO) Birth Certificate',
	'Affidavit of Support and Consent if not travelling with either or both parents',
];
