export type PhilippinesDay = {
	day: string;
	title: string;
	stops: string[];
	image: string;
	imageAlt: string;
	caption: string;
};

export type PhilippinesContact = { label: string; value: string; href?: string };

export type PhilippinesPackage = {
	id: string;
	title: string;
	tagline: string;
	region: string;
	days: string;
	year: string;
	price: string;
	priceNote: string;
	summary: string;
	airline?: string;
	hotel?: string;
	flyer: string;
	dates: string[];
	flights?: string[];
	inclusions: string[];
	exclusions: string[];
	optional?: string[];
	notes?: string[];
	contacts: PhilippinesContact[];
	itinerary: PhilippinesDay[];
};

const coronFlyer =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/7878bbc7dc332618d8faa22ecb9728d0.jpg';

export const philippinesHero = 'https://images.hostinger.com/00941d66-7be6-46a0-9202-4aacfa1ed0cd.png';

export const philippinesPackages: PhilippinesPackage[] = [
	{
		id: 'coron-4d3n',
		title: '4D3N Coron Package',
		tagline: 'Unwind. Explore. Fall in love with Coron!',
		region: 'Coron · Kayangan Lake · Twin Lagoon · Barracuda Lake',
		days: '4 days / 3 nights',
		year: '2027',
		price: 'Php 22,998',
		priceNote: 'Starts at · per pax',
		summary:
			'A 4-day, 3-night Coron getaway on Cebu Pacific, staying in a standard room at Tag Resort Coron. The flyer prices it from Php 22,998 per person and prints two island tours covering Kayangan Lake, Twin Lagoon, Barracuda Lake, Skeleton Wreck, and Siete Pecados.',
		airline: 'Cebu Pacific',
		hotel: 'Tag Resort Coron · Standard Room · 1 King / 2 Twin',
		flyer: coronFlyer,
		dates: ['1 May 2027 – 4 May 2027'],
		flights: [
			'CRK–USU · DG6039 · 1 May 2027 · 1315–1440',
			'USU–CRK · DG5294 · 4 May 2027 · 1625–1750',
		],
		inclusions: [
			'Round trip air ticket via Cebu Pacific Airlines',
			'Hotel accommodation based on Standard Room — 1 King / 2 Twin, Tag Resort Coron',
			'Daily breakfast',
			'Round trip transfers',
			'Coron Island Tour A: Kayangan Lake, CYC Beach, Coral Garden, Reef Garden, lunch area (white sand beach)',
			'Coron Island Tour B: Barracuda Lake, Twin Lagoon, Skeleton Wreck, Siete Pecados, lunch area (white sand beach)',
			'Environmental fee during tour',
		],
		exclusions: [
			'Check-in luggage',
			'Travel insurance',
			'Environmental fee upon arrival at the Coron (USU) airport',
			'Others not mentioned in the inclusions',
		],
		optional: [
			'Coron Super Ultimate Tour — Php 2,200/pax',
			'Island Escapade Tour — Php 2,200/pax',
			'Reefs and Wreck tour — Php 2,200/pax',
			'Calauit Safari with Black Island — Php 3,200/pax',
		],
		notes: [
			'Air fare rates and seats availability are subject to change without prior notice',
			'Final SOA to be provided once booking is confirmed',
			'Nature. Adventure. Paradise.',
		],
		contacts: [{ label: 'Mobile', value: '0917 174 4488 — ARN', href: 'tel:09171744488' }],
		itinerary: [
			{
				day: '01',
				title: 'Day 1 — Arrival in Coron',
				caption: 'Tag Resort Coron',
				image: 'https://images.hostinger.com/0d7feee2-38a2-488b-a757-7dd850773f50.png',
				imageAlt: 'Overwater cottages at Tag Resort Coron, Palawan',
				stops: [
					'Cebu Pacific DG6039 · CRK–USU · 1 May 2027 · 1315–1440',
					'Arrival at Busuanga Airport (USU)',
					'Round-trip transfer to the hotel',
					'Check in at Tag Resort Coron',
				],
			},
			{
				day: '02',
				title: 'Day 2 — Coron Island Tour A',
				caption: 'Kayangan Lake',
				image: 'https://images.hostinger.com/0840c949-f289-4991-978b-9761a5e4ef5a.png',
				imageAlt: 'Kayangan Lake limestone lagoon in Coron, Palawan',
				stops: [
					'Kayangan Lake',
					'CYC Beach',
					'Coral Garden',
					'Reef Garden',
					'Lunch area (white sand beach)',
				],
			},
			{
				day: '03',
				title: 'Day 3 — Coron Island Tour B',
				caption: 'Twin Lagoon',
				image: 'https://images.hostinger.com/70ebc779-cf84-4c59-b199-02e8ea692b92.png',
				imageAlt: 'Twin Lagoon in Coron, Palawan',
				stops: [
					'Barracuda Lake',
					'Twin Lagoon',
					'Skeleton Wreck',
					'Siete Pecados',
					'Lunch area (white sand beach)',
				],
			},
			{
				day: '04',
				title: 'Day 4 — Departure',
				caption: 'Skeleton Wreck, Coron',
				image: 'https://images.hostinger.com/fe123560-f3b1-4732-ae7c-dace092362f4.png',
				imageAlt: 'Snorkelers above a coral-covered wreck in clear Coron water',
				stops: ['Cebu Pacific DG5294 · USU–CRK · 4 May 2027 · 1625–1750', 'Transfer to Busuanga Airport for departure'],
			},
		],
	},
];
