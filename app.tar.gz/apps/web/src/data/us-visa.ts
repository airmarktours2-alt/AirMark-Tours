export const usVisaHero =
	'https://images.hostinger.com/f8a6c2dd-44a1-49eb-9ec3-974b4af71e09.png';

export const usVisaRates = [
	{
		label: 'New Application',
		price: '₱18,500',
		note: 'per client — processing fee included',
	},
	{
		label: 'Renewal + 2GO Courier',
		price: '₱19,300',
		note: 'per client — includes PHP 630 VFS fee',
	},
];

export const usVisaFeeNote =
	'Tourist/Business Visa (B1/B2): USD $185 application fee (approx. PHP 11,000 depending on exchange rate). Paid in local currency via RCBC.';

export const usVisaInclusions = [
	'Reviewing of Document Requirements',
	'Reviewing of DS-160 application',
	'Creation of DS-160 application through Online',
	'Creating Appointment for VISA Biometrics and Embassy Interview',
	'Dry run of questions and answer / set of possible interview questions',
	'Processing Fee',
	'VISA Application Fee (USD 185.00)',
	'2GO processing (applicable for dropbox application during US Visa Renewal only), including PHP 630.00 VFS Fee',
];

export const usVisaInterviewWaiver = [
	'IW Confirmation Letter',
	'Proof of Payment',
	'UID Number',
	'DS-160 Confirmation Number',
];

export const usVisaExclusions = ['Insurance', 'Courier Fee / Delivery Fee'];

export const usVisaAttendanceNote =
	'The client will personally attend their US Biometrics and US Interview schedule. Rate is subject to change without prior notice.';

export const usVisaDocuments = [
	{
		title: 'Original Passport',
		items: [
			'At least 6 months valid beyond intended stay.',
			'Passports must be signed and must have at least two (2) blank visa pages.',
		],
	},
	{
		title: 'Visa Application Form',
		items: ['Duly filled out non-immigrant visa electronic DS-160 form.'],
	},
	{
		title: 'One Copy of Visa Picture',
		items: ['Size of 2in x 2in or 5cm x 5cm, taken within the last 6 months.'],
	},
	{
		title: 'Application Fee Payment Receipt',
		items: [
			'A receipt showing payment of your USD 185 non-refundable visa application processing fee, paid in local currency (MRV receipt).',
		],
	},
	{
		title: 'Appointment Letter',
		items: ['A copy of your interview appointment letter.'],
	},
	{
		title: 'Supporting Documents',
		items: [
			'Proof of funds — Financial Capability: bank statements, pay slips, income tax returns, or employment certificates.',
			'Proof of relationships.',
			'Documents showing economic status.',
			'Purpose of Trip: Letter outlining travel plans, flight itinerary, or invitation letters from friends/family in the US.',
			'Ties to the Philippines: proof of employment, property ownership, vehicle ownership, business ownership (permits), or family ties.',
			'Personal Identification: PSA Birth Certificate, Marriage Certificate (if applicable), and NBI clearance for applicants aged 16 and older.',
		],
	},
];

export const usVisaNotes = [
	{
		label: 'Upcoming Fees',
		text: 'The new $250 Visa Integrity and Border Security Fee, signed in July 2025, is scheduled to apply to most nonimmigrant visas but currently lacks full implementation guidelines from the Bureau of Consular Affairs.',
	},
	{
		label: 'Bond Requirement',
		text: 'Some applicants might be required to post a bond between $5,000 – $15,000 after their interview.',
	},
	{
		label: 'Payment',
		text: 'Fees are paid in local currency at the Rizal Commercial Banking Corporation (RCBC) website.',
	},
];

export const usVisaDisclaimer =
	'Disclaimer: Visa fees change, and new laws are implemented. Always check the official U.S. Embassy in the Philippines website for the most current information.';
