import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Mail, Maximize2, Phone, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { hongKongHero, hongKongPackages, type HongKongPackage } from '@/data/hong-kong';

type Poster = { alt: string; src: string; title: string };

function highlights(pkg: HongKongPackage) {
	return pkg.region
		.split('·')
		.map((part) => part.trim())
		.filter(Boolean)
		.slice(0, 3);
}

export function HongKongPage() {
	const [activePoster, setActivePoster] = useState<Poster | null>(null);
	const [detail, setDetail] = useState<HongKongPackage | null>(null);

	const closeLightbox = useCallback(() => setActivePoster(null), []);
	const closeDetail = useCallback(() => setDetail(null), []);

	useEffect(() => {
		if (!activePoster && !detail) return;
		const onKey = (event: KeyboardEvent) => {
			if (event.key !== 'Escape') return;
			if (activePoster) closeLightbox();
			else closeDetail();
		};
		document.addEventListener('keydown', onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.removeEventListener('keydown', onKey);
			document.body.style.overflow = previous;
		};
	}, [activePoster, detail, closeLightbox, closeDetail]);

	return (
		<div className="bg-background text-foreground">
			<Navbar />
			<header className="relative min-h-[100dvh] overflow-hidden bg-[hsl(var(--navy))] text-white">
				<img
					src={hongKongHero}
					alt="Hong Kong skyline across Victoria Harbour"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover object-center"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,18,40,0.62)_0%,rgba(8,18,40,0.34)_34%,rgba(8,18,40,0.55)_66%,rgba(8,18,40,0.9)_100%)]" />

				<div className="relative mx-auto flex min-h-[100dvh] max-w-[1320px] flex-col px-4 pt-[92px] sm:px-8 lg:px-10">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 py-2 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>

					<div className="flex flex-1 flex-col items-center justify-center px-2 pb-24 text-center">
						<p className="font-body text-[11px] font-semibold tracking-[0.32em] text-[#f3a000] uppercase">
							Hong Kong · Cebu Pacific
						</p>
						<h1 className="mt-4 font-editorial text-6xl font-medium leading-none text-white sm:text-7xl md:text-8xl">
							Hong Kong
						</h1>
						<p className="mt-5 max-w-2xl font-body text-sm leading-relaxed text-white/90 sm:text-base">
							Published Airmark flyers — Shop & Play, and Hong Kong with Macau. Open a poster full screen, or see the description for the fare, dates, and day plan.
						</p>
						<p className="mt-6 font-display text-2xl text-white">
							From <span className="text-[#f3a000]">$488</span> per person
						</p>
					</div>
				</div>

				<ul className="absolute inset-x-0 bottom-0 hidden border-t border-white/10 bg-[hsl(var(--navy))]/90 md:grid md:grid-cols-4">
					{['Cebu Pacific airfare', '3 nights hotel', 'Hotel breakfast', 'Private coach'].map((item) => (
						<li
							key={item}
							className="px-4 py-3 text-center font-body text-[11px] font-semibold tracking-[0.14em] text-white/80 uppercase"
						>
							{item}
						</li>
					))}
				</ul>
			</header>

			<section className="bg-background" aria-labelledby="hong-kong-catalog">
				<div className="bg-[hsl(var(--navy))] px-4 py-3 text-center text-white">
					<div className="mx-auto max-w-2xl">
						<p className="font-body text-[9px] font-semibold tracking-[0.32em] text-[#f3a000] uppercase">
							Featured Tours
						</p>
						<h2 id="hong-kong-catalog" className="mt-2 font-editorial text-[27px] leading-tight sm:text-[30px]">
							Choose Your Hong Kong Adventure
						</h2>
						<p className="mx-auto mt-1 max-w-[600px] font-body text-sm leading-5 text-white/70">
							Two carefully crafted journeys — a twin-city Hong Kong &amp; Macau escape and a luxurious Shop &amp; Play stay at the 5-star Nina Hotel.
						</p>
					</div>
				</div>
				<div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
					<ul className="mt-10 grid gap-8 sm:grid-cols-2">
						{hongKongPackages.map((pkg) => (
							<li key={pkg.id} className="flex flex-col">
								<figure className="group relative overflow-hidden rounded-2xl border-2 border-[#1d4e89] bg-white shadow-sm">
									<button
										type="button"
										onClick={() =>
											setActivePoster({
												alt: `${pkg.title} package flyer`,
												src: pkg.flyer,
												title: pkg.title,
											})
										}
										className="block w-full cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
										aria-label={`Open ${pkg.title} poster full screen`}
									>
										<img
											src={pkg.flyer}
											alt={`${pkg.title} package flyer`}
											width={800}
											height={1100}
											loading="lazy"
											className="aspect-[4/5] w-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.02]"
										/>
										<span className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-gradient-to-t from-[hsl(var(--navy))]/85 to-transparent px-4 py-3 font-body text-xs font-semibold text-white">
											<Maximize2 className="h-4 w-4" aria-hidden="true" />
											View poster
										</span>
									</button>
								</figure>

								<h3 className="mt-4 text-center font-display text-lg font-bold tracking-wide text-[hsl(var(--navy))] uppercase">
									{pkg.title}
								</h3>
								<p className="mt-3 rounded-lg bg-[#1d4e89] px-3 py-2 text-center font-body text-xs font-semibold tracking-[0.16em] text-white uppercase">
									{pkg.days}
								</p>
								<ul className="mt-3 list-disc space-y-1 pl-5 font-body text-sm text-foreground/80">
									{highlights(pkg).map((item) => (
										<li key={item}>{item}</li>
									))}
								</ul>
								<div className="mt-auto pt-4 text-center">
									<p className="font-body text-[11px] tracking-[0.18em] text-muted-foreground uppercase">From</p>
									<p className="font-display text-2xl text-[#e23b4a]">{pkg.price}/pax</p>
									<div className="mt-3 flex flex-col gap-2 sm:flex-row sm:justify-center">
										<button
											type="button"
											onClick={() => setDetail(pkg)}
											className="inline-flex min-h-11 items-center justify-center rounded-lg border border-[#1d4e89] px-4 font-body text-xs font-semibold tracking-[0.12em] text-[#1d4e89] uppercase transition-colors hover:bg-[#1d4e89] hover:text-white active:scale-[0.98]"
										>
											See description
										</button>
										<ContactTrigger className="inline-flex min-h-11 items-center justify-center rounded-lg px-4 font-body text-xs font-semibold tracking-[0.12em] text-[#e23b4a] uppercase hover:underline">
											Enquire →
										</ContactTrigger>
									</div>
								</div>
							</li>
						))}
					</ul>
				</div>
			</section>

			<section className="border-t border-white/10 bg-[hsl(var(--navy))] text-white">
				<div className="mx-auto max-w-3xl px-6 py-16 text-center">
					<h2 className="font-editorial text-4xl md:text-5xl">Your Hong Kong departure starts here</h2>
					<p className="mx-auto mt-4 max-w-xl font-body text-sm leading-relaxed text-white/70">
						Tell the desk which flyer and date you want. Seats and a written quotation are confirmed before you pay.
					</p>
					<div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
						<a
							href="mailto:jhayram.airmark@gmail.com"
							className="inline-flex min-h-11 items-center gap-2 font-body text-sm text-white/90 hover:text-[#f3a000]"
						>
							<Mail className="h-4 w-4" aria-hidden="true" />
							jhayram.airmark@gmail.com
						</a>
						<a
							href="tel:09568518768"
							className="inline-flex min-h-11 items-center gap-2 font-body text-sm text-white/90 hover:text-[#f3a000]"
						>
							<Phone className="h-4 w-4" aria-hidden="true" />
							0956 8518 768
						</a>
					</div>
					<ContactTrigger className="mt-8 inline-flex min-h-12 items-center justify-center rounded-full bg-[#f3a000] px-7 font-body text-sm font-semibold text-[hsl(var(--navy))] transition-colors hover:bg-[#ffad0a] active:scale-[0.98]">
						Contact Us
					</ContactTrigger>
				</div>
			</section>
			<Footer />

			{detail ? (
				<div
					className="fixed inset-0 z-[90] flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6"
					role="dialog"
					aria-modal="true"
					aria-labelledby="hong-kong-detail-title"
					onClick={closeDetail}
				>
					<div
						className="flex max-h-[100dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-2xl bg-background shadow-xl sm:max-h-[90dvh] sm:rounded-2xl"
						onClick={(event) => event.stopPropagation()}
					>
						<div className="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
							<div>
								<p className="font-mono text-[11px] tracking-[0.22em] text-primary uppercase">
									{detail.year} · {detail.days}
								</p>
								<h2 id="hong-kong-detail-title" className="font-display text-2xl text-[hsl(var(--navy))]">
									{detail.title}
								</h2>
								<p className="font-body text-sm text-muted-foreground">{detail.region}</p>
							</div>
							<button
								type="button"
								onClick={closeDetail}
								className="inline-flex min-h-11 min-w-11 shrink-0 items-center justify-center rounded-full bg-secondary text-[hsl(var(--navy))]"
								aria-label="Close description"
							>
								<X className="h-5 w-5" aria-hidden="true" />
							</button>
						</div>
						<div className="overflow-y-auto px-5 py-5">
							<p className="font-display text-2xl text-[hsl(var(--navy))]">{detail.price}</p>
							<p className="font-body text-sm text-muted-foreground">{detail.priceNote}</p>
							<p className="mt-4 font-body text-sm leading-relaxed text-foreground/80">{detail.summary}</p>
							{detail.airline ? (
								<p className="mt-2 font-body text-sm">
									Airline: <strong>{detail.airline}</strong>
								</p>
							) : null}
							{detail.hotel ? (
								<p className="mt-1 font-body text-sm">
									Hotel: <strong>{detail.hotel}</strong>
								</p>
							) : null}

							<h3 className="mt-6 font-display text-lg">Travel dates</h3>
							<ul className="mt-2 space-y-2">
								{detail.dates.map((date) => (
									<li key={date} className="rounded-xl bg-secondary px-3 py-2 font-mono text-xs">
										{date}
									</li>
								))}
							</ul>

							<div className="mt-6 grid gap-6 md:grid-cols-2">
								<div>
									<h3 className="font-display text-lg">Inclusions</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.inclusions.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</div>
								<div>
									<h3 className="font-display text-lg">Exclusions</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.exclusions.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</div>
							</div>

							<h3 className="mt-6 font-display text-lg">Itinerary</h3>
							<ol className="mt-3 space-y-3">
								{detail.itinerary.map((day) => (
									<li key={`${detail.id}-${day.day}`} className="rounded-xl bg-secondary/70 p-4">
										<p className="font-mono text-[11px] tracking-[0.2em] text-primary uppercase">Day {day.day}</p>
										<p className="font-display text-lg">{day.title}</p>
										<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm">
											{day.stops.map((stop) => (
												<li key={stop}>{stop}</li>
											))}
										</ul>
									</li>
								))}
							</ol>

							<h3 className="mt-6 font-display text-lg">For inquiries</h3>
							<ul className="mt-3 flex flex-wrap gap-3">
								{detail.contacts.map((contact) => (
									<li key={`${detail.id}-${contact.value}`}>
										<a
											href={contact.href}
											className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 font-body text-sm hover:border-primary hover:text-primary"
										>
											{contact.label === 'Mobile' ? <Phone className="h-4 w-4" aria-hidden="true" /> : <Mail className="h-4 w-4" aria-hidden="true" />}
											{contact.value}
										</a>
									</li>
								))}
							</ul>
						</div>
						<div className="flex flex-col gap-2 border-t border-border px-5 py-4 sm:flex-row sm:justify-end">
							<button
								type="button"
								onClick={() =>
									setActivePoster({
										alt: `${detail.title} package flyer`,
										src: detail.flyer,
										title: detail.title,
									})
								}
								className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-border px-5 font-body text-sm font-semibold"
							>
								<Maximize2 className="h-4 w-4" aria-hidden="true" />
								View poster
							</button>
							<ContactTrigger className="inline-flex min-h-11 items-center justify-center rounded-full bg-[#f3a000] px-5 font-body text-sm font-semibold text-[hsl(var(--navy))]">
								Enquire
							</ContactTrigger>
						</div>
					</div>
				</div>
			) : null}

			{activePoster ? (
				<div
					className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4"
					role="dialog"
					aria-modal="true"
					aria-label={activePoster.title}
					onClick={closeLightbox}
				>
					<button
						type="button"
						onClick={closeLightbox}
						className="absolute right-4 top-4 inline-flex min-h-11 min-w-11 items-center justify-center rounded-full bg-white text-[hsl(var(--navy))]"
						aria-label="Close poster"
					>
						<X className="h-5 w-5" aria-hidden="true" />
					</button>
					<img
						src={activePoster.src}
						alt={activePoster.alt}
						className="max-h-[92dvh] w-auto max-w-full object-contain"
						onClick={(event) => event.stopPropagation()}
					/>
				</div>
			) : null}
		</div>
	);
}
