import { ContactTrigger } from '@/components/contact/contact-panel';
import {
	Briefcase,
	Building2,
	Check,
	CircleCheck,
	GraduationCap,
	Hotel,
	MapPin,
	Plane,
	Ticket,
} from 'lucide-react';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import {
	AeroKMark,
	AirBusanMark,
	CentralAirlinesMark,
	LoongAirMark,
	OkAirMark,
} from '@/components/about/airline-marks';
import {
	aboutPhotos,
	companies,
	gsaSupport,
	highlights,
	palaceBackdrop,
	pillars,
	tourServices,
} from '@/data/about';

const logo =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/5ba0a291fc149a106f47489235da9b13.png';

const serviceIcons = [Ticket, Hotel, MapPin, Briefcase];
const airlineMarks = [AeroKMark, AirBusanMark, LoongAirMark, CentralAirlinesMark, OkAirMark];
const companyIcons = [Building2, Plane, Briefcase, GraduationCap];

export function AboutPage() {
	return (
		<div className="min-h-screen bg-white text-[#1b2740]">
			<Navbar />
			<main>
				<section className="relative overflow-hidden bg-[#f7f8fb] pt-[68px]">
					<div
						className="pointer-events-none absolute inset-0 opacity-[0.07]"
						style={{
							backgroundImage: `url(${palaceBackdrop})`,
							backgroundSize: 'cover',
							backgroundPosition: 'center',
						}}
						aria-hidden="true"
					/>
					<div className="relative mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:py-24">
						<div>
							<img
								src={logo}
								alt="Airmark Tour and Dev't Inc."
								width={280}
								height={72}
								className="h-14 w-auto sm:h-16"
							/>
							<h1 className="mt-6 font-display text-3xl font-bold tracking-tight text-[#152033] sm:text-[2.15rem]">
								Airmark Tour &amp; Dev&apos;t, Inc.
							</h1>
							<p className="mt-1 font-body text-sm text-[#5c6b82]">Airmark Aviation Services, Inc.</p>
							<p className="mt-6 max-w-md font-body text-[15px] leading-relaxed text-[#6b7c93]">
								A group of companies dedicated to aviation, travel, and language services — connecting
								the Philippines to the world.
							</p>
							<ContactTrigger className="mt-8 inline-flex min-h-11 items-center rounded-full bg-[#152033] px-5 font-body text-sm font-semibold text-white transition-colors hover:bg-[#1d3358] active:scale-[0.98]">
								Talk to a consultant
							</ContactTrigger>
						</div>
						<div className="rounded-[28px] bg-white p-3 shadow-[0_18px_50px_rgba(21,32,51,0.08)] sm:p-4">
							<div className="grid grid-cols-2 gap-3">
								{aboutPhotos.map((photo) => (
									<div key={photo.src} className="overflow-hidden rounded-2xl">
										<img
											src={photo.src}
											alt={photo.alt}
											width={640}
											height={640}
											className="aspect-square h-full w-full object-cover"
										/>
									</div>
								))}
							</div>
						</div>
					</div>
				</section>

				<section className="bg-white">
					<div className="mx-auto grid max-w-6xl gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16 lg:py-24">
						<div>
							<p className="font-body text-[11px] font-semibold tracking-[0.28em] text-[#c48a12] uppercase">
								Who we are
							</p>
							<h2 className="mt-3 font-display text-4xl font-bold leading-[1.05] tracking-tight text-[#121a2b] sm:text-5xl">
								Plan Your Trip
								<br />
								With Us
							</h2>
							<p className="mt-6 max-w-xl font-body text-[15px] leading-relaxed text-[#5d6d84]">
								At <strong className="font-semibold text-[#243044]">Airmark Tours</strong>, we specialize
								in crafting unforgettable experiences. As a trusted travel agency, we are committed to
								providing reliable tour packages and seamless visa assistance for Korea, Japan, Vietnam,
								and beyond.
							</p>
							<p className="mt-4 max-w-xl font-body text-[15px] leading-relaxed text-[#5d6d84]">
								Whether you&apos;re a first-time visitor or a seasoned traveler, we tailor our services
								to meet your needs, ensuring a smooth and enjoyable trip — from booking to landing back
								home.
							</p>
							<ul className="mt-8 grid gap-3 sm:grid-cols-2">
								{highlights.map((item) => (
									<li key={item} className="flex items-start gap-2.5 font-body text-sm text-[#3d4d66]">
										<CircleCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#e0a01a]" aria-hidden="true" />
										{item}
									</li>
								))}
							</ul>
							<a
								href="#group"
								className="mt-8 inline-flex min-h-11 items-center rounded-full bg-[#152033] px-5 font-body text-sm font-semibold text-white transition-transform hover:-translate-y-px active:scale-[0.98]"
							>
								Learn More About Us
							</a>
						</div>
						<div className="flex flex-col gap-4">
							{pillars.map((pillar) => (
								<article
									key={pillar.title}
									className="rounded-2xl border border-[#e7ebf2] bg-[#fbfcfe] px-6 py-5"
								>
									<h3 className="font-display text-lg font-bold text-[#152033]">{pillar.title}</h3>
									<p className="mt-2 font-body text-sm leading-relaxed text-[#5d6d84]">{pillar.body}</p>
								</article>
							))}
						</div>
					</div>
				</section>

				<section id="group" className="scroll-mt-24 bg-[#f6f7fb]">
					<div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
						<div className="text-center">
							<h2 className="font-display text-3xl font-bold tracking-wide text-[#152033] sm:text-4xl">
								AIRMARK GROUP OF COMPANIES
							</h2>
							<span className="mx-auto mt-3 block h-px w-16 bg-[#c9a15a]" aria-hidden="true" />
						</div>
						<div className="mt-8 overflow-hidden rounded-2xl border border-[#e4e8f0] bg-white shadow-[0_16px_40px_rgba(21,32,51,0.06)]">
							<div className="hidden grid-cols-[1.05fr_1.45fr_1fr] bg-[#15284a] px-5 py-3 text-[11px] font-semibold tracking-[0.14em] text-white uppercase md:grid">
								<span>Company</span>
								<span>Accreditations / Recognitions / Partnerships</span>
								<span>Services</span>
							</div>
							{companies.map((company, index) => {
								const Icon = companyIcons[index] ?? Building2;
								return (
									<article
										key={company.name}
										className={`grid gap-4 border-t border-[#eef1f6] px-5 py-5 md:grid-cols-[1.05fr_1.45fr_1fr] md:gap-6 ${
											index % 2 === 1 ? 'bg-[#f7f8fb]' : 'bg-white'
										} ${company.accent === 'gold' ? 'border-l-4 border-l-[#c9a15a]' : 'border-l-4 border-l-[#15284a]'}`}
									>
										<div className="flex items-start gap-3">
											<span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#15284a] text-white">
												<Icon className="h-4 w-4" aria-hidden="true" />
											</span>
											<h3 className="pt-1 font-body text-[13px] font-bold tracking-wide text-[#152033]">
												{company.name}
											</h3>
										</div>
										<ul className="space-y-2">
											{company.accreditations.map((item) => (
												<li key={item} className="flex gap-2 font-body text-[13px] leading-relaxed text-[#3f4e66]">
													<Check className="mt-0.5 h-4 w-4 shrink-0 text-[#1f7a4d]" aria-hidden="true" />
													<span>{item}</span>
												</li>
											))}
										</ul>
										<ul className="space-y-1.5">
											{company.services.map((item) => (
												<li key={item} className="flex gap-2 font-body text-[13px] leading-relaxed text-[#3f4e66]">
													<span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-[#15284a]" aria-hidden="true" />
													<span>{item}</span>
												</li>
											))}
										</ul>
									</article>
								);
							})}
						</div>
					</div>
				</section>

				<section className="relative overflow-hidden">
					<img
						src={palaceBackdrop}
						alt=""
						width={1600}
						height={900}
						className="absolute inset-0 h-full w-full object-cover"
					/>
					<div className="absolute inset-0 bg-white/78" />
					<div className="relative mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
						<h2 className="text-center font-display text-4xl font-bold text-[#2f5f9a] sm:text-5xl">
							Our Services
						</h2>
						<div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
							{tourServices.map((label, index) => {
								const Icon = serviceIcons[index] ?? Ticket;
								return (
									<article
										key={label}
										className="flex min-h-[180px] flex-col items-center justify-center rounded-2xl bg-white px-5 py-8 text-center shadow-[0_10px_30px_rgba(21,32,51,0.08)]"
									>
										<span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-[#eef3fb] text-[#2f5f9a]">
											<Icon className="h-5 w-5" strokeWidth={1.75} aria-hidden="true" />
										</span>
										<p className="mt-4 max-w-[12rem] font-body text-sm font-semibold leading-snug text-[#243044]">
											{label}
										</p>
									</article>
								);
							})}
						</div>
					</div>
				</section>

				<section className="relative overflow-hidden border-t border-white/40">
					<img
						src={aboutPhotos[2].src}
						alt=""
						width={1200}
						height={800}
						loading="lazy"
						className="absolute inset-0 h-full w-full object-cover"
					/>
					<div className="absolute inset-0 bg-white/82" />
					<div className="relative mx-auto max-w-6xl px-5 py-16 sm:px-8 lg:py-20">
						<h2 className="text-center font-display text-4xl font-bold text-[#2f5f9a] sm:text-5xl">
							Our Services (GSA)
						</h2>
						<div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
							{airlineMarks.map((Mark) => (
								<div
									key={Mark.name}
									className="flex min-h-[108px] items-center justify-center rounded-2xl bg-white px-3 py-4 shadow-[0_8px_24px_rgba(21,32,51,0.07)]"
								>
									<Mark className="h-14 w-full max-w-[150px]" />
								</div>
							))}
						</div>
						<p className="mt-8 text-center font-body text-sm font-medium text-[#3d4d66]">{gsaSupport}</p>
					</div>
				</section>
			</main>
			<Footer />
		</div>
	);
}
