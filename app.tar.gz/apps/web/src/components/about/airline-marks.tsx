type MarkProps = { className?: string };

export function AeroKMark({ className }: MarkProps) {
	return (
		<svg viewBox="0 0 160 48" className={className} role="img" aria-label="Aero K">
			<text x="4" y="34" fontFamily="Inter, sans-serif" fontSize="30" fontWeight="800" fill="#1a2744">
				Aero
			</text>
			<rect x="92" y="16" width="14" height="14" rx="2" fill="#f3a000" />
			<text x="110" y="34" fontFamily="Inter, sans-serif" fontSize="30" fontWeight="800" fill="#1a2744">
				K
			</text>
		</svg>
	);
}

export function AirBusanMark({ className }: MarkProps) {
	return (
		<svg viewBox="0 0 180 56" className={className} role="img" aria-label="Air Busan">
			<path d="M28 16c18-10 48-10 68 0" fill="none" stroke="#1d4e9f" strokeWidth="3" />
			<path d="M36 18c8 6 16 8 28 6" fill="none" stroke="#1d4e9f" strokeWidth="2" />
			<text x="18" y="42" fontFamily="Inter, sans-serif" fontSize="16" fontWeight="600" fill="#1d4e9f">
				AIR
			</text>
			<text x="62" y="44" fontFamily="Inter, sans-serif" fontSize="22" fontWeight="800" fill="#1d4e9f">
				BUSAN
			</text>
		</svg>
	);
}

export function LoongAirMark({ className }: MarkProps) {
	return (
		<svg viewBox="0 0 160 72" className={className} role="img" aria-label="Loong Air">
			<path
				d="M78 8c8 6 10 14 6 22-6 2-14-2-18-8 6-2 10-6 12-14z"
				fill="#e11d2e"
			/>
			<path d="M70 18c10 2 18 8 20 16-8 0-16-4-20-10z" fill="#b91c1c" />
			<text x="18" y="50" fontFamily="Inter, sans-serif" fontSize="16" fontWeight="700" fill="#111">
				长龙航空
			</text>
			<text x="28" y="66" fontFamily="Inter, sans-serif" fontSize="13" fontWeight="800" letterSpacing="1" fill="#111">
				LOONGAIR
			</text>
		</svg>
	);
}

export function CentralAirlinesMark({ className }: MarkProps) {
	return (
		<svg viewBox="0 0 180 56" className={className} role="img" aria-label="Central Airlines">
			<rect x="8" y="14" width="10" height="10" fill="#e11d48" />
			<rect x="20" y="14" width="10" height="10" fill="#f59e0b" />
			<rect x="8" y="26" width="10" height="10" fill="#2563eb" />
			<rect x="20" y="26" width="10" height="10" fill="#16a34a" />
			<text x="40" y="26" fontFamily="Inter, sans-serif" fontSize="13" fontWeight="700" fill="#1f2937">
				中州航空
			</text>
			<text x="40" y="42" fontFamily="Inter, sans-serif" fontSize="11" fontWeight="600" fill="#4b5563">
				Central Airlines
			</text>
		</svg>
	);
}

export function OkAirMark({ className }: MarkProps) {
	return (
		<svg viewBox="0 0 170 56" className={className} role="img" aria-label="OKAir">
			<path d="M18 36c6-16 16-22 22-18-8 2-12 10-10 20z" fill="#f97316" />
			<path d="M28 34c8-14 18-18 22-12-6 4-12 12-12 20z" fill="#fb923c" />
			<text x="52" y="30" fontFamily="Inter, sans-serif" fontSize="20" fontWeight="800" fill="#1d4e9f">
				OKAIR
			</text>
			<text x="52" y="46" fontFamily="Inter, sans-serif" fontSize="12" fontWeight="600" fill="#f97316">
				奥凯航空
			</text>
		</svg>
	);
}
