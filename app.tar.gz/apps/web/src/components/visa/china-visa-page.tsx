import { Link } from 'react-router';
import { ArrowLeft, ClipboardCheck } from 'lucide-react';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { ChinaVisaType } from '@/components/visa/china-visa-type';
import { chinaVisaBasic, chinaVisaHero } from '@/data/china-visa';

export function ChinaVisaPage() {
	return (
		<div className="min-h-screen bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[78dvh] overflow-hidden">
				<img
					src={chinaVisaHero}
					alt=""
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,16,28,0.38)_0%,rgba(6,18,32,0.28)_36%,rgba(7,17,31,0.62)_70%,rgba(7,17,31,1)_100%)]" />
				<div className="relative mx-auto flex min-h-[78dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-20 sm:px-8">
					<Link
						to="/visa"
						className="inline-flex min-h-11 w-fit items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-white/80 uppercase transition-colors hover:text-white"
					>
						<ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
						Back to Visa
					</Link>
					<div className="flex flex-1 flex-col items-center justify-center px-2 text-center">
						<p className="flex items-center gap-3 font-body text-[11px] font-semibold tracking-[0.32em] text-[#f2556a] uppercase">
							<span className="h-px w-8 bg-[#f2556a]/80" aria-hidden="true" />
							China Visa · PEK / PVG
							<span className="h-px w-8 bg-[#f2556a]/80" aria-hidden="true" />
						</p>
						<h1 className="mt-5 font-editorial text-[2.7rem] leading-[1.05] text-white sm:text-6xl md:text-7xl">
							China Visa <span className="italic text-[#f2556a]">Requirements</span>
						</h1>
						<p className="mt-5 max-w-xl font-body text-sm leading-relaxed text-white/75 sm:text-base">
							New application and re-application requirements for Filipino nationals visiting China.
						</p>
					</div>
				</div>
			</header>

			<main className="relative -mt-6 pb-6">
				<section className="mx-auto max-w-[760px] px-4 sm:px-8">
					<article className="rounded-2xl border border-white/10 bg-[#0c1830]/95 px-5 py-6 sm:px-7">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#12352c] text-[#3dce8a]">
								<ClipboardCheck className="h-4 w-4" aria-hidden="true" />
							</span>
							<div className="min-w-0 flex-1">
								<h2 className="font-display text-base font-semibold text-white sm:text-lg">Basic Requirements</h2>
								<p className="mt-1 font-body text-sm text-white/50">Required for all applicants</p>
								<ul className="mt-5 flex flex-col gap-3">
									{chinaVisaBasic.map((item) => (
										<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
											<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#3dce8a]" aria-hidden="true" />
											<span>{item}</span>
										</li>
									))}
								</ul>
							</div>
						</div>
					</article>
				</section>
				<ChinaVisaType />
			</main>
			<Footer />
		</div>
	);
}
