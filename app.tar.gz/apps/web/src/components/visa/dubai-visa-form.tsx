import { useState } from 'react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Check, Plane, Send } from 'lucide-react';

type FormState = {
	fullName: string;
	mobile: string;
	email: string;
	purpose: string;
	income: string;
	position: string;
	salary: string;
	countries: string;
};

const emptyForm: FormState = {
	fullName: '',
	mobile: '',
	email: '',
	purpose: '',
	income: '',
	position: '',
	salary: '',
	countries: '',
};

const requiredKeys: (keyof FormState)[] = ['fullName', 'mobile', 'email', 'purpose', 'income', 'countries'];

export function DubaiVisaForm() {
	const [values, setValues] = useState<FormState>(emptyForm);
	const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
	const [submitted, setSubmitted] = useState(false);

	function update(key: keyof FormState, value: string) {
		setValues((current) => ({ ...current, [key]: value }));
		setErrors((current) => ({ ...current, [key]: undefined }));
		setSubmitted(false);
	}

	function onSubmit(event: React.FormEvent<HTMLFormElement>) {
		event.preventDefault();
		const next: Partial<Record<keyof FormState, string>> = {};
		for (const key of requiredKeys) {
			if (!values[key].trim()) {
				next[key] = 'This field is required.';
			}
		}
		if (values.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
			next.email = 'Enter a valid email address.';
		}
		if (Object.keys(next).length > 0) {
			setErrors(next);
			setSubmitted(false);
			return;
		}
		setErrors({});
		setSubmitted(true);
	}

	return (
		<section className="mx-auto mt-8 max-w-[760px] px-4 pb-20 sm:px-8" aria-labelledby="dubai-form-heading">
			<form
				onSubmit={onSubmit}
				noValidate
				className="rounded-[22px] border border-white/10 bg-[#0b1528]/95 px-5 py-6 shadow-[0_20px_50px_rgba(0,0,0,0.28)] sm:px-7 sm:py-7"
			>
				<div className="flex items-start justify-between gap-4">
					<div>
						<p className="font-body text-[10px] font-semibold tracking-[0.22em] text-white/45 uppercase">
							Airmark Tour and Dev&apos;t Inc.
						</p>
						<h2 id="dubai-form-heading" className="mt-1 font-display text-lg font-semibold text-white sm:text-xl">
							Dubai Visa Questionnaire
						</h2>
					</div>
					<span className="inline-flex min-h-9 items-center gap-1.5 rounded-full border border-[#f3a000]/40 px-3 font-body text-[11px] font-semibold tracking-[0.16em] text-[#f3a000] uppercase">
						<Plane className="h-3.5 w-3.5" aria-hidden="true" />
						DXB
					</span>
				</div>

				<div className="mt-6 grid gap-4 sm:grid-cols-2">
					<Field
						id="full-name"
						label="Full Name"
						value={values.fullName}
						error={errors.fullName}
						onChange={(value) => update('fullName', value)}
						autoComplete="name"
					/>
					<Field
						id="mobile"
						label="Mobile Number"
						value={values.mobile}
						error={errors.mobile}
						onChange={(value) => update('mobile', value)}
						autoComplete="tel"
						inputMode="tel"
					/>
					<Field
						id="email"
						label="Email Address"
						type="email"
						value={values.email}
						error={errors.email}
						onChange={(value) => update('email', value)}
						autoComplete="email"
					/>
					<Field
						id="purpose"
						label="Purpose of Travel"
						value={values.purpose}
						error={errors.purpose}
						onChange={(value) => update('purpose', value)}
					/>
				</div>

				<p className="mt-7 text-center font-body text-[10px] font-semibold tracking-[0.28em] text-white/40 uppercase">
					Income Details
				</p>
				<div className="mt-3 rounded-2xl border border-white/10 px-4 py-4 sm:px-5">
					<Field
						id="income"
						label="Current Source of Income"
						value={values.income}
						error={errors.income}
						onChange={(value) => update('income', value)}
					/>
					<p className="mt-3 font-body text-xs text-white/45">
						If employed, kindly provide your current position and monthly salary
					</p>
					<div className="mt-3 grid gap-4 sm:grid-cols-2">
						<Field
							id="position"
							label="Current Position"
							value={values.position}
							onChange={(value) => update('position', value)}
						/>
						<Field
							id="salary"
							label="Monthly Salary"
							value={values.salary}
							onChange={(value) => update('salary', value)}
						/>
					</div>
				</div>

				<p className="mt-7 flex items-center justify-center gap-2 text-center font-body text-[10px] font-semibold tracking-[0.28em] text-white/40 uppercase">
					<span className="inline-block h-1.5 w-1.5 rounded-full bg-[#f3a000]" aria-hidden="true" />
					Travel History
				</p>
				<div className="mt-3">
					<label htmlFor="countries" className="font-body text-[11px] font-semibold tracking-[0.16em] text-[#f3a000] uppercase">
						Countries Visited for the Past 5 Years
					</label>
					<textarea
						id="countries"
						rows={4}
						value={values.countries}
						onChange={(event) => update('countries', event.target.value)}
						aria-invalid={errors.countries ? true : undefined}
						aria-describedby={errors.countries ? 'countries-error' : undefined}
						className="mt-2 w-full resize-y rounded-xl border border-white/10 bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none focus:border-[#f3a000]"
					/>
					{errors.countries ? (
						<p id="countries-error" className="mt-1.5 font-body text-xs text-[#ffb4b4]">
							{errors.countries}
						</p>
					) : null}
				</div>

				<button
					type="submit"
					className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#f3a000] font-body text-sm font-semibold text-[#152033] transition-transform hover:bg-[#ffb11a] active:scale-[0.99]"
				>
					<Send className="h-4 w-4" aria-hidden="true" />
					Submit Questionnaire
				</button>
				<p className="mt-3 text-center font-body text-xs leading-relaxed text-white/45">
					By submitting, you agree to be contacted by our Dubai visa consultants. Your information is kept strictly confidential.
				</p>

				{submitted ? (
					<div
						role="status"
						className="mt-5 flex gap-3 rounded-xl border border-[#3dce8a]/30 bg-[#12352c] px-4 py-3 font-body text-sm leading-relaxed text-[#d8ffe9]"
					>
						<Check className="mt-0.5 h-4 w-4 shrink-0 text-[#3dce8a]" aria-hidden="true" />
						<p>
							Questionnaire received on this page. This confirmation is shown here only — it is not an email and it is not saved for later. Contact our consultants to continue your Dubai visa file.
						</p>
					</div>
				) : null}
			</form>

			<div className="mt-8 text-center">
				<p className="font-body text-sm text-white/55">Need help with your Dubai visa application?</p>
				<ContactTrigger className="mt-4 inline-flex min-h-12 items-center justify-center rounded-full bg-[#f3a000] px-7 font-body text-sm font-semibold text-[#152033] transition-transform hover:bg-[#ffb11a] active:scale-[0.98]">
					Contact Our Consultants
				</ContactTrigger>
			</div>
		</section>
	);
}

function Field({
	id,
	label,
	value,
	onChange,
	error,
	type = 'text',
	autoComplete,
	inputMode,
}: {
	id: string;
	label: string;
	value: string;
	onChange: (value: string) => void;
	error?: string;
	type?: string;
	autoComplete?: string;
	inputMode?: 'tel' | 'email' | 'text';
}) {
	return (
		<div>
			<label htmlFor={id} className="font-body text-[11px] font-semibold tracking-[0.16em] text-[#f3a000] uppercase">
				{label}
			</label>
			<input
				id={id}
				type={type}
				value={value}
				autoComplete={autoComplete}
				inputMode={inputMode}
				onChange={(event) => onChange(event.target.value)}
				aria-invalid={error ? true : undefined}
				aria-describedby={error ? `${id}-error` : undefined}
				className="mt-2 h-12 w-full rounded-xl border border-white/10 bg-white px-4 font-body text-sm text-[#152033] outline-none focus:border-[#f3a000]"
			/>
			{error ? (
				<p id={`${id}-error`} className="mt-1.5 font-body text-xs text-[#ffb4b4]">
					{error}
				</p>
			) : null}
		</div>
	);
}
