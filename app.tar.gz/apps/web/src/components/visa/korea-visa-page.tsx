import { Link } from 'react-router';
import { ArrowLeft, Building2, Info } from 'lucide-react';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { KoreaVisaAudience } from '@/components/visa/korea-visa-audience';
import {
	koreaVisaAgencyItems,
	koreaVisaGroupNote,
	koreaVisaHero,
} from '@/data/korea-visa';

function MarkList({ items }: { items: { mark: string; text: string }[] }) {
	return (
		<ol className="mt-5 flex flex-col gap-3.5">
			{items.map((item) => (
				<li key={item.mark} className="flex gap-3">
					<span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#163a66] font-body text-[11px] font-semibold text-[#7eb6ff]">
						{item.mark}
					</span>
					<p className="font-body text-sm leading-relaxed text-white/75">{item.text}</p>
				</li>
			))}
		</ol>
	);
}

export function KoreaVisaPage() {
	return (
		<div className="min-h-screen bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[78dvh] overflow-hidden">
				<img
					src={koreaVisaHero}
					alt=""
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,16,28,0.22)_0%,rgba(6,18,32,0.12)_38%,rgba(7,17,31,0.55)_72%,rgba(7,17,31,1)_100%)]" />
				<div className="relative mx-auto flex min-h-[78dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-20 sm:px-8">
					<Link
						to="/visa"
						className="inline-flex min-h-11 w-fit items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-white/80 uppercase transition-colors hover:text-white"
					>
						<ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
						Back to Visa
					</Link>
					<div className="flex flex-1 flex-col items-center justify-center px-2 text-center">
						<p className="flex items-center gap-3 font-body text-[11px] font-semibold tracking-[0.32em] text-[#6eb6ff] uppercase">
							<span className="h-px w-8 bg-[#6eb6ff]/80" aria-hidden="true" />
							Korea Visa · ICN
							<span className="h-px w-8 bg-[#6eb6ff]/80" aria-hidden="true" />
						</p>
						<h1 className="mt-5 font-editorial text-[2.7rem] leading-[1.05] text-white sm:text-6xl md:text-7xl">
							Korea Visa <span className="italic text-[#6eb6ff]">Requirements</span>
						</h1>
						<p className="mt-5 max-w-xl font-body text-sm leading-relaxed text-white/75 sm:text-base">
							Group E-Visa — process and submit via an Evisa Accredited Travel Agency in the Philippines.
						</p>
					</div>
				</div>
			</header>

			<main className="relative -mt-6 pb-6">
				<section className="mx-auto flex max-w-[920px] flex-col gap-5 px-4 sm:px-8">
					<article className="rounded-2xl border border-[#2a4668] bg-[#0c1c33]/95 px-5 py-5 sm:px-6">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#163a66] text-[#7eb6ff]">
								<Info className="h-4 w-4" aria-hidden="true" />
							</span>
							<div>
								<h2 className="font-display text-base font-semibold text-white">Group E-Visa</h2>
								<p className="mt-1 font-body text-sm leading-relaxed text-white/70">{koreaVisaGroupNote}</p>
							</div>
						</div>
					</article>

					<article className="rounded-2xl border border-[#2a4668] bg-[#0c1c33]/95 px-5 py-6 sm:px-6">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#163a66] text-[#7eb6ff]">
								<Building2 className="h-4 w-4" aria-hidden="true" />
							</span>
							<div className="min-w-0 flex-1">
								<h2 className="font-display text-base font-semibold text-white sm:text-lg">
									For Travel Agency with Accredited Tour Operator in Korea
								</h2>
								<p className="mt-1 font-body text-sm text-white/55">
									Required from the travel agency processing the group visa
								</p>
								<ul className="mt-5 flex flex-col gap-3">
									{koreaVisaAgencyItems.map((item) => (
										<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
											<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#4d9dff]" aria-hidden="true" />
											<span>{item}</span>
										</li>
									))}
								</ul>
							</div>
						</div>
					</article>
				</section>

				<KoreaVisaAudience />
			</main>
			<Footer />
		</div>
	);
}
