import { useState } from 'react';
import { ChevronDown, ClipboardList, Info, Users } from 'lucide-react';
import { japanVisaCommon, japanVisaConditions, japanVisaPurpose } from '@/data/japan-visa';

type EntryType = 'multiple' | 'single';

const roman = ['I', 'II', 'III', 'IV'];

export function JapanVisaDetails() {
	const [entry, setEntry] = useState<EntryType>('multiple');
	const [openCondition, setOpenCondition] = useState<number | null>(null);
	const multiple = entry === 'multiple';

	return (
		<div className="mx-auto flex max-w-[920px] flex-col gap-5 px-4 pb-16 sm:px-8">
			<div className="flex justify-center">
				<div
					className="inline-flex rounded-full border border-white/10 bg-[#121c33] p-1"
					role="tablist"
					aria-label="Japan visa entry type"
				>
					<button
						type="button"
						role="tab"
						id="tab-multiple"
						aria-selected={multiple}
						aria-controls="panel-japan-entry"
						onClick={() => setEntry('multiple')}
						className={`inline-flex min-h-11 items-center rounded-full px-5 py-2 font-body text-sm font-semibold transition-colors ${
							multiple ? 'bg-[#ff5a6e] text-white' : 'text-white/70 hover:text-white'
						}`}
					>
						Multiple Entry
					</button>
					<button
						type="button"
						role="tab"
						id="tab-single"
						aria-selected={!multiple}
						aria-controls="panel-japan-entry"
						onClick={() => setEntry('single')}
						className={`inline-flex min-h-11 items-center rounded-full px-5 py-2 font-body text-sm font-semibold transition-colors ${
							!multiple ? 'bg-[#ff5a6e] text-white' : 'text-white/70 hover:text-white'
						}`}
					>
						Single Entry
					</button>
				</div>
			</div>

			<div id="panel-japan-entry" role="tabpanel" aria-labelledby={multiple ? 'tab-multiple' : 'tab-single'}>
				{multiple ? (
					<div className="flex flex-col gap-5">
						<article className="rounded-2xl border border-[#ff5a6e]/35 bg-[#0c1830]/95 px-5 py-5 sm:px-6">
							<div className="flex gap-3">
								<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#3a2430] text-[#ff8a98]">
									<Info className="h-4 w-4" aria-hidden="true" />
								</span>
								<div>
									<h2 className="font-display text-base font-semibold text-white">Purpose</h2>
									<p className="mt-1 font-body text-sm leading-relaxed text-white/70">
										Multiple entry. {japanVisaPurpose}
									</p>
								</div>
							</div>
						</article>

						<article className="rounded-2xl border border-white/10 bg-[#0c1830]/95 px-4 py-6 sm:px-6">
							<div className="flex gap-3">
								<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#3a2430] text-[#ff8a98]">
									<ClipboardList className="h-4 w-4" aria-hidden="true" />
								</span>
								<div>
									<h2 className="font-display text-base font-semibold text-white sm:text-lg">
										Common Requirements
									</h2>
									<p className="mt-1 font-body text-sm text-white/50">For a multiple-entry visa</p>
								</div>
							</div>
							<div className="mt-5 grid gap-3 md:grid-cols-2">
								{japanVisaCommon.map((item) => (
									<div
										key={item.number}
										className="rounded-xl border border-white/10 bg-[#0a1528] px-4 py-4"
									>
										<div className="flex gap-3">
											<span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-[#ff5a6e] font-body text-[11px] font-semibold text-white">
												{item.number}
											</span>
											<div>
												<h3 className="font-display text-sm font-semibold text-white">{item.title}</h3>
												<p className="mt-1 font-body text-sm leading-relaxed text-white/65">{item.body}</p>
												{item.notes ? (
													<ul className="mt-2 flex flex-col gap-1.5">
														{item.notes.map((note) => (
															<li
																key={note}
																className="font-body text-sm leading-relaxed text-white/55"
															>
																- {note}
															</li>
														))}
													</ul>
												) : null}
											</div>
										</div>
									</div>
								))}
							</div>
						</article>

						<article className="rounded-2xl border border-white/10 bg-[#0c1830]/95 px-4 py-6 sm:px-6">
							<div className="flex gap-3">
								<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#3a2430] text-[#ff8a98]">
									<Users className="h-4 w-4" aria-hidden="true" />
								</span>
								<div>
									<h2 className="font-display text-base font-semibold text-white sm:text-lg">
										Conditions and Specific Requirements
									</h2>
									<p className="mt-1 font-body text-sm text-white/50">
										Applicant must satisfy one of the four conditions below
									</p>
								</div>
							</div>
							<div className="mt-5 flex flex-col gap-3">
								{japanVisaConditions.map((label, index) => {
									const open = openCondition === index;
									return (
										<div
											key={label}
											className="overflow-hidden rounded-xl border border-white/10 bg-[#0a1528]"
										>
											<button
												type="button"
												className="flex min-h-[52px] w-full items-center gap-3 px-4 py-3 text-left"
												aria-expanded={open}
												onClick={() => setOpenCondition(open ? null : index)}
											>
												<span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-[#ff5a6e] font-body text-[11px] font-semibold text-white">
													{roman[index]}
												</span>
												<span className="flex-1 font-body text-sm font-medium text-white/90">{label}</span>
												<ChevronDown
													className={`h-4 w-4 shrink-0 text-white/45 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
													aria-hidden="true"
												/>
											</button>
											{open ? (
												<p className="border-t border-white/10 px-4 py-3 font-body text-sm leading-relaxed text-white/55">
													The supplied checklist does not list extra documents for this condition. Confirm the current papers with Airmark before you apply.
												</p>
											) : null}
										</div>
									);
								})}
							</div>
						</article>
					</div>
				) : (
					<article className="rounded-2xl border border-white/10 bg-[#0c1830]/95 px-5 py-6 sm:px-6">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#3a2430] text-[#ff8a98]">
								<Info className="h-4 w-4" aria-hidden="true" />
							</span>
							<div>
								<h2 className="font-display text-base font-semibold text-white">Single Entry</h2>
								<p className="mt-1 font-body text-sm leading-relaxed text-white/70">
									The checklist on this page is for a multiple-entry visa. Single-entry documents were not included in the supplied list. Confirm the current single-entry requirements with Airmark before you apply.
								</p>
							</div>
						</div>
					</article>
				)}
			</div>
		</div>
	);
}
