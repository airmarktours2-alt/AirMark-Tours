import { Link } from 'react-router';
import { AlertTriangle, ArrowLeft, Check, ClipboardList } from 'lucide-react';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { DubaiVisaForm } from '@/components/visa/dubai-visa-form';
import { dubaiVisaHero, dubaiVisaInclusions, dubaiVisaRequirements, dubaiVisaTerms } from '@/data/dubai-visa';

export function DubaiVisaPage() {
	return (
		<div className="min-h-screen bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[78dvh] overflow-hidden">
				<img
					src={dubaiVisaHero}
					alt="Dubai skyline and Burj Khalifa at dusk"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,14,28,0.42)_0%,rgba(6,16,32,0.28)_34%,rgba(7,17,31,0.72)_68%,rgba(7,17,31,1)_100%)]" />
				<div className="relative mx-auto flex min-h-[78dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-16 sm:px-8">
					<Link
						to="/visa"
						className="inline-flex min-h-11 w-fit items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-white/80 uppercase transition-colors hover:text-white"
					>
						<ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
						Back to Visa
					</Link>
					<div className="flex flex-1 flex-col items-center justify-center px-2 text-center">
						<p className="flex items-center gap-3 font-body text-[11px] font-semibold tracking-[0.32em] text-[#f3a000] uppercase">
							<span className="h-px w-8 bg-[#f3a000]/80" aria-hidden="true" />
							Dubai Visa · DXB
							<span className="h-px w-8 bg-[#f3a000]/80" aria-hidden="true" />
						</p>
						<h1 className="mt-5 font-editorial text-[2.7rem] leading-[1.05] text-white sm:text-6xl md:text-7xl">
							Visa <span className="italic text-[#f3a000]">Questionnaire</span>
						</h1>
						<p className="mt-5 max-w-xl font-body text-sm leading-relaxed text-white/75 sm:text-base">
							Complete this form so our consultants can prepare your Dubai visa application accurately and efficiently.
						</p>
					</div>
				</div>
			</header>

			<main className="relative -mt-8 pb-4">
				<section className="mx-auto grid max-w-[980px] gap-4 px-4 sm:px-8 lg:grid-cols-[1.35fr_0.85fr]">
					<article className="rounded-2xl border border-white/10 bg-[#0c1830]/95 px-5 py-6 sm:px-6">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#3a2a12] text-[#f3a000]">
								<ClipboardList className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-base font-semibold text-white sm:text-lg">
								Applicant&apos;s General Requirements
							</h2>
						</div>
						<ul className="mt-5 flex flex-col gap-3.5">
							{dubaiVisaRequirements.map((item) => (
								<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<span className="mt-1 h-3.5 w-3.5 shrink-0 rounded-[3px] border border-white/35" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
					</article>
					<article className="rounded-2xl border border-[#f3a000]/25 bg-[#101820]/95 px-5 py-6 sm:px-6">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#3a2a12] text-[#f3a000]">
								<Check className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-base font-semibold text-white sm:text-lg">Inclusions</h2>
						</div>
						<ul className="mt-5 flex flex-col gap-3.5">
							{dubaiVisaInclusions.map((item) => (
								<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<Check className="mt-0.5 h-4 w-4 shrink-0 text-[#f3a000]" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
					</article>
				</section>

				<section className="mx-auto mt-4 max-w-[980px] px-4 sm:px-8">
					<article className="rounded-2xl border border-white/10 bg-[#0c1830]/95 px-5 py-6 sm:px-7">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#3a2218] text-[#f3a000]">
								<AlertTriangle className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-base font-semibold text-white sm:text-lg">Terms and Conditions</h2>
						</div>
						<ul className="mt-5 grid gap-x-8 gap-y-3 sm:grid-cols-2">
							{dubaiVisaTerms.map((item) => (
								<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#f3a000]" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
					</article>
				</section>

				<DubaiVisaForm />
			</main>
			<Footer />
		</div>
	);
}
