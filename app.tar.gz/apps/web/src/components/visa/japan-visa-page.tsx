import { Link } from 'react-router';
import { ArrowLeft } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { JapanVisaDetails } from '@/components/visa/japan-visa-details';
import { japanVisaHero } from '@/data/japan-visa';

export function JapanVisaPage() {
	return (
		<div className="min-h-screen bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[78dvh] overflow-hidden">
				<img
					src={japanVisaHero}
					alt="Mount Fuji framed by cherry blossoms"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,16,28,0.28)_0%,rgba(6,18,32,0.18)_36%,rgba(7,17,31,0.62)_70%,rgba(7,17,31,1)_100%)]" />
				<div className="relative mx-auto flex min-h-[78dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-16 sm:px-8">
					<Link
						to="/visa"
						className="inline-flex min-h-11 w-fit items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-white/80 uppercase transition-colors hover:text-white"
					>
						<ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
						Back to Visa
					</Link>
					<div className="flex flex-1 flex-col items-center justify-center px-2 text-center">
						<p className="flex items-center gap-3 font-body text-[11px] font-semibold tracking-[0.32em] text-[#ff8a98] uppercase">
							<span className="h-px w-8 bg-[#ff8a98]/80" aria-hidden="true" />
							Japan Visa · HND
							<span className="h-px w-8 bg-[#ff8a98]/80" aria-hidden="true" />
						</p>
						<h1 className="mt-5 font-editorial text-[2.7rem] leading-[1.05] text-white sm:text-6xl md:text-7xl">
							Japan Visa <span className="italic text-[#ff5a6e]">Requirements</span>
						</h1>
						<p className="mt-5 max-w-xl font-body text-sm leading-relaxed text-white/75 sm:text-base">
							Tourism, business, or visiting relatives — select your visa type below.
						</p>
					</div>
				</div>
			</header>

			<main className="relative -mt-10">
				<JapanVisaDetails />
				<section className="mx-auto max-w-[720px] px-4 pb-20 text-center sm:px-8">
					<p className="font-body text-sm text-white/55">Ready to start your Japan visa application?</p>
					<ContactTrigger className="mt-4 inline-flex min-h-11 items-center justify-center rounded-full bg-[#ff5a6e] px-7 py-3 font-body text-sm font-semibold text-white shadow-[0_10px_24px_rgba(255,90,110,0.28)] transition-transform hover:-translate-y-px active:scale-[0.98]">
						Contact Our Consultants
					</ContactTrigger>
				</section>
			</main>
			<Footer />
		</div>
	);
}
