import { Link } from 'react-router';
import { ArrowLeft, ClipboardList, Info, SquareCheck, TriangleAlert, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import {
	usVisaAttendanceNote,
	usVisaDisclaimer,
	usVisaDocuments,
	usVisaExclusions,
	usVisaFeeNote,
	usVisaHero,
	usVisaInclusions,
	usVisaInterviewWaiver,
	usVisaNotes,
	usVisaRates,
} from '@/data/us-visa';

export function UsVisaPage() {
	return (
		<div className="min-h-screen bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[88dvh] overflow-hidden">
				<img
					src={usVisaHero}
					alt="Statue of Liberty against a blue sky"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover object-[center_30%]"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,22,48,0.38)_0%,rgba(10,28,58,0.28)_32%,rgba(8,22,46,0.62)_62%,rgba(7,17,31,1)_100%)]" />
				<div className="relative mx-auto flex min-h-[88dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-10 sm:px-8">
					<Link
						to="/visa"
						className="inline-flex min-h-11 w-fit items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-white/85 uppercase transition-colors hover:text-white"
					>
						<ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
						Back to Visa
					</Link>
					<div className="flex flex-1 flex-col items-center justify-center px-2 pb-28 text-center sm:pb-36">
						<p className="flex items-center gap-3 font-body text-[11px] font-semibold tracking-[0.28em] text-[#7eb6ff] uppercase">
							<span className="h-px w-8 bg-[#7eb6ff]/70" aria-hidden="true" />
							US Visa · B1/B2 Tourist &amp; Business
							<span className="h-px w-8 bg-[#7eb6ff]/70" aria-hidden="true" />
						</p>
						<h1 className="mt-4 font-editorial text-[2.8rem] leading-[1.02] text-white sm:text-6xl md:text-7xl">
							US Visa <span className="italic text-[#8eb8f5]">Requirements</span>
						</h1>
						<p className="mt-4 max-w-xl font-body text-sm leading-relaxed text-white/80 sm:text-base">
							New application and renewal — Tourist/Business Visa (B1/B2) assistance for Filipino applicants.
						</p>
					</div>
				</div>
			</header>

			<main className="relative -mt-28 pb-6 sm:-mt-32">
				<section className="mx-auto max-w-[980px] px-4 sm:px-8">
					<div className="grid gap-4 sm:grid-cols-2">
						{usVisaRates.map((rate) => (
							<article
								key={rate.label}
								className="rounded-2xl border border-white/15 bg-[#0b1a33]/80 px-6 py-6 backdrop-blur-sm"
							>
								<p className="font-body text-[11px] font-semibold tracking-[0.2em] text-[#7eb6ff] uppercase">
									{rate.label}
								</p>
								<p className="mt-3 font-display text-3xl font-semibold tracking-tight text-white">{rate.price}</p>
								<p className="mt-1 font-body text-sm text-white/65">{rate.note}</p>
							</article>
						))}
					</div>
					<p className="mt-4 rounded-2xl border border-white/12 bg-[#0b1a33]/70 px-5 py-4 font-body text-sm leading-relaxed text-white/80">
						<span className="font-semibold text-white">Tourist/Business Visa (B1/B2):</span>{' '}
						{usVisaFeeNote.replace('Tourist/Business Visa (B1/B2): ', '')}
					</p>
				</section>

				<section className="mx-auto mt-5 grid max-w-[980px] gap-4 px-4 sm:px-8 lg:grid-cols-[1.45fr_0.85fr]">
					<article className="rounded-2xl border border-white/10 bg-[#0c1830] px-5 py-6 sm:px-6">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#12305a] text-[#7eb6ff]">
								<SquareCheck className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-lg font-semibold">Inclusions</h2>
						</div>
						<ul className="mt-5 flex flex-col gap-3">
							{usVisaInclusions.map((item) => (
								<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#7eb6ff]" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
						<div className="mt-5 rounded-xl border border-[#3d6cb5]/50 bg-[#0a2144] px-4 py-4">
							<p className="font-body text-[11px] font-semibold tracking-[0.16em] text-[#9ec4ff] uppercase">
								Interview Waiver (IW) — for renewal Dropbox only
							</p>
							<ul className="mt-3 flex flex-col gap-2">
								{usVisaInterviewWaiver.map((item) => (
									<li key={item} className="flex gap-2.5 font-body text-sm text-white/85">
										<span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-white/70" aria-hidden="true" />
										<span>{item}</span>
									</li>
								))}
							</ul>
						</div>
					</article>

					<div className="flex flex-col gap-4">
						<article className="rounded-2xl border border-white/10 bg-[#0c1830] px-5 py-6 sm:px-6">
							<div className="flex items-center gap-3">
								<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#3a1d24] text-[#f0717a]">
									<X className="h-4 w-4" aria-hidden="true" />
								</span>
								<h2 className="font-display text-lg font-semibold">Exclusions</h2>
							</div>
							<ul className="mt-5 flex flex-col gap-3">
								{usVisaExclusions.map((item) => (
									<li key={item} className="flex gap-3 font-body text-sm text-white/85">
										<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#f0717a]" aria-hidden="true" />
										<span>{item}</span>
									</li>
								))}
							</ul>
						</article>
						<article className="rounded-2xl border border-white/10 bg-[#0c1830] px-5 py-5">
							<div className="flex gap-3">
								<Info className="mt-0.5 h-4 w-4 shrink-0 text-[#7eb6ff]" aria-hidden="true" />
								<p className="font-body text-sm leading-relaxed text-white/75">{usVisaAttendanceNote}</p>
							</div>
						</article>
					</div>
				</section>

				<section className="mx-auto mt-5 max-w-[980px] px-4 sm:px-8">
					<article className="rounded-2xl border border-white/10 bg-[#0c1830] px-5 py-6 sm:px-6">
						<div className="flex items-start gap-3">
							<span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#12305a] text-[#7eb6ff]">
								<ClipboardList className="h-4 w-4" aria-hidden="true" />
							</span>
							<div>
								<h2 className="font-display text-lg font-semibold">Document Requirements</h2>
								<p className="mt-1 font-body text-sm text-white/55">
									Additional documents may be required by the embassy without prior notice.
								</p>
							</div>
						</div>
						<div className="mt-5 grid gap-4 md:grid-cols-2">
							{usVisaDocuments.map((doc, index) => (
								<div key={doc.title} className="rounded-xl border border-white/10 bg-[#091428] px-4 py-4">
									<div className="flex items-center gap-3">
										<span className="flex h-7 w-7 items-center justify-center rounded-md bg-[#16325c] font-body text-xs font-semibold text-[#9ec4ff]">
											{index + 1}
										</span>
										<h3 className="font-display text-[15px] font-semibold">{doc.title}</h3>
									</div>
									<ul className="mt-3 flex flex-col gap-2">
										{doc.items.map((item) => (
											<li key={item} className="flex gap-2.5 font-body text-sm leading-relaxed text-white/75">
												<span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-white/55" aria-hidden="true" />
												<span>{item}</span>
											</li>
										))}
									</ul>
								</div>
							))}
						</div>
					</article>
				</section>

				<section className="mx-auto mt-5 max-w-[980px] px-4 sm:px-8">
					<article className="rounded-2xl border border-[#c9a84c]/35 bg-[#0c1830] px-5 py-6 sm:px-6">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#3a2a12] text-[#f3a000]">
								<TriangleAlert className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-lg font-semibold">Important Notes</h2>
						</div>
						<ul className="mt-5 flex flex-col gap-3.5">
							{usVisaNotes.map((note) => (
								<li key={note.label} className="flex gap-3 font-body text-sm leading-relaxed text-white/80">
									<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#f3a000]" aria-hidden="true" />
									<span>
										<span className="font-semibold text-[#f3a000]">{note.label}:</span> {note.text}
									</span>
								</li>
							))}
						</ul>
						<p className="mt-5 font-body text-xs leading-relaxed text-white/45 italic">{usVisaDisclaimer}</p>
					</article>
				</section>

				<section className="mx-auto max-w-[720px] px-4 py-14 text-center sm:px-8">
					<p className="font-body text-sm text-white/70">Ready to start your US visa application?</p>
					<ContactTrigger className="mt-5 inline-flex min-h-11 items-center justify-center rounded-full bg-[#3b6fe0] px-7 font-body text-sm font-semibold text-white transition-transform hover:-translate-y-px hover:bg-[#4a7cf0] active:scale-[0.98]">
						Contact Our Consultants
					</ContactTrigger>
				</section>
			</main>
			<Footer />
		</div>
	);
}
