import { useState } from 'react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Building2, Users } from 'lucide-react';

type Audience = 'company' | 'collective';

const companyDocuments = [
	'Photocopy of Company Business Permits (Latest Mayor’s / SEC / DTI)',
	'Guaranteed Letter from the company with a list of employees/participants (passport details) in company letterhead with original signature, notarized.',
	'Original Bank Cert and Bank Statement latest 3 months',
	'Photocopy of ITR',
];

const tourLeader = [
	'Passport valid for more than 6 months from the date of travel',
	'Passport size picture',
	'Application form (computerized, printed in A4 size paper, 5 pages, with live ink signature on the 5th page)',
	'Certificate of Employment – (on company letterhead with telephone number and email address, full name of the applicant, designation, date started, and compensation. The purpose should be for a tourist visa application to South Korea.)',
	'Bank Certificate – on bank letterhead, strictly with 6 months Average Daily Balance, date opened, and current balance',
	'Bank statements: last 3 months',
	'Copy of latest ITR',
];

const participants = [
	'Original passports',
	'Passport size picture',
	'Original Certificate of Employment – on company letterhead with telephone number and email address, full name of applicant, designation, date started, and compensation. The purpose should be for a tourist visa application to South Korea or School Certificate for an Educational tourist.',
];

function BulletList({
	items,
	dotClass,
}: {
	items: string[];
	dotClass: string;
}) {
	return (
		<ul className="mt-4 flex flex-col gap-3">
			{items.map((item) => (
				<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
					<span className={`mt-2 h-1.5 w-1.5 shrink-0 rounded-full ${dotClass}`} aria-hidden="true" />
					<span>{item}</span>
				</li>
			))}
		</ul>
	);
}

export function KoreaVisaAudience() {
	const [audience, setAudience] = useState<Audience>('company');

	return (
		<section className="mx-auto mt-8 max-w-[920px] px-4 sm:px-8" aria-labelledby="korea-audience-heading">
			<div className="flex justify-center">
				<div
					className="inline-flex max-w-full flex-wrap justify-center gap-1 rounded-full border border-white/10 bg-[#0c1830] p-1"
					role="tablist"
					aria-label="Korea visa applicant type"
				>
					<button
						type="button"
						role="tab"
						id="tab-company"
						aria-selected={audience === 'company'}
						aria-controls="panel-company"
						onClick={() => setAudience('company')}
						className={`inline-flex min-h-11 items-center gap-2 rounded-full px-4 py-2 font-body text-sm font-semibold transition-colors ${
							audience === 'company'
								? 'bg-[#2f6bff] text-white'
								: 'text-white/70 hover:text-white'
						}`}
					>
						<Building2 className="h-4 w-4" aria-hidden="true" />
						Company / Educational
					</button>
					<button
						type="button"
						role="tab"
						id="tab-collective"
						aria-selected={audience === 'collective'}
						aria-controls="panel-collective"
						onClick={() => setAudience('collective')}
						className={`inline-flex min-h-11 items-center gap-2 rounded-full px-4 py-2 font-body text-sm font-medium transition-colors ${
							audience === 'collective'
								? 'bg-[#2f6bff] text-white'
								: 'text-white/55 hover:text-white'
						}`}
					>
						<Users className="h-4 w-4" aria-hidden="true" />
						Collective / Regular Tourist
					</button>
				</div>
			</div>

			<h2 id="korea-audience-heading" className="sr-only">
				Applicant type requirements
			</h2>

			{audience === 'company' ? (
				<div
					id="panel-company"
					role="tabpanel"
					aria-labelledby="tab-company"
					className="mt-6 flex flex-col gap-4"
				>
					<article className="rounded-2xl border border-[#2a4668] bg-[#0c1c33]/95 px-5 py-5 sm:px-6">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#5b3d8a] text-white">
								<Building2 className="h-4 w-4" aria-hidden="true" />
							</span>
							<div className="min-w-0">
								<h3 className="font-display text-base font-semibold text-white">1. Company Documents</h3>
								<p className="font-body text-sm text-white/45">Company Incentives / Educational</p>
							</div>
						</div>
						<BulletList items={companyDocuments} dotClass="bg-[#a78bfa]" />
					</article>

					<article className="rounded-2xl border border-[#2a4668] bg-[#0c1c33]/95 px-5 py-5 sm:px-6">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#8a6a1f] text-white">
								<Users className="h-4 w-4" aria-hidden="true" />
							</span>
							<div className="min-w-0">
								<h3 className="font-display text-base font-semibold text-white">2. Tour Leader</h3>
								<p className="font-body text-sm text-white/45">
									One must be assigned among the group. Minor or Senior are not eligible to be a TL.
								</p>
							</div>
						</div>
						<BulletList items={tourLeader} dotClass="bg-[#f5c542]" />
					</article>

					<article className="rounded-2xl border border-[#2a4668] bg-[#0c1c33]/95 px-5 py-5 sm:px-6">
						<div className="flex gap-3">
							<span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#1f6b62] text-white">
								<Users className="h-4 w-4" aria-hidden="true" />
							</span>
							<div className="min-w-0">
								<h3 className="font-display text-base font-semibold text-white">
									3. Requirements for the Rest of Participants
								</h3>
							</div>
						</div>
						<BulletList items={participants} dotClass="bg-[#3dceb6]" />
					</article>
				</div>
			) : (
				<div id="panel-collective" role="tabpanel" aria-labelledby="tab-collective" className="mt-6">
					<article className="rounded-2xl border border-[#2a4668] bg-[#0c1c33]/80 px-6 py-12 text-center sm:px-10 sm:py-14">
						<span className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#163a66] text-[#7eb6ff]">
							<Users className="h-5 w-5" aria-hidden="true" />
						</span>
						<h3 className="mt-5 font-display text-xl font-semibold text-white sm:text-2xl">
							Collective or Regular Tourist
						</h3>
						<p className="mx-auto mt-4 max-w-md font-body text-sm leading-relaxed text-white/45">
							Please check the basic requirements and additional documents for collective or regular tourist.
							Contact our consultants directly for the complete updated checklist.
						</p>
						<ContactTrigger className="mt-7 inline-flex min-h-11 items-center justify-center rounded-full bg-[#2f6bff] px-6 py-2.5 font-body text-sm font-semibold text-white transition-colors hover:bg-[#2458d6] active:scale-[0.98]">
							Get Full Requirements
						</ContactTrigger>
					</article>
					<div className="mt-10 flex flex-col items-center px-4 text-center">
						<p className="font-body text-sm text-white/40">Ready to start your Korea visa application?</p>
						<ContactTrigger className="mt-4 inline-flex min-h-11 items-center justify-center rounded-full bg-[#2f6bff] px-6 py-2.5 font-body text-sm font-semibold text-white transition-colors hover:bg-[#2458d6] active:scale-[0.98]">
							Contact Our Consultants
						</ContactTrigger>
					</div>
				</div>
			)}
		</section>
	);
}
