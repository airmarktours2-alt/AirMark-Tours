import { Link } from 'react-router';
import { ArrowLeft, ClipboardList, Globe, Info, UserRound } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import {
	schengenCountries,
	schengenMinorRequirements,
	schengenNotes,
	schengenRequirements,
	schengenVisaHero,
} from '@/data/schengen-visa';

export function SchengenVisaPage() {
	return (
		<div className="min-h-screen bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[78dvh] overflow-hidden">
				<img
					src={schengenVisaHero}
					alt="Pont Alexandre III in Paris at dusk, lamps lit along the bridge"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover object-center"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,18,40,0.42)_0%,rgba(10,22,48,0.38)_38%,rgba(7,17,31,0.78)_72%,rgba(7,17,31,1)_100%)]" />
				<div className="relative mx-auto flex min-h-[78dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-16 sm:px-8">
					<Link
						to="/visa"
						className="inline-flex min-h-11 w-fit items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-white/85 uppercase transition-colors hover:text-white"
					>
						<ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
						Back to Visa
					</Link>
					<div className="flex flex-1 flex-col items-center justify-center px-2 pb-16 text-center sm:pb-24">
						<p className="flex items-center gap-3 font-body text-[11px] font-semibold tracking-[0.28em] text-[#8eb8f5] uppercase">
							<span className="h-px w-8 bg-[#8eb8f5]/70" aria-hidden="true" />
							Schengen · Europe
							<span className="h-px w-8 bg-[#8eb8f5]/70" aria-hidden="true" />
						</p>
						<h1 className="mt-4 font-editorial text-[2.6rem] leading-[1.05] text-white sm:text-6xl md:text-7xl">
							Schengen Visa <span className="italic text-[#8eb8f5]">Requirements</span>
						</h1>
						<p className="mt-4 max-w-xl font-body text-sm leading-relaxed text-white/80 sm:text-base">
							Processing time starts after securing a biometrics schedule. Schedule will depend on the available dates at the visa centers.
						</p>
					</div>
				</div>
			</header>

			<main className="relative -mt-20 pb-16 sm:-mt-24">
				<section className="mx-auto max-w-[980px] px-4 sm:px-8">
					<article className="rounded-[22px] border border-white/12 bg-[#0b1a33]/85 px-5 py-6 backdrop-blur-sm sm:px-7 sm:py-7">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#12305a] text-[#8eb8f5]">
								<Globe className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-lg font-semibold">Schengen Area — 29 Countries</h2>
						</div>
						<ul className="mt-5 flex flex-wrap gap-2">
							{schengenCountries.map((country) => (
								<li key={country}>
									<span className="inline-flex min-h-9 items-center rounded-full border border-[#3d6cb5]/55 bg-[#0a2144] px-3.5 font-body text-sm text-[#c5d8f5]">
										{country}
									</span>
								</li>
							))}
						</ul>
					</article>
				</section>

				<section className="mx-auto mt-4 max-w-[980px] px-4 sm:px-8">
					<article className="rounded-[22px] border border-white/12 bg-[#0c1830] px-5 py-6 sm:px-7">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#12305a] text-[#8eb8f5]">
								<Info className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-lg font-semibold">Important Notes</h2>
						</div>
						<ul className="mt-5 flex flex-col gap-3">
							{schengenNotes.map((note) => (
								<li key={note} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#8eb8f5]" aria-hidden="true" />
									<span>{note}</span>
								</li>
							))}
						</ul>
					</article>
				</section>

				<section className="mx-auto mt-4 max-w-[980px] px-4 sm:px-8">
					<article className="rounded-[22px] border border-white/12 bg-[#0c1830] px-5 py-6 sm:px-7">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#12305a] text-[#8eb8f5]">
								<ClipboardList className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-lg font-semibold">Requirements</h2>
						</div>
						<ol className="mt-5 grid gap-3 sm:grid-cols-2">
							{schengenRequirements.map((item, index) => (
								<li
									key={item.title}
									className="rounded-2xl border border-white/10 bg-[#091428] px-4 py-4 sm:px-5"
								>
									<div className="flex items-start gap-3">
										<span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#12305a] font-body text-xs font-semibold text-[#8eb8f5]">
											{index + 1}
										</span>
										<div>
											<p className="font-display text-[15px] font-semibold text-white">{item.title}</p>
											<p className="mt-1 whitespace-pre-line font-body text-sm leading-relaxed text-white/70">
												{item.body}
											</p>
										</div>
									</div>
								</li>
							))}
						</ol>
					</article>
				</section>

				<section className="mx-auto mt-4 max-w-[980px] px-4 sm:px-8">
					<article className="rounded-[22px] border border-white/12 bg-[#0c1830] px-5 py-6 sm:px-7">
						<div className="flex items-center gap-3">
							<span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#12305a] text-[#8eb8f5]">
								<UserRound className="h-4 w-4" aria-hidden="true" />
							</span>
							<h2 className="font-display text-lg font-semibold">Minor Applicants</h2>
						</div>
						<ul className="mt-5 flex flex-col gap-3">
							{schengenMinorRequirements.map((item) => (
								<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#8eb8f5]" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
					</article>
					<div className="mt-10 text-center">
						<p className="font-body text-sm text-white/65">Ready to start your Schengen visa application?</p>
						<ContactTrigger className="mt-4 inline-flex min-h-11 items-center justify-center rounded-full bg-[#3b82f6] px-6 font-body text-sm font-semibold text-white transition-transform hover:-translate-y-px hover:bg-[#4b8ef7] active:scale-[0.98]">
							Contact Our Consultants
						</ContactTrigger>
					</div>
				</section>
			</main>
			<Footer />
		</div>
	);
}
