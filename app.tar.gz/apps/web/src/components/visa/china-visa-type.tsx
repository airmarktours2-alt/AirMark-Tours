import { useState } from 'react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { RefreshCw, Star } from 'lucide-react';
import { chinaVisaFirstTime, chinaVisaReapplication } from '@/data/china-visa';

type ApplicationType = 'first' | 'reapply';

export function ChinaVisaType() {
	const [type, setType] = useState<ApplicationType>('first');
	const first = type === 'first';
	const items = first ? chinaVisaFirstTime : chinaVisaReapplication;

	return (
		<section className="mx-auto mt-8 max-w-[760px] px-4 pb-16 sm:px-8" aria-labelledby="china-type-heading">
			<div className="flex justify-center">
				<div
					className="inline-flex rounded-full border border-white/10 bg-[#121c33] p-1"
					role="tablist"
					aria-label="China visa application type"
				>
					<button
						type="button"
						role="tab"
						id="tab-first"
						aria-selected={first}
						aria-controls="panel-china-type"
						onClick={() => setType('first')}
						className={`inline-flex min-h-11 items-center gap-2 rounded-full px-5 py-2 font-body text-sm font-semibold transition-colors ${
							first ? 'bg-[#f2556a] text-white' : 'text-white/70 hover:text-white'
						}`}
					>
						<Star className="h-3.5 w-3.5" aria-hidden="true" />
						First Time
					</button>
					<button
						type="button"
						role="tab"
						id="tab-reapply"
						aria-selected={!first}
						aria-controls="panel-china-type"
						onClick={() => setType('reapply')}
						className={`inline-flex min-h-11 items-center gap-2 rounded-full px-5 py-2 font-body text-sm font-semibold transition-colors ${
							!first ? 'bg-[#f2556a] text-white' : 'text-white/70 hover:text-white'
						}`}
					>
						<RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
						Re-Application
					</button>
				</div>
			</div>

			<article
				id="panel-china-type"
				role="tabpanel"
				aria-labelledby={first ? 'tab-first' : 'tab-reapply'}
				className="mt-6 rounded-2xl border border-white/10 bg-[#0c1830]/90 px-5 py-6 sm:px-7"
			>
				<div className="flex gap-3">
					<span
						className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
							first ? 'bg-[#3a2430] text-[#f2556a]' : 'bg-[#3a3420] text-[#e6b325]'
						}`}
					>
						{first ? (
							<Star className="h-4 w-4" aria-hidden="true" />
						) : (
							<RefreshCw className="h-4 w-4" aria-hidden="true" />
						)}
					</span>
					<div className="min-w-0 flex-1">
						<h2 id="china-type-heading" className="font-display text-base font-semibold text-white sm:text-lg">
							{first ? 'First Time Applicants' : 'Re-Application'}
						</h2>
						<p className="mt-1 font-body text-sm text-white/50">
							{first
								? 'Additional documents required alongside the basic requirements'
								: 'For applicants with a previous China Visa'}
						</p>
						<ul className="mt-5 flex flex-col gap-3">
							{items.map((item) => (
								<li key={item} className="flex gap-3 font-body text-sm leading-relaxed text-white/85">
									<span
										className={`mt-2 h-1.5 w-1.5 shrink-0 rounded-full ${first ? 'bg-[#f2556a]' : 'bg-[#e6b325]'}`}
										aria-hidden="true"
									/>
									<span>{item}</span>
								</li>
							))}
						</ul>
					</div>
				</div>
			</article>

			<div className="mt-10 text-center">
				<p className="font-body text-sm text-white/55">Ready to start your China visa application?</p>
				<ContactTrigger className="mt-4 inline-flex min-h-11 items-center justify-center rounded-full bg-[#f2556a] px-6 font-body text-sm font-semibold text-white shadow-[0_8px_24px_rgba(242,85,106,0.28)] transition-transform hover:-translate-y-px active:scale-[0.98]">
					Contact Our Consultants
				</ContactTrigger>
			</div>
		</section>
	);
}
