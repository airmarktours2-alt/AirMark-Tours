import { useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, ChevronDown, CircleHelp } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { visaDestinations, visaFaqs, visaHero } from '@/data/visa';

export function VisaPage() {
	const [openIndex, setOpenIndex] = useState<number | null>(null);

	return (
		<div className="min-h-screen bg-white text-[#152033]">
			<Navbar />
			<header className="relative min-h-[46dvh] overflow-hidden">
				<img
					src={visaHero}
					alt="Airplane wing above clouds at sunrise"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(10,25,47,0.5)_0%,rgba(10,25,47,0.42)_45%,rgba(10,25,47,0.82)_100%)]" />
				<div className="relative mx-auto flex min-h-[46dvh] max-w-[1100px] flex-col px-4 pt-[92px] pb-10 sm:px-8">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>
					<div className="flex flex-1 flex-col justify-end pb-2 pt-10">
						<p className="font-body text-[11px] font-semibold tracking-[0.28em] text-[#f3a000] uppercase">
							Visa assistance
						</p>
						<h1 className="mt-3 font-editorial text-5xl leading-[1.05] text-white sm:text-6xl">Visa</h1>
						<p className="mt-4 max-w-xl font-body text-sm leading-relaxed text-white/80 sm:text-base">
							Starting rates for visa assistance on the destinations Airmark lists here. Eligibility, documents, and final fees are confirmed with the desk before you apply.
						</p>
					</div>
				</div>
			</header>

			<main className="relative bg-[#fbfcfe]">
				<div
					className="pointer-events-none absolute inset-0 opacity-[0.06]"
					style={{
						backgroundImage: `url(${visaHero})`,
						backgroundSize: 'cover',
						backgroundPosition: 'center',
					}}
					aria-hidden="true"
				/>
				<section className="relative mx-auto max-w-[1100px] px-4 py-16 sm:px-8 sm:py-20">
					<div className="mx-auto max-w-xl text-center">
						<p className="flex items-center justify-center gap-3 font-body text-[11px] font-semibold tracking-[0.28em] text-[#c48a12] uppercase">
							<span className="h-px w-8 bg-[#c48a12]" aria-hidden="true" />
							Visa destinations
							<span className="h-px w-8 bg-[#c48a12]" aria-hidden="true" />
						</p>
						<h2 className="mt-4 font-editorial text-4xl text-[#121a2b] sm:text-5xl">Choose Your Visa</h2>
						<p className="mx-auto mt-4 max-w-md font-body text-sm leading-relaxed text-[#6b7c93]">
							Expert visa processing for the world&apos;s most sought-after destinations. Tap a card to start your application with our consultants.
						</p>
					</div>
					<div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
						{visaDestinations.map((destination) => (
							<a
								key={destination.code}
								href={destination.href ?? '/#contact'}
								className="group relative block overflow-hidden rounded-[22px] shadow-[0_16px_40px_rgba(21,32,51,0.12)] transition-transform duration-200 hover:-translate-y-1 active:scale-[0.99]"
							>
								<img
									src={destination.image}
									alt={destination.alt}
									width={960}
									height={540}
									loading="lazy"
									className="aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
								/>
								<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,16,32,0.08)_20%,rgba(8,16,32,0.78)_100%)]" />
								<span className="absolute top-4 right-4 font-body text-[10px] font-semibold tracking-[0.22em] text-white/70 uppercase">
									Visa
								</span>
								<div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 px-5 pb-5 text-white">
									<div>
										<p className="font-body text-[11px] font-semibold tracking-[0.16em] text-[#f3a000]">
											{destination.code}
										</p>
										<p className="mt-1 font-display text-xl font-semibold tracking-tight sm:text-[1.35rem]">
											{destination.name}
										</p>
									</div>
									<div className="text-right">
										<p className="font-body text-[10px] font-semibold tracking-[0.14em] text-white/75 uppercase">
											Starts at
										</p>
										<p className="font-display text-xl font-semibold tracking-tight sm:text-[1.35rem]">
											{destination.price}
										</p>
									</div>
								</div>
							</a>
						))}
					</div>
					<p className="mt-6 text-center font-body text-xs leading-relaxed text-[#7a8799]">
						Prices are starting rates. Final fees depend on destination, visa type, and current requirements.
					</p>
				</section>

				<section className="relative border-t border-[#eef1f6] bg-[#f7f8fb]/90">
					<div className="mx-auto max-w-[860px] px-4 py-16 sm:px-8 sm:py-20">
						<div className="text-center">
							<p className="inline-flex items-center gap-2 font-body text-[11px] font-semibold tracking-[0.28em] text-[#c48a12] uppercase">
								<CircleHelp className="h-3.5 w-3.5" aria-hidden="true" />
								Visa FAQ
							</p>
							<h2 className="mt-3 font-editorial text-4xl text-[#121a2b] sm:text-[2.6rem]">
								Visa Assistance Questions
							</h2>
							<p className="mt-3 font-body text-sm text-[#6b7c93]">
								Everything you need to know about our visa processing services.
							</p>
						</div>
						<div className="mt-10 flex flex-col gap-3">
							{visaFaqs.map((item, index) => {
								const open = openIndex === index;
								return (
									<div
										key={item.question}
										className="overflow-hidden rounded-2xl border border-[#e6eaf1] bg-white shadow-[0_1px_2px_rgba(21,32,51,0.04)]"
									>
										<button
											type="button"
											className="flex min-h-[56px] w-full items-center justify-between gap-4 px-5 py-4 text-left font-body text-[15px] font-medium text-[#1a2740] transition-colors hover:bg-[#fafbfd]"
											aria-expanded={open}
											onClick={() => setOpenIndex(open ? null : index)}
										>
											<span>{item.question}</span>
											<ChevronDown
												className={`h-4 w-4 shrink-0 text-[#8b97a8] transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
												aria-hidden="true"
											/>
										</button>
										{open ? (
											<div className="border-t border-[#eef1f6] px-5 py-4 font-body text-sm leading-relaxed text-[#4d5d74]">
												{item.answer}
											</div>
										) : null}
									</div>
								);
							})}
						</div>
						<p className="mt-8 text-center font-body text-sm text-[#5c6b82]">
							Ready to start?{' '}
							<ContactTrigger className="inline font-semibold text-[#152033] underline decoration-[#f3a000] underline-offset-4">
								Contact Airmark
							</ContactTrigger>{' '}
							and confirm availability, documents, and the total for your application.
						</p>
					</div>
				</section>
			</main>
			<Footer />
		</div>
	);
}
