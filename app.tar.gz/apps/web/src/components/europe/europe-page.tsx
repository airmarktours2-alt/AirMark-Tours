import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Maximize2, Phone, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { europeHero, europePackages, type EuropePackage } from '@/data/europe';

type Poster = { alt: string; src: string; title: string };
type FilterId = 'all' | 'western' | 'balkans' | 'pilgrimage' | 'middle-east' | 'scandinavia';

const filters: { id: FilterId; label: string }[] = [
	{ id: 'all', label: 'All' },
	{ id: 'western', label: 'Western Europe' },
	{ id: 'balkans', label: 'Balkans' },
	{ id: 'pilgrimage', label: 'Pilgrimage' },
	{ id: 'middle-east', label: 'Türkiye & Middle East' },
	{ id: 'scandinavia', label: 'Scandinavia & Arctic' },
];

const categories: Record<string, FilterId[]> = {
	'uk-ireland': ['western'],
	'portugal-spain': ['western'],
	'spain-swiss-france': ['western'],
	switzerland: ['western'],
	pilgrimage: ['pilgrimage', 'western'],
	medjugorje: ['pilgrimage', 'balkans'],
	'scandinavia-balkans': ['scandinavia', 'balkans'],
	morocco: ['middle-east'],
	lapland: ['scandinavia'],
	'iceland-scandinavia-baltics': ['scandinavia'],
	'jordan-israel-egypt': ['middle-east', 'pilgrimage'],
	'greece-turkiye': ['middle-east'],
	'italy-switzerland-france': ['western'],
	'affordable-turkiye': ['middle-east'],
	'european-dream': ['western'],
	kazakhstan: ['middle-east'],
	'europe-timeless': ['western'],
	'spain-swiss-france-december': ['western'],
	balkans: ['balkans'],
	'aba-ginoong-maria': ['pilgrimage', 'western'],
	'ten-in-one-europe': ['western'],
};

function dayLabel(days: string) {
	const match = days.match(/(\d+)/);
	return match ? `${match[1]} days` : days;
}

function highlights(pkg: EuropePackage) {
	const places = pkg.region
		.split('·')
		.map((part) => part.trim())
		.filter(Boolean);
	if (places.length >= 2) return places.slice(0, 2);
	return pkg.itinerary.slice(0, 2).map((day) => day.title);
}

export function EuropePage() {
	const [activePoster, setActivePoster] = useState<Poster | null>(null);
	const [detail, setDetail] = useState<EuropePackage | null>(null);
	const [filter, setFilter] = useState<FilterId>('all');

	const closeLightbox = useCallback(() => setActivePoster(null), []);
	const closeDetail = useCallback(() => setDetail(null), []);

	const visible = useMemo(
		() =>
			filter === 'all'
				? europePackages
				: europePackages.filter((pkg) => (categories[pkg.id] ?? []).includes(filter)),
		[filter],
	);

	useEffect(() => {
		if (!activePoster && !detail) return;
		const onKey = (event: KeyboardEvent) => {
			if (event.key !== 'Escape') return;
			if (activePoster) closeLightbox();
			else closeDetail();
		};
		document.addEventListener('keydown', onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.removeEventListener('keydown', onKey);
			document.body.style.overflow = previous;
		};
	}, [activePoster, detail, closeLightbox, closeDetail]);

	return (
		<div className="bg-background text-foreground">
			<Navbar />
			<header className="relative min-h-[100dvh] overflow-hidden bg-[hsl(var(--navy))] text-white">
				<img
					src={europeHero}
					alt="European landmarks at dusk, from the Eiffel Tower and the Colosseum to alpine peaks, Amsterdam canals, and Santorini"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover object-center"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,18,40,0.62)_0%,rgba(8,18,40,0.38)_32%,rgba(8,18,40,0.55)_62%,rgba(8,18,40,0.86)_100%)]" />
				<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(8,18,40,0.55)_0%,rgba(8,18,40,0.12)_55%,transparent_78%)]" />

				<div className="relative mx-auto flex min-h-[100dvh] max-w-[1320px] flex-col px-4 pt-[92px] sm:px-8 lg:px-10">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 py-2 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>

					<div className="flex flex-1 flex-col items-center justify-center px-2 pb-24 text-center">
						<p className="font-body text-[11px] font-semibold tracking-[0.32em] text-[#f3a000] uppercase">
							Europe · Middle East · Beyond
						</p>
						<h1 className="mt-4 font-editorial text-6xl font-medium leading-none text-white sm:text-7xl md:text-8xl">
							Europe
						</h1>
						<p className="mt-5 max-w-2xl font-body text-sm leading-relaxed text-white/90 sm:text-base">
							Published Airmark departures — the British Isles, Iberia, the Alps, Greece and Türkiye, the Holy Land, Iceland, the Balkans, and a Kazakhstan add-on — with the fare, dates, and day plan printed on each flyer.
						</p>
						<p className="mt-6 font-display text-2xl text-white">
							From <span className="text-[#f3a000]">USD 1,198</span> per person
						</p>
					</div>
				</div>

				<ul className="absolute inset-x-0 bottom-0 hidden border-t border-white/10 bg-[hsl(var(--navy))]/90 md:grid md:grid-cols-4">
					{['Roundtrip airfare', 'Hotel accommodation', 'Daily breakfast', 'Sightseeing tours'].map((item) => (
						<li
							key={item}
							className="px-4 py-3 text-center font-body text-[11px] font-semibold tracking-[0.14em] text-white/80 uppercase"
						>
							{item}
						</li>
					))}
				</ul>
			</header>

			<section className="bg-background" aria-labelledby="europe-catalog">
				<div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
					<div className="mx-auto max-w-2xl text-center">
						<h2 id="europe-catalog" className="font-display text-3xl text-[hsl(var(--navy))] md:text-4xl">
							Browse the flyers
						</h2>
						<p className="mt-3 font-body text-sm leading-relaxed text-muted-foreground">
							Flights, hotels, tours, and expert guides included. Open a poster to read the printed promo, or view the flyer full screen.
						</p>
					</div>

					<div className="mt-8 flex flex-wrap justify-center gap-2" role="tablist" aria-label="Filter Europe packages">
						{filters.map((item) => {
							const selected = filter === item.id;
							return (
								<button
									key={item.id}
									type="button"
									role="tab"
									aria-selected={selected}
									onClick={() => setFilter(item.id)}
									className={`min-h-11 rounded-full px-4 font-body text-[11px] font-semibold tracking-[0.08em] uppercase transition-colors active:scale-[0.98] ${
										selected
											? 'bg-[#f3a000] text-[hsl(var(--navy))]'
											: 'bg-secondary text-foreground hover:bg-secondary/70'
									}`}
								>
									{item.label}
								</button>
							);
						})}
					</div>

					{visible.length === 0 ? (
						<p className="mt-12 text-center font-body text-sm text-muted-foreground">No packages in this group yet.</p>
					) : (
						<ul className="mt-10 grid gap-8 sm:grid-cols-2 xl:grid-cols-3">
							{visible.map((pkg) => (
								<li key={pkg.id} className="flex flex-col">
									<figure className="group relative overflow-hidden rounded-2xl border-2 border-[#1d4e89] bg-white shadow-sm">
										<button
											type="button"
											onClick={() =>
												setActivePoster({
													alt: `${pkg.title} package flyer`,
													src: pkg.flyer,
													title: pkg.title,
												})
											}
											className="block w-full cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
											aria-label={`Open ${pkg.title} poster full screen`}
										>
											<img
												src={pkg.flyer}
												alt={`${pkg.title} package flyer`}
												width={800}
												height={1100}
												loading="lazy"
												className="aspect-[4/5] w-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.02]"
											/>
											<span className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-gradient-to-t from-[hsl(var(--navy))]/85 to-transparent px-4 py-3 font-body text-xs font-semibold text-white">
												<Maximize2 className="h-4 w-4" aria-hidden="true" />
												View poster
											</span>
										</button>
									</figure>

									<h3 className="mt-4 text-center font-display text-lg font-bold tracking-wide text-[hsl(var(--navy))] uppercase">
										{pkg.title}
									</h3>
									<p className="mt-3 rounded-lg bg-[#1d4e89] px-3 py-2 text-center font-body text-xs font-semibold tracking-[0.16em] text-white uppercase">
										{dayLabel(pkg.days)}
									</p>
									<ul className="mt-3 list-disc space-y-1 pl-5 font-body text-sm text-foreground/80">
										{highlights(pkg).map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
									<div className="mt-auto pt-4 text-center">
										<p className="font-body text-[11px] tracking-[0.18em] text-muted-foreground uppercase">From</p>
										<p className="font-display text-2xl text-[#e23b4a]">{pkg.price.replace('USD ', '$')}/pax</p>
										<div className="mt-3 flex flex-col gap-2 sm:flex-row sm:justify-center">
											<button
												type="button"
												onClick={() => setDetail(pkg)}
												className="inline-flex min-h-11 items-center justify-center rounded-lg border border-[#1d4e89] px-4 font-body text-xs font-semibold tracking-[0.12em] text-[#1d4e89] uppercase transition-colors hover:bg-[#1d4e89] hover:text-white active:scale-[0.98]"
											>
												See description
											</button>
											<ContactTrigger className="inline-flex min-h-11 items-center justify-center rounded-lg px-4 font-body text-xs font-semibold tracking-[0.12em] text-[#e23b4a] uppercase hover:underline">
												Enquire →
											</ContactTrigger>
										</div>
									</div>
								</li>
							))}
						</ul>
					)}
				</div>
			</section>

			<section className="border-t border-white/10 bg-[hsl(var(--navy))] text-white">
				<div className="mx-auto max-w-3xl px-6 py-16 text-center">
					<h2 className="font-editorial text-4xl md:text-5xl">Your Europe departure starts here</h2>
					<p className="mx-auto mt-4 max-w-xl font-body text-sm leading-relaxed text-white/70">
						Tell the desk which flyer and date you want. Seats, the deposit, and a written quotation are confirmed before you pay.
					</p>
					<ContactTrigger className="mt-8 inline-flex min-h-12 items-center justify-center rounded-full bg-[#f3a000] px-7 font-body text-sm font-semibold text-[hsl(var(--navy))] transition-colors hover:bg-[#ffad0a] active:scale-[0.98]">
						Contact Us
					</ContactTrigger>
				</div>
			</section>
			<Footer />

			{detail ? (
				<div
					className="fixed inset-0 z-[90] flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6"
					role="dialog"
					aria-modal="true"
					aria-labelledby="europe-detail-title"
					onClick={closeDetail}
				>
					<div
						className="flex max-h-[100dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-2xl bg-background shadow-xl sm:max-h-[90dvh] sm:rounded-2xl"
						onClick={(event) => event.stopPropagation()}
					>
						<div className="flex items-start justify-between gap-4 border-b border-border px-5 py-4">
							<div>
								<p className="font-mono text-[11px] tracking-[0.22em] text-primary uppercase">
									{detail.year} · {detail.days}
								</p>
								<h2 id="europe-detail-title" className="font-display text-2xl text-[hsl(var(--navy))]">
									{detail.title}
								</h2>
								<p className="font-body text-sm text-muted-foreground">{detail.region}</p>
							</div>
							<button
								type="button"
								onClick={closeDetail}
								className="inline-flex min-h-11 min-w-11 shrink-0 items-center justify-center rounded-full bg-secondary text-[hsl(var(--navy))]"
								aria-label="Close description"
							>
								<X className="h-5 w-5" aria-hidden="true" />
							</button>
						</div>
						<div className="overflow-y-auto px-5 py-5">
							<p className="font-display text-2xl text-[hsl(var(--navy))]">{detail.price}</p>
							<p className="font-body text-sm text-muted-foreground">{detail.priceNote}</p>
							<p className="mt-4 font-body text-sm leading-relaxed text-foreground/80">{detail.summary}</p>
							{detail.airline ? (
								<p className="mt-2 font-body text-sm">
									Airline: <strong>{detail.airline}</strong>
								</p>
							) : null}

							<h3 className="mt-6 font-display text-lg">{detail.year} travel dates</h3>
							<ul className="mt-2 flex flex-wrap gap-2">
								{detail.dates.map((date) => (
									<li key={date} className="rounded-full bg-secondary px-3 py-1.5 font-mono text-xs">
										{date}
									</li>
								))}
							</ul>

							{detail.flights ? (
								<>
									<h3 className="mt-6 font-display text-lg">Flight details</h3>
									<ul className="mt-2 space-y-1 font-mono text-sm">
										{detail.flights.map((flight) => (
											<li key={flight}>{flight}</li>
										))}
									</ul>
								</>
							) : null}

							{detail.booking ? (
								<>
									<h3 className="mt-6 font-display text-lg">Booking condition</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.booking.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</>
							) : null}

							<div className="mt-6 grid gap-6 md:grid-cols-2">
								<div>
									<h3 className="font-display text-lg">Inclusions</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.inclusions.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</div>
								<div>
									<h3 className="font-display text-lg">Exclusions</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.exclusions.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</div>
							</div>

							{detail.entrances ? (
								<>
									<h3 className="mt-6 font-display text-lg">Included entrances</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.entrances.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</>
							) : null}

							{detail.visa.length ? (
								<>
									<h3 className="mt-6 font-display text-lg">Visa requirements</h3>
									<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
										{detail.visa.map((item) => (
											<li key={item}>{item}</li>
										))}
									</ul>
								</>
							) : null}

							{detail.notes ? (
								<ul className="mt-4 flex flex-wrap gap-2">
									{detail.notes.map((note) => (
										<li key={note} className="rounded-full bg-secondary px-3 py-1 font-body text-xs">
											{note}
										</li>
									))}
								</ul>
							) : null}

							<h3 className="mt-6 font-display text-lg">Itinerary</h3>
							<ol className="mt-3 space-y-3">
								{detail.itinerary.map((day, index) => (
									<li key={`${detail.id}-${day.day}-${index}`} className="rounded-xl bg-secondary/70 p-4">
										<p className="font-mono text-[11px] tracking-[0.2em] text-primary uppercase">
											{day.day}
											{day.meals ? ` · ${day.meals}` : ''}
										</p>
										<p className="font-display text-lg">{day.title}</p>
										<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm">
											{day.stops.map((stop, stopIndex) => (
												<li key={`${day.day}-${stopIndex}`}>{stop}</li>
											))}
										</ul>
										{day.note ? <p className="mt-2 font-body text-sm text-muted-foreground">{day.note}</p> : null}
									</li>
								))}
							</ol>

							<h3 className="mt-6 font-display text-lg">For inquiries</h3>
							<ul className="mt-3 flex flex-wrap gap-3">
								{detail.contacts.map((contact) => (
									<li key={`${detail.id}-${contact.value}`}>
										<a
											href={contact.href}
											className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 font-body text-sm hover:border-primary hover:text-primary"
										>
											{contact.label === 'Mobile' ? <Phone className="h-4 w-4" aria-hidden="true" /> : null}
											{contact.value}
										</a>
									</li>
								))}
							</ul>
						</div>
						<div className="flex flex-col gap-2 border-t border-border px-5 py-4 sm:flex-row sm:justify-end">
							<button
								type="button"
								onClick={() =>
									setActivePoster({
										alt: `${detail.title} package flyer`,
										src: detail.flyer,
										title: detail.title,
									})
								}
								className="inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-border px-5 font-body text-sm font-semibold"
							>
								<Maximize2 className="h-4 w-4" aria-hidden="true" />
								View poster
							</button>
							<ContactTrigger className="inline-flex min-h-11 items-center justify-center rounded-full bg-[#f3a000] px-5 font-body text-sm font-semibold text-[hsl(var(--navy))]">
								Enquire
							</ContactTrigger>
						</div>
					</div>
				</div>
			) : null}

			{activePoster ? (
				<div
					className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4"
					role="dialog"
					aria-modal="true"
					aria-label={activePoster.title}
					onClick={closeLightbox}
				>
					<button
						type="button"
						onClick={closeLightbox}
						className="absolute right-4 top-4 inline-flex min-h-11 min-w-11 items-center justify-center rounded-full bg-white text-[hsl(var(--navy))]"
						aria-label="Close poster"
					>
						<X className="h-5 w-5" aria-hidden="true" />
					</button>
					<img
						src={activePoster.src}
						alt={activePoster.alt}
						className="max-h-[92dvh] w-auto max-w-full object-contain"
						onClick={(event) => event.stopPropagation()}
					/>
				</div>
			) : null}
		</div>
	);
}
