import { useEffect, useState, useCallback } from 'react';
import { Globe, Plane, ArrowRight } from 'lucide-react';
import { heroSlides } from '@/data/team';

const stats = [
	{ value: '50+', label: 'Destinations' },
	{ value: '12K+', label: 'Happy Travelers' },
	{ value: '98%', label: 'Satisfaction' },
];

const SLIDE_INTERVAL = 7000;

export function Hero() {
	const [active, setActive] = useState(0);
	const count = heroSlides.length;

	const go = useCallback(
		(next: number) => setActive((prev) => (next + count) % count),
		[count],
	);

	useEffect(() => {
		const id = setInterval(() => setActive((p) => (p + 1) % count), SLIDE_INTERVAL);
		return () => clearInterval(id);
	}, [count]);

	return (
		<section id="top" className="relative w-full min-h-[100dvh] min-h-[700px] overflow-hidden">
			{/* Slider images */}
			<div className="absolute inset-0">
				{heroSlides.map((slide, i) => (
					<div
						key={slide.image}
						aria-hidden={i !== active}
						className={`absolute inset-0 w-full h-full overflow-hidden transition-all duration-[3200ms] ease-in-out ${
							i === active
								? 'opacity-100 scale-100 blur-0'
								: 'opacity-0 scale-105 blur-sm'
						}`}
					>
						<img
							src={slide.image}
							alt={slide.caption}
							className={`w-full h-full object-cover transition-transform duration-[12000ms] ease-out ${
								i === active ? 'scale-110' : 'scale-100'
							}`}
						/>
					</div>
				))}
				<div className="absolute inset-0 bg-gradient-to-b from-[hsl(var(--navy))]/45 via-[hsl(var(--navy))]/25 to-[hsl(var(--navy))]/60" />
				<div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--navy))]/40 via-transparent to-[hsl(var(--navy))]/25" />
			</div>

			<div className="relative z-10 flex flex-col items-center justify-center h-full min-h-[100dvh] px-6 text-center pt-20">
				<h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.05] max-w-5xl text-balance">
					Your Passport to <span className="text-primary">Possibilities</span>
				</h1>
				<p className="mt-6 font-body text-base md:text-lg text-white/80 max-w-xl leading-relaxed">
					Experience world-class destinations with precision-crafted itineraries. Every flight,
					every stay — engineered for excellence.
				</p>

				<div className="mt-10 flex flex-col sm:flex-row gap-3">
					<a
						href="/flights"
						className="bg-primary text-[hsl(var(--navy))] font-body font-semibold text-base md:text-lg pl-7 md:pl-8 pr-3 py-3 rounded-full transition-all duration-300 flex items-center gap-4 border border-white/25 shadow-lg hover:scale-105 hover:-translate-y-0.5 hover:shadow-2xl hover:shadow-primary/40"
					>
						<span>International Flights</span>
						<span className="h-9 w-9 md:h-10 md:w-10 rounded-full bg-[hsl(var(--navy-soft))] flex items-center justify-center shrink-0">
							<Globe className="h-5 w-5 text-white" />
						</span>
					</a>
					<a
						href="/domestic"
						className="bg-[hsl(var(--navy-soft))] text-white font-body font-semibold text-base md:text-lg pl-7 md:pl-8 pr-3 py-3 rounded-full transition-all duration-300 flex items-center gap-4 border border-white/25 shadow-lg hover:scale-105 hover:-translate-y-0.5"
					>
						<span>Domestic Flights</span>
						<span className="h-9 w-9 md:h-10 md:w-10 rounded-full bg-primary flex items-center justify-center shrink-0">
							<Plane className="h-5 w-5 text-[hsl(var(--navy))]" />
						</span>
					</a>
				</div>

				<div className="mt-12 flex flex-wrap justify-center gap-8 md:gap-16">
					{stats.map((s) => (
						<div key={s.label} className="text-center">
							<div className="font-display text-2xl md:text-3xl font-bold text-primary">{s.value}</div>
							<div className="font-mono text-[10px] md:text-xs tracking-[0.2em] text-white uppercase mt-1">
								{s.label}
							</div>
						</div>
					))}
				</div>
			</div>

			{/* Slider dots */}
			<div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-10 hidden sm:flex gap-2">
				{heroSlides.map((slide, i) => (
					<button
						key={slide.image}
						aria-label={`Show slide ${i + 1}: ${slide.caption}`}
						aria-current={i === active}
						onClick={() => go(i)}
						className={`rounded-full transition-all duration-300 h-2 ${
							i === active ? 'w-6 bg-primary' : 'w-2 bg-white/40 hover:bg-white/70'
						}`}
					/>
				))}
			</div>

			<div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 hidden sm:flex">
				<div className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center pt-2">
					<div className="w-1.5 h-3 bg-primary rounded-full animate-bounce" />
				</div>
			</div>

			<a
				href="#destinations"
				className="sr-only"
				aria-label="Explore destinations"
			>
				<ArrowRight />
			</a>
		</section>
	);
}
