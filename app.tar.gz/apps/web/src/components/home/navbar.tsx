import { useEffect, useState } from 'react';
import { Globe, Menu, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';

declare global {
	interface Window {
		google?: {
			translate?: {
				TranslateElement?: new (
					config: { pageLanguage: string; includedLanguages?: string },
					el: string,
				) => void;
			};
		};
		googleTranslateElementInit?: () => void;
	}
}

const links = [
	{ label: 'Home', href: '/#top' },
	{ label: 'Tour Packages', href: '/#destinations' },
	{ label: 'Visa', href: '/visa' },
	{ label: 'Testimonials', href: '/testimonials' },
	{ label: 'Events', href: '/events' },
	{ label: 'News', href: '/news' },
	{ label: 'About Us', href: '/about' },
	{ label: 'FAQ', href: '/faq' },
];

export function Navbar() {
	const [open, setOpen] = useState(false);

	useEffect(() => {
		const labelSelect = () => {
			const languageSelect = document.querySelector<HTMLSelectElement>(
				'#google_translate_element select.goog-te-combo',
			);
			if (!languageSelect?.options.length) return;
			const first = languageSelect.options[0];
			if (first && first.value === '' && first.text !== 'English') {
				first.text = 'English';
				first.label = 'English';
			}
			languageSelect.setAttribute('aria-label', 'Choose language');
		};

		if (!document.getElementById('google-translate-script')) {
			window.googleTranslateElementInit = () => {
				const Ctor = window.google?.translate?.TranslateElement;
				if (!Ctor) return;
				new Ctor(
					{
						pageLanguage: 'en',
						includedLanguages: 'ar,zh-CN,ja,ko,es,vi',
					},
					'google_translate_element',
				);
				labelSelect();
			};
			const script = document.createElement('script');
			script.id = 'google-translate-script';
			script.src =
				'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
			script.async = true;
			document.body.appendChild(script);
		}

		const host = document.getElementById('google_translate_element');
		const observer = new MutationObserver(labelSelect);
		if (host) observer.observe(host, { childList: true, subtree: true });
		labelSelect();
		const timer = window.setInterval(labelSelect, 400);
		const stop = window.setTimeout(() => window.clearInterval(timer), 8000);
		return () => {
			observer.disconnect();
			window.clearInterval(timer);
			window.clearTimeout(stop);
		};
	}, []);

	return (
		<header className="fixed inset-x-0 top-0 z-50 h-[68px] bg-[linear-gradient(105deg,#182642_0%,#172c52_58%,#1b3562_100%)] shadow-[0_2px_12px_rgba(4,12,32,0.14)]">
			<nav
				className="mx-auto flex h-full max-w-[1320px] items-center justify-between px-4 sm:px-8 lg:px-10"
				aria-label="Main navigation"
			>
				<a href="/" className="flex shrink-0 items-center" aria-label="Airmark Tours home">
					<img
						src="https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/5ba0a291fc149a106f47489235da9b13.png"
						alt="Airmark Tour and Dev't Inc."
						className="h-6 w-auto brightness-0 invert sm:h-8"
					/>
				</a>

				<div className="hidden items-center gap-5 xl:flex 2xl:gap-6">
					{links.map((link) => (
						<a
							key={link.label}
							href={link.href}
							className="whitespace-nowrap font-body text-[11px] font-semibold uppercase tracking-[0.025em] text-white/85 transition-colors hover:text-white 2xl:text-xs"
						>
							{link.label}
						</a>
					))}
				</div>

				<div className="flex shrink-0 items-center gap-2 sm:gap-3 xl:gap-7">
					<div id="google_translate_element" className="translate-wrap">
						<Globe className="h-4 w-4 shrink-0" aria-hidden="true" />
					</div>
					<ContactTrigger className="hidden min-h-9 items-center justify-center whitespace-nowrap rounded-full bg-[#f3a000] px-5 font-body text-xs font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98] xl:inline-flex">
						Contact Us
					</ContactTrigger>
					<button
						type="button"
						className="inline-flex h-11 w-11 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10 xl:hidden"
						onClick={() => setOpen((value) => !value)}
						aria-label={open ? 'Close menu' : 'Open menu'}
						aria-expanded={open}
						aria-controls="mobile-navigation"
					>
						{open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
					</button>
				</div>
			</nav>

			{open && (
				<div
					id="mobile-navigation"
					className="absolute inset-x-0 top-full border-t border-white/10 bg-[#172c52] shadow-xl xl:hidden"
				>
					<nav className="mx-auto flex max-w-[1320px] flex-col px-5 py-3 sm:px-8" aria-label="Mobile navigation">
						{links.map((link) => (
							<a
								key={link.label}
								href={link.href}
								onClick={() => setOpen(false)}
								className="border-b border-white/10 py-3 font-body text-xs font-semibold uppercase tracking-wide text-white/85 transition-colors hover:text-white last:border-0"
							>
								{link.label}
							</a>
						))}
						<ContactTrigger
							onClick={() => setOpen(false)}
							className="mt-3 flex min-h-11 items-center justify-center rounded-full bg-[#f3a000] px-5 font-body text-sm font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98]"
						>
							Contact Us
						</ContactTrigger>
					</nav>
				</div>
			)}
		</header>
	);
}
