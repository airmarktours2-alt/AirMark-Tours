import { useState, useEffect, useRef, useCallback } from 'react';
import { Plane, MapPin, Users, Award, ChevronLeft, ChevronRight } from 'lucide-react';
import { aboutImage, team } from '@/data/team';

const milestones = [
	{ icon: Plane, value: '10+', label: 'Years of Service' },
	{ icon: MapPin, value: '50+', label: 'Destinations' },
	{ icon: Users, value: '12,000+', label: 'Travelers Served' },
	{ icon: Award, value: '15+', label: 'Industry Awards' },
];

const AUTOPLAY_MS = 5000;

export function About() {
	const [active, setActive] = useState(1);
	const [paused, setPaused] = useState(false);
	const count = team.length;
	const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

	const go = useCallback(
		(dir: number) => setActive((i) => (i + dir + count) % count),
		[count],
	);

	// Autoplay: advance every AUTOPLAY_MS when not paused.
	useEffect(() => {
		if (paused || count <= 1) return;
		timerRef.current = setTimeout(() => {
			setActive((i) => (i + 1) % count);
		}, AUTOPLAY_MS);
		return () => {
			if (timerRef.current) clearTimeout(timerRef.current);
		};
	}, [active, paused, count]);

	return (
		<section id="about" className="relative py-24 md:py-32 bg-background overflow-hidden">
			<div className="max-w-7xl mx-auto px-6 lg:px-8">
				<div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
					<div className="relative">
						<div className="rounded-2xl overflow-hidden aspect-[4/3]">
							<img src={aboutImage} alt="Airmark aerial view" className="w-full h-full object-cover" />
						</div>
						<div className="absolute -bottom-6 -right-4 md:right-6 bg-card border border-border/50 rounded-2xl p-6 shadow-2xl">
							<p className="font-display text-3xl font-bold text-primary">98%</p>
							<p className="font-mono text-[10px] tracking-[0.2em] text-muted-foreground uppercase mt-1">
								Client Satisfaction
							</p>
						</div>
					</div>

					<div>
						<span className="font-mono text-xs tracking-[0.3em] text-primary uppercase">About Airmark</span>
						<h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mt-4 leading-tight">
							Navigating Dreams Across the Globe Since 2016
						</h2>
						<p className="font-body text-muted-foreground mt-6 text-base leading-relaxed">
							Airmark Tour and Dev't Inc. was founded with a singular mission: to transform travel from a
							transaction into an unforgettable experience. With over a decade of expertise, we've built a
							reputation for precision, reliability, and extraordinary service.
						</p>
						<p className="font-body text-muted-foreground mt-4 text-base leading-relaxed">
							From intimate getaways to grand expeditions, our team of seasoned travel architects designs
							every itinerary with meticulous care — ensuring every moment of your journey is as remarkable
							as the destination itself.
						</p>

						<div className="grid grid-cols-2 gap-6 mt-10">
							{milestones.map((m) => (
								<div key={m.label} className="flex items-start gap-3">
									<div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
										<m.icon className="h-5 w-5 text-primary" />
									</div>
									<div>
										<p className="font-display text-xl font-bold text-foreground">{m.value}</p>
										<p className="font-mono text-[10px] tracking-[0.15em] text-muted-foreground uppercase">
											{m.label}
										</p>
									</div>
								</div>
							))}
						</div>
					</div>
				</div>

				<div className="mt-16">
					<div className="text-center mb-10">
						<span className="font-mono text-xs tracking-[0.3em] text-primary uppercase">Our People</span>
						<h3 className="font-display text-2xl md:text-4xl font-bold text-foreground mt-3">Meet the Team</h3>
					</div>

					<div
						className="relative flex items-center justify-center gap-3 md:gap-4"
						onMouseEnter={() => setPaused(true)}
						onMouseLeave={() => setPaused(false)}
						onFocus={() => setPaused(true)}
						onBlur={(e) => {
							if (!e.currentTarget.contains(e.relatedTarget as Node)) setPaused(false);
						}}
					>
						<button
							onClick={() => go(-1)}
							onFocus={() => setPaused(true)}
							className="z-10 h-10 w-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center hover:bg-primary/20 transition-colors shrink-0"
							aria-label="Previous"
						>
							<ChevronLeft className="h-5 w-5 text-primary" />
						</button>

						<div className="flex items-center gap-3 md:gap-4 overflow-hidden">
							{team.map((member, i) => {
								const offset = (i - active + count) % count;
								const isCenter = offset === 0;
								const isSide = offset === 1 || offset === count - 1;
								if (!isCenter && !isSide) return null;
								return (
									<div
										key={member.name}
										className={`relative rounded-2xl overflow-hidden shrink-0 transition-all duration-300 ${
											isCenter
												? 'shadow-2xl border border-primary/30 w-[300px] h-[420px] sm:w-[440px] sm:h-[600px]'
												: 'border border-white/10 shadow-lg w-[180px] h-[300px] sm:w-[300px] sm:h-[420px] hidden sm:block opacity-60'
										}`}
									>
										<img
											src={member.image}
											alt={member.name}
											className="w-full h-full object-cover object-top"
										/>
										{isCenter && (
											<div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[hsl(var(--navy))]/95 to-transparent px-4 py-4">
												<p className="font-display text-lg font-bold text-white">{member.name}</p>
												<p className="font-body text-xs text-primary mt-0.5">{member.role}</p>
											</div>
										)}
									</div>
								);
							})}
						</div>

						<button
							onClick={() => go(1)}
							onFocus={() => setPaused(true)}
							className="z-10 h-10 w-10 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center hover:bg-primary/20 transition-colors shrink-0"
							aria-label="Next"
						>
							<ChevronRight className="h-5 w-5 text-primary" />
						</button>
					</div>

					<div className="flex justify-center gap-2 mt-6 flex-wrap">
						{team.map((_, i) => (
							<button
								key={i}
								onClick={() => setActive(i)}
								onFocus={() => setPaused(true)}
								aria-label={`Go to slide ${i + 1}`}
								className={`rounded-full transition-all duration-300 h-2 ${
									i === active ? 'w-6 bg-primary' : 'w-2 bg-foreground/15'
								}`}
							/>
						))}
					</div>
					<p className="text-center font-mono text-xs text-muted-foreground mt-3">
						{active + 1} / {count}
					</p>
				</div>
			</div>
		</section>
	);
}
