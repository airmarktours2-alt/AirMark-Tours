import { Link } from 'react-router';
import { ArrowRight } from 'lucide-react';
import { destinations } from '@/data/destinations';

export function Destinations() {
	return (
		<section id="destinations" className="relative py-24 md:py-32 bg-background">
			<div className="max-w-7xl mx-auto px-6 lg:px-8">
				<div className="text-center mb-16">
					<span className="font-mono text-xs tracking-[0.3em] text-primary uppercase">Destination Matrix</span>
					<h2 className="font-display text-4xl md:text-6xl font-bold text-foreground mt-4">Explore the World</h2>
					<p className="font-body text-muted-foreground mt-4 max-w-lg mx-auto text-base leading-relaxed">
						Handpicked destinations where luxury meets adventure. Every journey mapped with precision.
					</p>
				</div>

				<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
					{destinations.map((d) => {
						const card = (
							<div
								className="group relative rounded-2xl overflow-hidden cursor-pointer aspect-[16/11]"
								translate={d.name === 'Europe' ? 'no' : undefined}
							>
								<img
									src={d.image}
									alt={d.name}
									loading="lazy"
									className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
								/>
								<div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--navy))] via-[hsl(var(--navy))]/70 to-transparent" />
								<span className="absolute top-4 right-4 font-mono text-6xl font-bold text-white/[0.06] leading-none select-none pointer-events-none">
									{d.code}
								</span>
								<div className="absolute bottom-0 left-0 right-0 z-10 p-7">
									<div className="flex items-end justify-between gap-4">
										<div className="min-w-0">
											<p className="font-mono text-[11px] tracking-[0.22em] text-primary uppercase truncate">
												{d.name === 'Europe' ? 'CDG EUROPE' : `${d.code} · ${d.region}`}
											</p>
											<h3 className="font-display text-3xl font-bold text-white mt-1">{d.name}</h3>
										</div>
										<div className="text-right shrink-0">
											<p className="font-mono text-[11px] text-muted-foreground tracking-widest uppercase">Package</p>
											<p className="font-display text-lg font-normal text-white whitespace-nowrap">
												<span className="text-white">From </span>
												{d.price}
											</p>
										</div>
									</div>
									<div
										className={`notranslate mt-4 flex items-center gap-2 transition-all duration-300 ${
											d.name === 'Europe'
												? 'opacity-100'
												: 'opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0'
										}`}
										translate="no"
									>
										<span className="text-sm font-body text-white font-medium">
											{d.name === 'Europe'
												? 'Book Seat'
												: d.name === 'South Korea' || d.name === 'Japan' || d.name === 'China' || d.name === 'Vietnam' || d.name === 'Philippines' || d.name === 'Taiwan' || d.name === 'Hong Kong' || d.name === 'Cruise'
													? 'View packages'
													: 'Book Seat'}
										</span>
										<ArrowRight className="h-4 w-4 text-primary shrink-0" />
									</div>
								</div>
							</div>
						);

						const packagePath =
							d.name === 'Japan'
								? '/japan'
								: d.name === 'China'
									? '/china'
									: d.name === 'South Korea'
										? '/korea'
										: d.name === 'Vietnam'
											? '/vietnam'
											: d.name === 'Europe'
												? '/europe'
												: d.name === 'Philippines'
													? '/philippines'
													: d.name === 'Taiwan'
														? '/taiwan'
														: d.name === 'Hong Kong'
															? '/hong-kong'
															: d.name === 'Cruise'
																? '/cruise'
																: '';
						if (packagePath) {
							return (
								<Link key={d.name} to={packagePath} className="block">
									{card}
								</Link>
							);
						}

						return <div key={d.name}>{card}</div>;
					})}
				</div>
			</div>
		</section>
	);
}
