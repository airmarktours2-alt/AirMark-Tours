import { Facebook, Instagram, MapPin, Phone } from 'lucide-react';
import { Link } from 'react-router';
import { deskContacts, office } from '@/data/contacts';

function BrandMark() {
	return (
		<img
			src="https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/5ba0a291fc149a106f47489235da9b13.png"
			alt="Airmark Tour and Dev't Inc."
			className="h-14 w-auto brightness-0 invert"
		/>
	);
}

export function Footer() {
	return (
		<footer className="bg-[hsl(var(--navy-deep))] text-white">
			<div className="mx-auto max-w-7xl px-6 py-14 lg:px-10 lg:py-16">
				<div className="grid grid-cols-1 gap-12 md:grid-cols-12 md:gap-8">
					<div className="md:col-span-4">
						<BrandMark />
						<p className="mt-8 max-w-xs font-body text-[15px] leading-relaxed text-white/75">
							Engineering extraordinary travel experiences since 2014.
							Every journey is a precision-crafted expedition into the extraordinary.
						</p>
						<div className="mt-8 flex items-center gap-3">
							{[
								{ Icon: Facebook, label: 'Facebook', href: 'https://www.facebook.com/share/18LZQZPqy9/?mibextid=wwXIfr' },
								{ Icon: Instagram, label: 'Instagram', href: 'https://www.instagram.com/airmarktours?stkn=MWNvMmoyMW1uMXc3Nw==' }
							].map(({ Icon, label, href }) => (
								<a
									key={label}
									href={href}
									target="_blank"
									rel="noreferrer"
									aria-label={label}
									className="flex h-11 w-11 items-center justify-center rounded-full border border-white/25 text-white/80 transition-colors hover:border-primary hover:text-primary"
								>
									<Icon className="h-4 w-4" strokeWidth={1.75} />
								</a>
							))}
							<a
								href="https://www.tiktok.com/@airmarktours?_r=1&_t=ZS-9ALmIHFWMh0"
								target="_blank"
								rel="noreferrer"
								aria-label="Twitter"
								className="flex h-11 w-11 items-center justify-center rounded-full border border-white/25 text-[13px] font-semibold text-white/80 transition-colors hover:border-primary hover:text-primary"
							>
								T
							</a>
						</div>
					</div>

					<div className="md:col-span-3">
						<p className="flex items-center gap-2 font-display text-[11px] font-semibold tracking-[0.18em] text-primary">
							<MapPin className="h-3.5 w-3.5" strokeWidth={2} />
							OUR ADDRESS
						</p>
						<p className="mt-5 font-body text-sm font-semibold text-white">{office.label}</p>
						<p className="mt-1 max-w-[16rem] font-body text-sm leading-relaxed text-white/70">
							{office.address}
						</p>
					</div>

					<div className="md:col-span-5">
						<p className="flex items-center gap-2 font-display text-[11px] font-semibold tracking-[0.18em] text-primary">
							<Phone className="h-3.5 w-3.5" strokeWidth={2} />
							CONTACT DETAILS
						</p>
						<ul className="mt-5 space-y-3.5">
							{deskContacts.map((c) => (
								<li key={c.email}>
									<p className="font-body text-[13px] text-white/55">{c.regions}</p>
									<p className="font-body text-sm font-semibold text-white">
										{c.name} – {c.phone} /{' '}
										<a href={`mailto:${c.email}`} className="hover:text-primary">
											{c.email}
										</a>
									</p>
								</li>
							))}
						</ul>
					</div>
				</div>

				<div className="mt-14 border-t border-white/15 pt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
					<p className="font-body text-[11px] tracking-[0.12em] text-white/45">
						© 2026 AIRMARK TOUR AND DEV&apos;T INC. ALL RIGHTS RESERVED.
					</p>
					<nav className="flex flex-wrap gap-x-6 gap-y-2">
						<Link to="/privacy" className="font-body text-[11px] tracking-[0.14em] text-white/55 hover:text-primary">
							PRIVACY POLICY
						</Link>
						<Link to="/terms" className="font-body text-[11px] tracking-[0.14em] text-white/55 hover:text-primary">
							TERMS OF SERVICE
						</Link>
						<Link to="/cookies" className="font-body text-[11px] tracking-[0.14em] text-white/55 hover:text-primary">
							COOKIE POLICY
						</Link>
					</nav>
				</div>
			</div>
		</footer>
	);
}
