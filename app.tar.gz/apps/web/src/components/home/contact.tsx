import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react';

const details = [
	{ icon: Mail, label: 'Email', value: 'info@airmarktours.online' },
	{ icon: Phone, label: 'Phone', value: '+63 917 000 0000' },
	{ icon: MapPin, label: 'Office', value: 'Manila, Philippines' },
	{ icon: Clock, label: 'Hours', value: 'Mon–Sat, 9am–6pm' },
];

export function Contact() {
	return (
		<section id="contact" className="relative py-24 md:py-32 bg-[hsl(var(--navy))] overflow-hidden">
			<div className="absolute inset-0 bg-gradient-to-b from-[hsl(var(--navy-deep))] via-[hsl(var(--navy))] to-[hsl(var(--navy-deep))]" />
			<div className="relative max-w-6xl mx-auto px-6 lg:px-8">
				<div className="text-center mb-16">
					<span className="font-mono text-xs tracking-[0.3em] text-primary uppercase">Get in Touch</span>
					<h2 className="font-display text-3xl md:text-5xl font-bold text-white mt-4">
						Start Your Journey Today
					</h2>
					<p className="font-body text-white/60 mt-4 max-w-lg mx-auto text-base leading-relaxed">
						Tell us where you want to go. Our travel architects will craft an itinerary built around you.
					</p>
				</div>

				<div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
					<div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
						{details.map((d) => (
							<div
								key={d.label}
								className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm"
							>
								<div className="h-10 w-10 rounded-lg bg-primary/15 flex items-center justify-center mb-4">
									<d.icon className="h-5 w-5 text-primary" />
								</div>
								<p className="font-mono text-[10px] tracking-[0.2em] text-white/40 uppercase">{d.label}</p>
								<p className="font-body text-white text-sm mt-1">{d.value}</p>
							</div>
						))}
					</div>

					<form className="bg-white/5 border border-white/10 rounded-2xl p-8 backdrop-blur-sm space-y-5">
						<div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
							<div>
								<label className="font-mono text-[10px] tracking-[0.2em] text-white/50 uppercase">Name</label>
								<input
									type="text"
									placeholder="Your name"
									className="mt-2 w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 font-body text-sm focus:outline-none focus:border-primary transition-colors"
								/>
							</div>
							<div>
								<label className="font-mono text-[10px] tracking-[0.2em] text-white/50 uppercase">Email</label>
								<input
									type="email"
									placeholder="you@email.com"
									className="mt-2 w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 font-body text-sm focus:outline-none focus:border-primary transition-colors"
								/>
							</div>
						</div>
						<div>
							<label className="font-mono text-[10px] tracking-[0.2em] text-white/50 uppercase">Destination</label>
							<input
								type="text"
								placeholder="Where would you like to go?"
								className="mt-2 w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 font-body text-sm focus:outline-none focus:border-primary transition-colors"
							/>
						</div>
						<div>
							<label className="font-mono text-[10px] tracking-[0.2em] text-white/50 uppercase">Message</label>
							<textarea
								rows={4}
								placeholder="Tell us about your travel plans..."
								className="mt-2 w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder:text-white/30 font-body text-sm focus:outline-none focus:border-primary transition-colors resize-none"
							/>
						</div>
						<button
							type="button"
							className="w-full bg-primary text-[hsl(var(--navy))] font-body font-semibold py-3.5 rounded-lg flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors"
						>
							Send Inquiry
							<Send className="h-4 w-4" />
						</button>
					</form>
				</div>
			</div>
		</section>
	);
}
