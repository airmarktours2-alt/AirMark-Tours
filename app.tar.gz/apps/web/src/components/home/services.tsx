import { services } from '@/data/services';

export function Services() {
	return (
		<section id="services" className="py-24 md:py-32 bg-background">
			<div className="max-w-6xl mx-auto px-6 lg:px-8">
				<div className="text-center mb-16">
					<h2 className="font-display text-3xl md:text-5xl font-bold text-foreground">
						Our Amazing <span className="italic text-primary">Services</span>
					</h2>
					<p className="font-body text-muted-foreground mt-4 max-w-lg mx-auto text-base leading-relaxed">
						Let us take the stress out of travel. From flights to accommodations, we'll help you plan the
						perfect trip — every step of the way.
					</p>
				</div>

				<div className="grid grid-cols-1 md:grid-cols-3 border border-border/50 rounded-2xl overflow-hidden">
					{services.map((s) => (
						<div
							key={s.title}
							className="p-8 border-border/50 [&:not(:nth-child(3n+1))]:border-l md:[&:nth-child(n+4)]:border-t"
						>
							<div className="h-11 w-11 rounded-lg bg-primary/10 flex items-center justify-center mb-6">
								<s.icon className="h-5 w-5 text-primary" />
							</div>
							<h3 className="font-display text-lg font-semibold text-foreground mb-2">{s.title}</h3>
							<p className="font-body text-sm text-muted-foreground leading-relaxed">{s.description}</p>
						</div>
					))}
				</div>
			</div>
		</section>
	);
}
