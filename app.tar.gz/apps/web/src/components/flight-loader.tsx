import { useEffect, useState } from 'react';
import { useNavigation } from 'react-router';
import { Plane } from 'lucide-react';

/**
 * Airplane-themed loading experience:
 *  - A full-screen splash shown on first paint that fades out once the page is
 *    interactive (or after a short fallback timeout).
 *  - A thin top progress bar with a flying airplane that appears during route
 *    navigation transitions.
 *
 * The custom airplane cursor itself is handled in CSS (see `index.css`) and is
 * only applied on hover-capable, fine-pointer devices — touch devices keep the
 * native cursor.
 */
export function FlightLoader() {
	const [showSplash, setShowSplash] = useState(true);
	const navigation = useNavigation();
	const navigating = navigation.state !== 'idle';

	// Hide the initial splash once the window has fully loaded. A fallback
	// timeout guarantees it disappears even if the `load` event already fired.
	useEffect(() => {
		let hide: number | undefined;
		const dismiss = () => setShowSplash(false);

		if (document.readyState === 'complete') {
			hide = window.setTimeout(dismiss, 900);
		} else {
			window.addEventListener('load', dismiss, { once: true });
			// Safety net: never let the splash linger beyond 2.5s.
			hide = window.setTimeout(dismiss, 2500);
		}

		return () => {
			window.removeEventListener('load', dismiss);
			if (hide) window.clearTimeout(hide);
		};
	}, []);

	return (
		<>
			{showSplash && (
				<div className="flight-splash" role="status" aria-label="Loading Airmark Tours" aria-live="polite">
					<div className="flight-splash__scene">
						<svg
							className="flight-splash__route"
							viewBox="0 0 300 90"
							preserveAspectRatio="none"
							aria-hidden="true"
						>
							<path
								id="flight-path"
								className="flight-splash__path"
								d="M10 75 C 70 75, 90 15, 150 15 S 230 75, 290 30"
							/>
							<g className="flight-splash__plane">
								<g transform="rotate(45 13 13)">
									<Plane size={26} color="#f3a000" strokeWidth={1.6} />
								</g>
								<animateMotion
									dur="1.8s"
									repeatCount="indefinite"
									rotate="auto"
									keyPoints="0;1"
									keyTimes="0;1"
									calcMode="spline"
									keySplines="0.4 0 0.2 1"
								>
									<mpath href="#flight-path" />
								</animateMotion>
							</g>
						</svg>
						<div className="flight-splash__brand">Airmark Tours</div>
						<div className="flight-splash__dots" aria-hidden="true">
							<span />
							<span />
							<span />
						</div>
					</div>
				</div>
			)}

			{navigating && (
				<div
					className="flight-progress"
					style={{ width: '70vw', opacity: 1 }}
					role="status"
					aria-label="Navigating"
				>
					<div className="flight-progress__bar" style={{ width: '100%' }} />
					<Plane className="flight-progress__plane" size={16} aria-hidden="true" />
				</div>
			)}
		</>
	);
}
