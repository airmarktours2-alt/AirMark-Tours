import { useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, ChevronDown } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { faqHero, faqSections } from '@/data/faq';

export function FaqPage() {
	const [openId, setOpenId] = useState<string | null>(null);

	return (
		<div className="min-h-screen bg-[#f6f7fb] text-[#152033]">
			<Navbar />
			<header className="relative min-h-[52dvh] overflow-hidden">
				<img
					src={faqHero}
					alt="Airplane wing above layered clouds at sunrise"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(10,25,47,0.55)_0%,rgba(10,25,47,0.38)_42%,rgba(10,25,47,0.82)_100%)]" />
				<div className="relative mx-auto flex min-h-[52dvh] max-w-[860px] flex-col px-4 pt-[92px] pb-10 sm:px-8">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>
					<div className="flex flex-1 flex-col justify-end pb-2 pt-12">
						<p className="font-body text-[11px] font-semibold tracking-[0.28em] text-[#f3a000] uppercase">
							Before you fly
						</p>
						<h1 className="mt-3 font-editorial text-5xl leading-[1.05] text-white sm:text-6xl">FAQ</h1>
						<p className="mt-4 max-w-xl font-body text-sm leading-relaxed text-white/80 sm:text-base">
							Answers on booking, payments, visa assistance, and tour packages. Specific terms always depend on the trip — confirm the details that apply to you with Airmark.
						</p>
					</div>
				</div>
			</header>

			<main className="relative">
				<div
					className="pointer-events-none absolute inset-0 opacity-[0.09]"
					style={{
						backgroundImage: `url(${faqHero})`,
						backgroundSize: 'cover',
						backgroundPosition: 'center',
					}}
					aria-hidden="true"
				/>
				<div className="relative mx-auto max-w-[860px] px-4 py-12 sm:px-8 sm:py-16">
					{faqSections.map((section) => (
						<section key={section.id} id={section.id} className="mb-12 scroll-mt-24 last:mb-0">
							<h2 className="flex items-center gap-3 font-editorial text-[1.65rem] text-[#152033] sm:text-[1.85rem]">
								<span className="h-7 w-[5px] shrink-0 rounded-full bg-[#f3a000]" aria-hidden="true" />
								{section.title}
							</h2>
							<div className="mt-5 flex flex-col gap-3">
								{section.items.map((item) => {
									const id = `${section.id}-${item.question}`;
									const open = openId === id;
									return (
										<div
											key={item.question}
											className="overflow-hidden rounded-2xl border border-[#e6eaf1] bg-white shadow-[0_1px_2px_rgba(21,32,51,0.04)]"
										>
											<button
												type="button"
												className="flex min-h-[56px] w-full items-center justify-between gap-4 px-5 py-4 text-left font-body text-[15px] font-medium text-[#1a2740] transition-colors hover:bg-[#fafbfd]"
												aria-expanded={open}
												onClick={() => setOpenId(open ? null : id)}
											>
												<span>{item.question}</span>
												<ChevronDown
													className={`h-4 w-4 shrink-0 text-[#8b97a8] transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
													aria-hidden="true"
												/>
											</button>
											{open ? (
												<div className="border-t border-[#eef1f6] px-5 py-4 font-body text-sm leading-relaxed text-[#4d5d74]">
													{item.answer}
												</div>
											) : null}
										</div>
									);
								})}
							</div>
						</section>
					))}
					<p className="mt-4 font-body text-sm text-[#5c6b82]">
						Still deciding?{' '}
						<ContactTrigger className="inline font-semibold text-[#152033] underline decoration-[#f3a000] underline-offset-4">
							Contact Airmark
						</ContactTrigger>{' '}
						and we will confirm availability, documents, and the terms for your trip.
					</p>
				</div>
			</main>
			<Footer />
		</div>
	);
}
