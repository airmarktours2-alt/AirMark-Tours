import { useState } from 'react';
import { ArrowLeft, Calendar, CheckCircle2, MapPin, Minus, Plane, Plus, Send, Users } from 'lucide-react';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import {
	domesticCabinClasses,
	domesticDestinations,
	domesticHero,
	domesticSteps,
	type DomesticCabinClass,
} from '@/data/domestic-flights';

type TripType = 'round' | 'oneway';

type FormState = {
	trip: TripType;
	cabin: DomesticCabinClass;
	from: string;
	to: string;
	depart: string;
	ret: string;
	adults: number;
	children: number;
	infants: number;
	name: string;
	email: string;
	phone: string;
	notes: string;
};

const initial: FormState = {
	trip: 'round',
	cabin: 'Economy',
	from: 'Manila (MNL)',
	to: '',
	depart: '',
	ret: '',
	adults: 1,
	children: 0,
	infants: 0,
	name: '',
	email: '',
	phone: '',
	notes: '',
};

function Stepper({
	label,
	value,
	min,
	onChange,
}: {
	label: string;
	value: number;
	min: number;
	onChange: (next: number) => void;
}) {
	return (
		<div className="flex items-center justify-between gap-2 rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3 py-2.5">
			<span className="font-body text-sm font-medium text-[hsl(var(--navy))]">{label}</span>
			<div className="flex items-center gap-1">
				<button
					type="button"
					aria-label={`Decrease ${label}`}
					onClick={() => onChange(Math.max(min, value - 1))}
					className="inline-flex h-8 w-8 items-center justify-center rounded-full text-[hsl(var(--navy))]/70 transition hover:bg-white active:scale-[0.98]"
				>
					<Minus className="h-3.5 w-3.5" />
				</button>
				<span className="w-5 text-center font-body text-sm font-semibold text-[hsl(var(--navy))]">{value}</span>
				<button
					type="button"
					aria-label={`Increase ${label}`}
					onClick={() => onChange(Math.min(9, value + 1))}
					className="inline-flex h-8 w-8 items-center justify-center rounded-full text-[hsl(var(--navy))]/70 transition hover:bg-white active:scale-[0.98]"
				>
					<Plus className="h-3.5 w-3.5" />
				</button>
			</div>
		</div>
	);
}

export function DomesticFlightsPage() {
	const [form, setForm] = useState<FormState>(initial);
	const [error, setError] = useState('');
	const [sent, setSent] = useState(false);

	const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
		setForm((prev) => ({ ...prev, [key]: value }));
		setSent(false);
	};

	const submit = (event: React.FormEvent) => {
		event.preventDefault();
		if (!form.from.trim() || !form.to.trim()) {
			setError('Enter both a departure city and a destination.');
			return;
		}
		if (!form.depart) {
			setError('Choose a departure date.');
			return;
		}
		if (form.trip === 'round' && !form.ret) {
			setError('Choose a return date, or switch to One Way.');
			return;
		}
		if (form.trip === 'round' && form.ret < form.depart) {
			setError('Return date must be on or after the departure date.');
			return;
		}
		if (form.adults < 1) {
			setError('At least one adult is required.');
			return;
		}
		if (!form.name.trim() || !form.email.trim()) {
			setError('Full name and email are required so we can send fare options.');
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
			setError('Enter a valid email address.');
			return;
		}
		setError('');
		setSent(true);
	};

	return (
		<div className="min-h-screen bg-white">
			<Navbar />
			<main>
				<section className="relative min-h-[640px] overflow-hidden pt-[68px] md:min-h-[720px]">
					<img
						src={domesticHero}
						alt="Limestone islands over a turquoise lagoon in Palawan"
						width={1600}
						height={900}
						fetchPriority="high"
						className="absolute inset-0 h-full w-full object-cover"
					/>
					<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(10,25,47,0.55)_0%,rgba(10,25,47,0.28)_38%,rgba(10,25,47,0.55)_100%)]" />
					<div className="relative z-10 mx-auto max-w-5xl px-5 pb-40 pt-6 sm:px-8">
						<a
							href="/"
							className="inline-flex items-center gap-2 font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-white/85 transition hover:text-white"
						>
							<ArrowLeft className="h-3.5 w-3.5" />
							Back Home
						</a>
						<div className="mx-auto mt-16 max-w-3xl text-center md:mt-24">
							<p className="flex items-center justify-center gap-3 font-body text-[11px] font-semibold uppercase tracking-[0.28em] text-[#f3a000]">
								<span className="h-px w-8 bg-[#f3a000]" />
								Domestic Flights
								<span className="h-px w-8 bg-[#f3a000]" />
							</p>
							<h1 className="mt-4 font-display text-4xl font-bold leading-tight text-white sm:text-5xl md:text-6xl">
								Explore the <span className="font-editorial italic font-medium text-[#f3a000]">Philippines</span>
							</h1>
							<p className="mx-auto mt-4 max-w-xl font-body text-sm leading-relaxed text-white/85 md:text-[15px]">
								Book flights to the country&apos;s top islands and cities. From Boracay&apos;s beaches to
								Palawan&apos;s lagoons — our team finds the best domestic fares for your trip.
							</p>
						</div>
					</div>
				</section>

				<section className="relative z-20 -mt-28 px-4 pb-8 sm:px-6">
					<form
						onSubmit={submit}
						noValidate
						className="mx-auto max-w-3xl rounded-[28px] bg-white px-5 py-6 shadow-[0_24px_60px_rgba(10,25,47,0.16)] sm:px-8 sm:py-7"
					>
						<div className="flex flex-wrap items-center justify-between gap-3">
							<div className="flex rounded-full bg-[#f3f5f8] p-1">
								{(
									[
										['round', 'Round Trip'],
										['oneway', 'One Way'],
									] as const
								).map(([value, label]) => (
									<button
										key={value}
										type="button"
										onClick={() => set('trip', value)}
										className={`min-h-9 rounded-full px-4 font-body text-sm font-semibold transition active:scale-[0.98] ${
											form.trip === value
												? 'bg-[#f3a000] text-white shadow-sm'
												: 'text-[hsl(var(--navy))]/70 hover:text-[hsl(var(--navy))]'
										}`}
									>
										{label}
									</button>
								))}
							</div>
							<label className="flex items-center gap-2 font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
								Cabin
								<select
									value={form.cabin}
									onChange={(event) => set('cabin', event.target.value as DomesticCabinClass)}
									className="min-h-9 rounded-full border border-[#e6ebf2] bg-white px-3 font-body text-sm font-medium normal-case tracking-normal text-[hsl(var(--navy))]"
								>
									{domesticCabinClasses.map((cabin) => (
										<option key={cabin} value={cabin}>
											{cabin}
										</option>
									))}
								</select>
							</label>
						</div>

						<div className="mt-6 grid gap-4 sm:grid-cols-2">
							<label className="block">
								<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
									From <span className="text-[#f3a000]">*</span>
								</span>
								<span className="mt-2 flex items-center gap-2 rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3">
									<MapPin className="h-4 w-4 shrink-0 text-[#f3a000]" />
									<input
										value={form.from}
										onChange={(event) => set('from', event.target.value)}
										className="min-h-11 w-full bg-transparent font-body text-sm text-[hsl(var(--navy))] outline-none placeholder:text-[hsl(var(--navy))]/35"
										placeholder="Manila (MNL)"
									/>
								</span>
							</label>
							<label className="block">
								<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
									To <span className="text-[#f3a000]">*</span>
								</span>
								<span className="mt-2 flex items-center gap-2 rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3">
									<MapPin className="h-4 w-4 shrink-0 text-[#f3a000]" />
									<input
										value={form.to}
										onChange={(event) => set('to', event.target.value)}
										className="min-h-11 w-full bg-transparent font-body text-sm text-[hsl(var(--navy))] outline-none placeholder:text-[hsl(var(--navy))]/35"
										placeholder="e.g. Boracay (MPH)"
									/>
								</span>
							</label>
							<label className="block">
								<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
									Departure Date <span className="text-[#f3a000]">*</span>
								</span>
								<span className="mt-2 flex items-center gap-2 rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3">
									<Calendar className="h-4 w-4 shrink-0 text-[hsl(var(--navy))]/35" />
									<input
										type="date"
										value={form.depart}
										onChange={(event) => set('depart', event.target.value)}
										className="min-h-11 w-full bg-transparent font-body text-sm text-[hsl(var(--navy))] outline-none"
									/>
								</span>
							</label>
							<label className={`block ${form.trip === 'oneway' ? 'opacity-50' : ''}`}>
								<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
									Return Date
								</span>
								<span className="mt-2 flex items-center gap-2 rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3">
									<Calendar className="h-4 w-4 shrink-0 text-[hsl(var(--navy))]/35" />
									<input
										type="date"
										value={form.trip === 'oneway' ? '' : form.ret}
										disabled={form.trip === 'oneway'}
										onChange={(event) => set('ret', event.target.value)}
										className="min-h-11 w-full bg-transparent font-body text-sm text-[hsl(var(--navy))] outline-none disabled:cursor-not-allowed"
									/>
								</span>
							</label>
						</div>

						<div className="mt-5">
							<p className="flex items-center gap-2 font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
								<Users className="h-3.5 w-3.5" />
								Passengers
							</p>
							<div className="mt-2 grid gap-3 sm:grid-cols-3">
								<Stepper label="Adults" value={form.adults} min={1} onChange={(value) => set('adults', value)} />
								<Stepper label="Children" value={form.children} min={0} onChange={(value) => set('children', value)} />
								<Stepper label="Infants" value={form.infants} min={0} onChange={(value) => set('infants', value)} />
							</div>
						</div>

						<div className="mt-8 border-t border-[#eef1f5] pt-6">
							<h2 className="font-display text-lg font-semibold text-[hsl(var(--navy))]">Your Contact Details</h2>
							<div className="mt-4 grid gap-4 sm:grid-cols-2">
								<label className="block">
									<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
										Full Name <span className="text-[#f3a000]">*</span>
									</span>
									<input
										value={form.name}
										onChange={(event) => set('name', event.target.value)}
										placeholder="Maria Santos"
										className="mt-2 min-h-11 w-full rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3 font-body text-sm text-[hsl(var(--navy))] outline-none placeholder:text-[hsl(var(--navy))]/35"
									/>
								</label>
								<label className="block">
									<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
										Email <span className="text-[#f3a000]">*</span>
									</span>
									<input
										type="email"
										value={form.email}
										onChange={(event) => set('email', event.target.value)}
										placeholder="maria@email.com"
										className="mt-2 min-h-11 w-full rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3 font-body text-sm text-[hsl(var(--navy))] outline-none placeholder:text-[hsl(var(--navy))]/35"
									/>
								</label>
							</div>
							<label className="mt-4 block">
								<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
									Phone
								</span>
								<input
									type="tel"
									value={form.phone}
									onChange={(event) => set('phone', event.target.value)}
									placeholder="+63 9XX XXX XXXX"
									className="mt-2 min-h-11 w-full rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3 font-body text-sm text-[hsl(var(--navy))] outline-none placeholder:text-[hsl(var(--navy))]/35"
								/>
							</label>
							<label className="mt-4 block">
								<span className="font-body text-[10px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))]/45">
									Notes (optional)
								</span>
								<textarea
									value={form.notes}
									onChange={(event) => set('notes', event.target.value)}
									rows={3}
									placeholder="Airline preferences, baggage, special requests..."
									className="mt-2 w-full resize-y rounded-xl border border-[#e7ebf2] bg-[#f4f6f9] px-3 py-3 font-body text-sm text-[hsl(var(--navy))] outline-none placeholder:text-[hsl(var(--navy))]/35"
								/>
							</label>
						</div>

						{error ? (
							<p role="alert" className="mt-4 font-body text-sm text-red-600">
								{error}
							</p>
						) : null}
						{sent ? (
							<p role="status" className="mt-4 rounded-xl bg-[#f4f6f9] px-4 py-3 font-body text-sm leading-relaxed text-[hsl(var(--navy))]">
								Request noted for {form.from} to {form.to}. This is not a confirmed booking, no fare is reserved, and this form does not save or email your details. An Airmark consultant can only follow up once you reach the team directly. Nothing is held until you choose and we confirm together.
							</p>
						) : null}

						<button
							type="submit"
							className="mt-5 flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#f3a000] font-body text-sm font-semibold text-white transition hover:bg-[#ffad0a] active:scale-[0.99]"
						>
							<Send className="h-4 w-4" />
							Request Flight Booking
						</button>
						<p className="mt-3 text-center font-body text-xs text-[hsl(var(--navy))]/45">
							A request does not lock a seat, fare, or travel date, and is not stored or emailed from this page.
						</p>
					</form>
				</section>

				<section className="mx-auto max-w-5xl px-5 py-16 sm:px-8">
					<p className="flex items-center gap-3 font-body text-[11px] font-semibold uppercase tracking-[0.22em] text-[#f3a000]">
						<span className="h-px w-8 bg-[#f3a000]" />
						Popular Destinations
					</p>
					<h2 className="mt-3 font-editorial text-3xl font-semibold text-[hsl(var(--navy))] md:text-4xl">
						Fly Where the Islands Await
					</h2>
					<div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
						{domesticDestinations.map((place) => (
							<button
								key={place.code}
								type="button"
								onClick={() => {
									set('to', place.label);
									window.scrollTo({ top: 280, behavior: 'smooth' });
								}}
								className="rounded-2xl border border-[#eef1f5] bg-[#f7f8fa] px-4 py-4 text-left transition hover:-translate-y-0.5 hover:border-[#f3a000]/40 hover:shadow-md active:scale-[0.99]"
							>
								<span className="font-body text-[11px] font-semibold uppercase tracking-wide text-[#f3a000]">
									{place.code}
								</span>
								<span className="mt-1 block font-display text-base font-semibold text-[hsl(var(--navy))]">
									{place.city}
								</span>
								<span className="mt-0.5 block font-body text-xs text-[hsl(var(--navy))]/45">{place.province}</span>
							</button>
						))}
					</div>

					<div className="mt-8 grid gap-4 md:grid-cols-3">
						{domesticSteps.map((step, index) => {
							const Icon = index === 0 ? Send : index === 1 ? Plane : CheckCircle2;
							return (
								<div key={step.title} className="rounded-2xl border border-[#eef1f5] bg-white px-5 py-6 shadow-[0_8px_24px_rgba(10,25,47,0.04)]">
									<span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-[#fff6e6] text-[#f3a000]">
										<Icon className="h-4 w-4" />
									</span>
									<h3 className="mt-4 font-display text-base font-semibold text-[hsl(var(--navy))]">{step.title}</h3>
									<p className="mt-2 font-body text-sm leading-relaxed text-[hsl(var(--navy))]/60">{step.body}</p>
								</div>
							);
						})}
					</div>
				</section>
			</main>
			<Footer />
		</div>
	);
}
