import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';

export function PolicyPage({
	title,
	intro,
	sections,
}: {
	title: string;
	intro: string;
	sections: { heading: string; body: string }[];
}) {
	return (
		<div className="min-h-[100dvh] bg-background text-foreground">
			<Navbar />
			<main className="mx-auto max-w-3xl px-6 pb-20 pt-32">
				<p className="font-display text-xs tracking-[0.2em] text-primary">AIRMARK TOUR AND DEV&apos;T INC.</p>
				<h1 className="mt-3 font-display text-4xl font-bold text-[hsl(var(--navy))]">{title}</h1>
				<p className="mt-5 font-body text-base leading-relaxed text-muted-foreground">{intro}</p>
				<div className="mt-10 space-y-8">
					{sections.map((s) => (
						<section key={s.heading}>
							<h2 className="font-display text-lg font-semibold text-[hsl(var(--navy))]">{s.heading}</h2>
							<p className="mt-2 font-body text-sm leading-relaxed text-muted-foreground">{s.body}</p>
						</section>
					))}
				</div>
			</main>
			<Footer />
		</div>
	);
}
