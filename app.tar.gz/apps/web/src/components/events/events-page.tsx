import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, CalendarDays, Mail, Maximize2, Music2, Phone, Ticket, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { events, type EventEntry } from '@/data/events';

const hero =
	'https://images.hostinger.com/8acf9b04-f8df-4c71-a8b7-8a7f1a9bd954.png';

type Poster = { alt: string; src: string; title: string };

function FactList({ title, items }: { title: string; items: string[] }) {
	return (
		<div>
			<h4 className="font-body text-[11px] font-semibold tracking-[0.22em] text-[#f3a000] uppercase">{title}</h4>
			<ul className="mt-2 space-y-1.5">
				{items.map((item) => (
					<li key={item} className="font-body text-sm leading-relaxed text-[hsl(var(--navy))]/80">
						{item}
					</li>
				))}
			</ul>
		</div>
	);
}

function EventBlock({ event, onOpen }: { event: EventEntry; onOpen: (poster: Poster) => void }) {
	return (
		<article id={event.slug} className="scroll-mt-28 border-t border-[hsl(var(--navy))]/10 py-12 lg:py-16">
			<div className="grid items-start gap-8 lg:grid-cols-[minmax(0,280px)_1fr] lg:gap-12">
				<figure className="group relative overflow-hidden rounded-2xl border border-[hsl(var(--navy))]/10 bg-white shadow-sm">
					<button
						type="button"
						onClick={() => onOpen({ alt: event.posterAlt, src: event.poster, title: event.title })}
						className="block w-full cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f3a000] focus-visible:ring-offset-2"
						aria-label={`Open ${event.title} poster full screen`}
					>
						<img
							src={event.poster}
							alt={event.posterAlt}
							width={800}
							height={1100}
							loading="lazy"
							className="h-auto w-full transition-transform duration-300 group-hover:scale-[1.02]"
						/>
						<span className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-gradient-to-t from-[hsl(var(--navy))]/85 to-transparent px-4 py-3 font-body text-xs font-semibold text-white">
							<Maximize2 className="h-4 w-4" aria-hidden="true" />
							View poster
						</span>
					</button>
				</figure>

				<div>
					<p className="font-body text-[11px] font-semibold tracking-[0.22em] text-[#f3a000] uppercase">
						{event.kind} · {event.place}
					</p>
					<h2 className="mt-2 font-editorial text-3xl text-[hsl(var(--navy))] md:text-4xl">{event.title}</h2>
					{event.price ? (
						<p className="mt-3 font-display text-3xl text-[hsl(var(--navy))]">
							{event.price}{' '}
							<span className="font-body text-sm font-medium text-[hsl(var(--navy))]/60">{event.priceNote}</span>
						</p>
					) : null}
					<p className="mt-4 max-w-2xl font-body text-sm leading-relaxed text-[hsl(var(--navy))]/78">{event.summary}</p>

					<div className="mt-6">
						<h3 className="font-body text-[11px] font-semibold tracking-[0.22em] text-[hsl(var(--navy))]/55 uppercase">
							{event.datesLabel}
						</h3>
						<ul className="mt-2 flex flex-wrap gap-2">
							{event.dates.map((date) => (
								<li
									key={date}
									className="rounded-full border border-[hsl(var(--navy))]/12 bg-white px-3 py-1.5 font-body text-xs text-[hsl(var(--navy))]"
								>
									{date}
								</li>
							))}
						</ul>
						{event.dateNote ? (
							<p className="mt-2 font-body text-xs leading-relaxed text-[hsl(var(--navy))]/55">{event.dateNote}</p>
						) : null}
					</div>

					{event.lineup ? (
						<div className="mt-6 grid gap-4 sm:grid-cols-2">
							{event.lineup.map((block) => (
								<div key={block.day} className="rounded-2xl bg-white p-4">
									<p className="font-body text-xs font-semibold tracking-[0.14em] text-[hsl(var(--navy))] uppercase">
										{block.day}
									</p>
									<ul className="mt-2 space-y-1">
										{block.artists.map((artist) => (
											<li key={artist} className="font-editorial text-xl text-[hsl(var(--navy))]">
												{artist}
											</li>
										))}
									</ul>
								</div>
							))}
						</div>
					) : null}

					{event.flights ? (
						<div className="mt-6">
							<h3 className="font-body text-[11px] font-semibold tracking-[0.22em] text-[hsl(var(--navy))]/55 uppercase">
								Flight details · {event.flights.airline}
							</h3>
							<ul className="mt-2 space-y-1 font-mono text-xs text-[hsl(var(--navy))]/80">
								{event.flights.legs.map((leg) => (
									<li key={leg}>{leg}</li>
								))}
							</ul>
						</div>
					) : null}

					<div className="mt-6 grid gap-6 sm:grid-cols-2">
						{event.inclusions ? <FactList title="Inclusions" items={event.inclusions} /> : null}
						{event.exclusions ? <FactList title="Exclusions" items={event.exclusions} /> : null}
						{event.hotel ? <FactList title="Hotel" items={event.hotel} /> : null}
					</div>

					{event.days ? (
						<ol className="mt-8 space-y-5">
							{event.days.map((day) => (
								<li key={day.label} className="grid gap-1 border-l-2 border-[#f3a000] pl-4">
									<p className="font-body text-xs font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase">
										{day.label}
										{day.meals ? ` · ${day.meals}` : ''} — {day.route}
									</p>
									<ul className="mt-1 list-disc space-y-0.5 pl-4 font-body text-sm text-[hsl(var(--navy))]/78">
										{day.stops.map((stop) => (
											<li key={stop}>{stop}</li>
										))}
									</ul>
									{day.note ? (
										<p className="mt-1 font-body text-xs text-[hsl(var(--navy))]/60">{day.note}</p>
									) : null}
								</li>
							))}
						</ol>
					) : null}

					<div className="mt-6 flex flex-wrap gap-3">
						{event.contacts.map((contact) => {
							const Icon = contact.href?.startsWith('mailto:')
								? Mail
								: contact.href?.startsWith('tel:')
									? Phone
									: CalendarDays;
							const className =
								'inline-flex min-h-11 items-center gap-2 rounded-full border border-[hsl(var(--navy))]/15 bg-white px-4 font-body text-xs font-semibold text-[hsl(var(--navy))] transition-colors hover:border-[#f3a000]';
							return contact.href ? (
								<a key={contact.value} href={contact.href} className={className}>
									<Icon className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
									<span>
										{contact.label}: {contact.value}
									</span>
								</a>
							) : (
								<span key={contact.value} className={className}>
									{contact.label}: {contact.value}
								</span>
							);
						})}
					</div>
				</div>
			</div>
		</article>
	);
}

export function EventsPage() {
	const [activePoster, setActivePoster] = useState<Poster | null>(null);
	const closeLightbox = useCallback(() => setActivePoster(null), []);

	useEffect(() => {
		if (!activePoster) return;
		const onKey = (event: KeyboardEvent) => {
			if (event.key === 'Escape') closeLightbox();
		};
		document.addEventListener('keydown', onKey);
		const prevOverflow = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.removeEventListener('keydown', onKey);
			document.body.style.overflow = prevOverflow;
		};
	}, [activePoster, closeLightbox]);

	return (
		<div className="bg-background text-foreground">
			<Navbar />
			<header className="relative min-h-[100dvh] overflow-hidden bg-[#0c1c34] text-white">
				<img
					src={hero}
					alt="Night concert stage in Seoul with a crowd and city fireworks"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover object-center"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,16,36,0.55)_0%,rgba(12,22,48,0.38)_32%,rgba(18,28,52,0.55)_62%,rgba(247,246,244,0.92)_88%,#f7f6f4_100%)]" />

				<div className="relative mx-auto flex min-h-[100dvh] max-w-[1320px] flex-col px-4 pt-[92px] sm:px-8 lg:px-10">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 py-2 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>

					<div className="flex flex-1 flex-col items-center justify-center px-2 pb-28 text-center sm:pb-36">
						<div className="flex items-center gap-3 text-[#f3a000]" aria-hidden="true">
							<CalendarDays className="h-5 w-5" strokeWidth={1.75} />
							<Music2 className="h-5 w-5" strokeWidth={1.75} />
							<Ticket className="h-5 w-5" strokeWidth={1.75} />
						</div>
						<h1 className="mt-5 max-w-4xl font-editorial text-5xl font-medium leading-[1.05] text-white sm:text-6xl md:text-7xl">
							Upcoming Events
						</h1>
						<p className="mt-5 max-w-xl font-body text-sm leading-relaxed text-white/90 sm:text-base">
							Festival nights, a Korea pilgrimage, and a Suwon run week — with the dates, fares, and day plans printed on each flyer.
						</p>
						<ul className="mt-7 flex flex-wrap items-center justify-center gap-2.5">
							{events.map((event) => (
								<li key={event.slug}>
									<a
										href={`#${event.slug}`}
										className="inline-flex min-h-9 items-center rounded-full border border-white/45 bg-white/10 px-4 font-body text-[10px] font-semibold tracking-[0.16em] text-white uppercase backdrop-blur-sm transition-colors hover:bg-white/20"
									>
										{event.title}
									</a>
								</li>
							))}
						</ul>
					</div>
				</div>
			</header>

			<main className="bg-[#f7f6f4]">
				<div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
					{events.map((event) => (
						<EventBlock key={event.slug} event={event} onOpen={setActivePoster} />
					))}
				</div>

				<section className="border-t border-border bg-white">
					<div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-6 py-10 sm:flex-row sm:items-center lg:px-8">
						<div>
							<p className="font-mono text-[11px] tracking-[0.28em] text-primary uppercase">Ask about a departure</p>
							<p className="mt-2 max-w-xl font-editorial text-2xl text-[hsl(var(--navy))] md:text-3xl">
								Tell the desk which event you want to join.
							</p>
						</div>
						<ContactTrigger className="inline-flex min-h-11 items-center justify-center rounded-full bg-[#f3a000] px-6 font-body text-sm font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98]">
							Contact Us
						</ContactTrigger>
					</div>
				</section>
			</main>
			<Footer />

			{activePoster ? (
				<div
					role="dialog"
					aria-modal="true"
					aria-label={activePoster.title}
					onClick={closeLightbox}
					className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
				>
					<button
						type="button"
						onClick={closeLightbox}
						aria-label="Close poster"
						className="absolute right-4 top-4 inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/25 bg-white/10 text-white transition-colors hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary active:scale-[0.98]"
					>
						<X className="h-5 w-5" aria-hidden="true" />
					</button>
					<img
						src={activePoster.src}
						alt={activePoster.alt}
						onClick={(event) => event.stopPropagation()}
						className="max-h-[92dvh] max-w-full rounded-lg object-contain shadow-2xl"
					/>
					<p className="absolute bottom-4 left-1/2 max-w-[90vw] -translate-x-1/2 text-center font-body text-xs text-white/70">
						{activePoster.title} — press Esc or tap outside to close
					</p>
				</div>
			) : null}
		</div>
	);
}
