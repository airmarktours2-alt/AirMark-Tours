import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, BedDouble, Check, Clock, Mail, Maximize2, Phone, Plane, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { philippinesHero, philippinesPackages, type PhilippinesPackage } from '@/data/philippines';

type Poster = { alt: string; src: string; title: string };

function SheetCard({
	children,
	className = '',
}: {
	children: React.ReactNode;
	className?: string;
}) {
	return (
		<section className={`rounded-2xl border border-[#e6ebf2] bg-white p-4 shadow-[0_8px_24px_rgba(15,35,70,0.05)] ${className}`}>
			{children}
		</section>
	);
}

function PackageSheet({
	pkg,
	onPoster,
}: {
	pkg: PhilippinesPackage;
	onPoster: (poster: Poster) => void;
}) {
	const [activeDate, setActiveDate] = useState(pkg.dates[0] ?? '');

	return (
		<article className="mx-auto max-w-6xl px-4 pb-16 sm:px-6">
			<header className="rounded-2xl bg-[#12315c] px-5 py-5 text-white shadow-sm sm:px-7 sm:py-6">
				<div className="flex flex-wrap items-start justify-between gap-4">
					<div>
						<p className="font-body text-[11px] font-semibold tracking-[0.22em] text-[#f3c15a] uppercase">
							Package 1 · {pkg.days}
						</p>
						<h1 className="mt-1 font-display text-3xl font-bold tracking-tight sm:text-4xl">{pkg.title}</h1>
						<p className="mt-1 font-editorial text-base italic text-white/80">{pkg.tagline}</p>
					</div>
					<p className="inline-flex items-center gap-2 font-body text-xs font-semibold tracking-[0.16em] text-white/85 uppercase">
						<Clock className="h-4 w-4 text-[#f3c15a]" aria-hidden="true" />
						{pkg.days}
					</p>
				</div>
			</header>

			<div className="mt-5 grid items-start gap-5 lg:grid-cols-[300px_minmax(0,1fr)]">
				<aside className="space-y-4">
					<div className="rounded-2xl bg-[#12315c] px-5 py-6 text-center text-white shadow-sm">
						<p className="font-body text-[11px] font-semibold tracking-[0.28em] text-[#f3c15a] uppercase">For only</p>
						<p className="mt-1 font-display text-4xl font-bold tracking-tight">{pkg.price.replace('Php', '₱')}</p>
						<p className="mt-1 font-body text-[11px] font-semibold tracking-[0.22em] text-white/70 uppercase">Per person</p>
					</div>

					<SheetCard>
						<p className="flex items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-[#12315c] uppercase">
							<Plane className="h-4 w-4 text-[#1d4e89]" aria-hidden="true" />
							Flight details
						</p>
						{pkg.airline ? <p className="mt-3 font-display text-sm font-semibold text-[#12315c]">{pkg.airline}</p> : null}
						<ul className="mt-2 space-y-1.5 font-body text-sm leading-relaxed text-foreground/80">
							{(pkg.flights ?? []).map((flight) => (
								<li key={flight}>{flight}</li>
							))}
						</ul>
					</SheetCard>

					{pkg.hotel ? (
						<SheetCard>
							<p className="flex items-center gap-2 font-body text-[11px] font-semibold tracking-[0.18em] text-[#12315c] uppercase">
								<BedDouble className="h-4 w-4 text-[#e23b4a]" aria-hidden="true" />
								Hotel
							</p>
							<p className="mt-3 font-body text-sm leading-relaxed text-foreground/85">{pkg.hotel}</p>
						</SheetCard>
					) : null}

					<SheetCard>
						<p className="font-body text-[11px] font-semibold tracking-[0.18em] text-[#1f8a4c] uppercase">Inclusions</p>
						<ul className="mt-3 space-y-2">
							{pkg.inclusions.map((item) => (
								<li key={item} className="flex gap-2 font-body text-sm leading-snug text-foreground/85">
									<Check className="mt-0.5 h-4 w-4 shrink-0 text-[#1f8a4c]" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
					</SheetCard>

					<SheetCard>
						<p className="font-body text-[11px] font-semibold tracking-[0.18em] text-[#e23b4a] uppercase">Exclusions</p>
						<ul className="mt-3 space-y-2">
							{pkg.exclusions.map((item) => (
								<li key={item} className="flex gap-2 font-body text-sm leading-snug text-foreground/85">
									<X className="mt-0.5 h-4 w-4 shrink-0 text-[#e23b4a]" aria-hidden="true" />
									<span>{item}</span>
								</li>
							))}
						</ul>
						{pkg.optional ? (
							<>
								<p className="mt-4 font-body text-[11px] font-semibold tracking-[0.18em] text-[#c47a00] uppercase">Optional tours</p>
								<ul className="mt-3 space-y-2">
									{pkg.optional.map((item) => (
										<li key={item} className="flex gap-2 font-body text-sm leading-snug text-foreground/85">
											<span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-[#c47a00]" aria-hidden="true" />
											<span>{item}</span>
										</li>
									))}
								</ul>
							</>
						) : null}
					</SheetCard>

					<div className="rounded-2xl bg-[#fff4c8] px-4 py-4">
						<p className="font-body text-[11px] font-semibold tracking-[0.2em] text-[#8a6a12] uppercase">Contact us</p>
						<ul className="mt-3 space-y-2">
							{pkg.contacts.map((contact) => (
								<li key={contact.value}>
									<a
										href={contact.href}
										className="inline-flex min-h-11 items-center gap-2 font-body text-sm font-medium text-[#12315c] hover:underline"
									>
										{contact.label.toLowerCase().includes('mail') ? (
											<Mail className="h-4 w-4" aria-hidden="true" />
										) : (
											<Phone className="h-4 w-4" aria-hidden="true" />
										)}
										{contact.value}
									</a>
								</li>
							))}
						</ul>
					</div>

					<button
						type="button"
						onClick={() =>
							onPoster({
								alt: `${pkg.title} package flyer`,
								src: pkg.flyer,
								title: pkg.title,
							})
						}
						className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border border-[#12315c] bg-white px-4 font-body text-xs font-semibold tracking-[0.12em] text-[#12315c] uppercase hover:bg-[#12315c] hover:text-white active:scale-[0.98]"
					>
						<Maximize2 className="h-4 w-4" aria-hidden="true" />
						View poster
					</button>
				</aside>

				<div className="space-y-4">
					<div className="rounded-2xl bg-[#ffe14a] px-4 py-4 sm:px-5">
						<p className="text-center font-body text-[11px] font-bold tracking-[0.22em] text-[#12315c] uppercase">
							{pkg.year} travel dates
						</p>
						<ul className="mt-3 flex flex-wrap justify-center gap-2">
							{pkg.dates.map((date) => {
								const selected = date === activeDate;
								return (
									<li key={date}>
										<button
											type="button"
											onClick={() => setActiveDate(date)}
											aria-pressed={selected}
											className={`min-h-11 rounded-lg px-4 font-body text-xs font-bold tracking-wide uppercase transition-colors active:scale-[0.98] ${
												selected ? 'bg-white text-[#12315c] shadow-sm' : 'bg-[#12315c] text-white'
											}`}
										>
											{date}
										</button>
									</li>
								);
							})}
						</ul>
					</div>

					<ol className="space-y-4">
						{pkg.itinerary.map((day) => (
							<li key={`${pkg.id}-${day.day}`} className="rounded-2xl border border-[#e6ebf2] bg-white p-3 shadow-[0_8px_24px_rgba(15,35,70,0.05)] sm:p-4">
								<div className="grid gap-4 sm:grid-cols-[220px_minmax(0,1fr)] sm:items-center">
									<figure className="relative overflow-hidden rounded-xl">
										<img
											src={day.image}
											alt={day.imageAlt}
											width={640}
											height={360}
											loading="lazy"
											className="aspect-[16/10] w-full object-cover"
										/>
										<span className="absolute left-3 top-3 rounded-md bg-[#12315c] px-2 py-1 font-body text-[10px] font-bold tracking-[0.14em] text-white uppercase">
											Day {day.day.replace(/^0/, '')}
										</span>
										<figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent px-3 pb-2 pt-8 font-body text-sm font-semibold text-white">
											{day.caption}
										</figcaption>
									</figure>
									<div>
										<h2 className="font-display text-lg font-bold text-[#12315c] sm:text-xl">{day.title}</h2>
										<ul className="mt-2 space-y-1.5">
											{day.stops.map((stop) => (
												<li key={stop} className="flex gap-2 font-body text-sm leading-snug text-foreground/85">
													<span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[#12315c]" aria-hidden="true" />
													<span>{stop}</span>
												</li>
											))}
										</ul>
									</div>
								</div>
							</li>
						))}
					</ol>

					{pkg.notes ? (
						<ul className="flex flex-wrap gap-2">
							{pkg.notes.map((note) => (
								<li key={note} className="rounded-full bg-white px-3 py-1.5 font-body text-xs text-foreground/70">
									{note}
								</li>
							))}
						</ul>
					) : null}
				</div>
			</div>

			<div className="mt-8 flex justify-center">
				<ContactTrigger className="inline-flex min-h-12 items-center justify-center rounded-full bg-[#12315c] px-8 font-body text-sm font-semibold text-white shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]">
					Book Now — {pkg.title}
				</ContactTrigger>
			</div>
		</article>
	);
}

export function PhilippinesPage() {
	const [activePoster, setActivePoster] = useState<Poster | null>(null);
	const closeLightbox = useCallback(() => setActivePoster(null), []);

	useEffect(() => {
		if (!activePoster) return;
		const onKey = (event: KeyboardEvent) => {
			if (event.key === 'Escape') closeLightbox();
		};
		document.addEventListener('keydown', onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.removeEventListener('keydown', onKey);
			document.body.style.overflow = previous;
		};
	}, [activePoster, closeLightbox]);

	return (
		<div className="relative min-h-screen bg-[#0a192f] text-foreground">
			<div
				aria-hidden="true"
				className="pointer-events-none fixed inset-0 z-0"
				style={{
					backgroundImage: `url(${philippinesHero})`,
					backgroundSize: 'cover',
					backgroundPosition: 'center 35%',
					backgroundRepeat: 'no-repeat',
				}}
			/>
			<div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(180deg,rgba(8,18,40,0.55)_0%,rgba(8,18,40,0.45)_100%)]" />
			<div className="relative z-10">
			<Navbar />
			<div className="relative h-44 overflow-hidden sm:h-56">
				<img
					src={philippinesHero}
					alt="Coron limestone cliffs and turquoise lagoon, Palawan"
					width={1600}
					height={900}
					fetchPriority="high"
					className="h-full w-full object-cover object-[center_35%]"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,18,40,0.35)_0%,rgba(8,18,40,0.15)_40%,rgba(8,18,40,0.35)_100%)]" />
				<div className="absolute left-0 right-0 top-[88px] mx-auto flex max-w-6xl px-4 sm:px-6">
					<Link
						to="/"
						className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white px-4 font-body text-[11px] font-semibold tracking-[0.16em] text-[#12315c] uppercase shadow-sm"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>
				</div>
			</div>

			<div className="relative -mt-10">
				{philippinesPackages.map((pkg) => (
					<PackageSheet key={pkg.id} pkg={pkg} onPoster={setActivePoster} />
				))}
			</div>
			<Footer />
			</div>

			{activePoster ? (
				<div
					className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4"
					role="dialog"
					aria-modal="true"
					aria-label={activePoster.title}
					onClick={closeLightbox}
				>
					<button
						type="button"
						onClick={closeLightbox}
						className="absolute right-4 top-4 inline-flex min-h-11 min-w-11 items-center justify-center rounded-full bg-white text-[#12315c]"
						aria-label="Close poster"
					>
						<X className="h-5 w-5" aria-hidden="true" />
					</button>
					<img
						src={activePoster.src}
						alt={activePoster.alt}
						className="max-h-[92dvh] w-auto max-w-full object-contain"
						onClick={(event) => event.stopPropagation()}
					/>
				</div>
			) : null}
		</div>
	);
}
