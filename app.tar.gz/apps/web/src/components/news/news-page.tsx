import { Link } from 'react-router';
import { ArrowLeft, ArrowRight, AtSign, Fuel, Plane } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { newsItems, type NewsItem } from '@/data/news';

const hero =
	'https://images.hostinger.com/ab498fe5-998f-412a-9449-0614e4861046.png';

const icons = {
	plane: Plane,
	fuel: Fuel,
	at: AtSign,
};

function NewsCard({ item }: { item: NewsItem }) {
	const Icon = icons[item.icon];
	const media = (
		<div className="relative min-h-[240px] overflow-hidden rounded-[22px] sm:min-h-[320px] lg:min-h-[380px]">
			<img
				src={item.image}
				alt={item.imageAlt}
				width={960}
				height={640}
				loading="lazy"
				className="absolute inset-0 h-full w-full object-cover"
			/>
			<div className="absolute inset-0 bg-gradient-to-t from-[#07111f]/35 via-transparent to-[#07111f]/10" />
			<span
				className="absolute left-4 top-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl border shadow-lg"
				style={{
					color: item.accent,
					background: 'rgba(8, 16, 32, 0.55)',
					borderColor: `${item.accent}55`,
				}}
			>
				<Icon className="h-5 w-5" strokeWidth={1.75} aria-hidden="true" />
			</span>
		</div>
	);

	const copy = (
		<div className="flex flex-col justify-center px-1 py-2 sm:px-2 lg:px-4 lg:py-6">
			<div className="flex flex-wrap items-center gap-2">
				<span
					className="inline-flex min-h-7 items-center rounded-full px-3 font-body text-[10px] font-semibold tracking-[0.16em] uppercase"
					style={{ background: item.accent, color: '#0b1220' }}
				>
					{item.category}
				</span>
				<span className="inline-flex min-h-7 items-center rounded-full bg-white/10 px-3 font-body text-[10px] font-semibold tracking-[0.16em] text-white/80 uppercase">
					{item.status}
				</span>
			</div>
			<h2 className="mt-4 font-editorial text-[2rem] leading-[1.1] text-white sm:text-4xl">{item.title}</h2>
			<p className="mt-3 max-w-xl font-body text-sm leading-relaxed text-white/72">{item.summary}</p>
			<ul className="mt-5 grid gap-x-6 gap-y-3 sm:grid-cols-2">
				{item.points.map((point) => (
					<li key={point} className="flex gap-2.5 font-body text-[13px] leading-relaxed text-white/82">
						<span
							className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full"
							style={{ background: item.accent }}
							aria-hidden="true"
						/>
						<span>{point}</span>
					</li>
				))}
			</ul>
			<ContactTrigger
				className="mt-7 inline-flex min-h-11 w-fit items-center gap-2 rounded-full px-5 font-body text-sm font-semibold text-[#0b1220] transition-transform hover:-translate-y-px active:scale-[0.98]"
				style={{ background: item.accent }}
			>
				Ask for Details
				<ArrowRight className="h-4 w-4" aria-hidden="true" />
			</ContactTrigger>
		</div>
	);

	return (
		<article
			id={item.slug}
			className="scroll-mt-28 overflow-hidden rounded-[28px] border border-white/10 bg-[#0d1b33] p-3 shadow-[0_18px_50px_rgba(4,10,24,0.35)] sm:p-4"
		>
			<div
				className={`grid items-stretch gap-4 lg:grid-cols-2 lg:gap-6 ${
					item.imageSide === 'right' ? '' : ''
				}`}
			>
				<div className={item.imageSide === 'right' ? 'lg:order-2' : ''}>{media}</div>
				<div className={item.imageSide === 'right' ? 'lg:order-1' : ''}>{copy}</div>
			</div>
		</article>
	);
}

export function NewsPage() {
	return (
		<div className="bg-[#07111f] text-white">
			<Navbar />
			<header className="relative min-h-[72dvh] overflow-hidden">
				<img
					src={hero}
					alt="Airplane wing above layered clouds at sunrise"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(7,17,31,0.55)_0%,rgba(7,17,31,0.42)_40%,rgba(7,17,31,0.88)_100%)]" />
				<div className="relative mx-auto flex min-h-[72dvh] max-w-[1180px] flex-col px-4 pt-[92px] pb-10 sm:px-8">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>
					<div className="flex flex-1 flex-col justify-end pb-4 pt-16">
						<p className="font-body text-[11px] font-semibold tracking-[0.28em] text-[#f3a000] uppercase">
							Airmark desk notes
						</p>
						<h1 className="mt-3 max-w-3xl font-editorial text-5xl leading-[1.05] text-white sm:text-6xl">
							Travel News
						</h1>
						<p className="mt-4 max-w-xl font-body text-sm leading-relaxed text-white/80 sm:text-base">
							Ongoing editorial briefings from the Airmark desk — airline notes, fare advisories, and industry headlines for Korea and Asia departures. These are topic guides, not a live feed.
						</p>
					</div>
				</div>
			</header>

			<main className="relative bg-[#07111f]">
				<div
					className="pointer-events-none absolute inset-0 opacity-40"
					style={{
						backgroundImage: `url(${hero})`,
						backgroundSize: 'cover',
						backgroundPosition: 'center',
					}}
					aria-hidden="true"
				/>
				<div className="pointer-events-none absolute inset-0 bg-[#07111f]/88" aria-hidden="true" />
				<div className="relative mx-auto flex max-w-[1180px] flex-col gap-6 px-4 py-10 sm:px-8 sm:py-14">
					{newsItems.map((item) => (
						<NewsCard key={item.slug} item={item} />
					))}
				</div>
			</main>
			<Footer />
		</div>
	);
}
