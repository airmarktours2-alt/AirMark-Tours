import { useState, type FormEvent } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Mail, MapPin, Phone, Send } from 'lucide-react';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { deskContacts, office } from '@/data/contacts';

const background =
	'https://images.hostinger.com/37415eaf-1954-4766-ad8c-675acc54041c.png';

type Inquiry = {
	name: string;
	email: string;
	phone: string;
	message: string;
};

const empty: Inquiry = { name: '', email: '', phone: '', message: '' };

export function ContactPage() {
	const [fields, setFields] = useState<Inquiry>(empty);
	const [error, setError] = useState('');
	const [sent, setSent] = useState<Inquiry | null>(null);

	function onSubmit(event: FormEvent<HTMLFormElement>) {
		event.preventDefault();
		const next = {
			name: fields.name.trim(),
			email: fields.email.trim(),
			phone: fields.phone.trim(),
			message: fields.message.trim(),
		};
		if (!next.name || !next.email || !next.phone || !next.message) {
			setError('Please fill in your name, email, phone, and message.');
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.email)) {
			setError('Enter a valid email address.');
			return;
		}
		setError('');
		setSent(next);
		setFields(empty);
	}

	return (
		<div className="min-h-screen bg-[#f4f6f8] text-[#152033]">
			<Navbar />
			<div className="relative overflow-hidden">
				<img
					src={background}
					alt="Airplane wing above clouds at golden hour"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(10,25,47,0.55)_0%,rgba(244,246,248,0.92)_28%,#f4f6f8_46%)]" />

				<main className="relative mx-auto max-w-[1080px] px-4 pb-16 pt-[92px] sm:px-6 lg:px-8 lg:pb-24">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-[hsl(var(--navy))] shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>

					<section className="mt-6 rounded-[28px] border border-white/80 bg-white px-5 py-7 shadow-[0_24px_60px_rgba(15,32,58,0.08)] sm:px-8 sm:py-9 lg:px-10">
						<p className="font-body text-[11px] font-semibold uppercase tracking-[0.28em] text-[#f3a000]">
							Ground Control
						</p>
						<h1 className="mt-2 font-editorial text-4xl text-[#152033] sm:text-5xl">Get In Touch</h1>
						<p className="mt-3 max-w-xl font-body text-sm leading-relaxed text-[#5c6778]">
							The Makati office and the same desk directory printed in the footer. Call or email the consultant who covers your destination.
						</p>

						<div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-2 lg:gap-6">
							<div className="space-y-4">
								<article className="rounded-2xl bg-[#f6f7f9] p-5 sm:p-6">
									<p className="flex items-center gap-2 font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8a93a3]">
										<MapPin className="h-4 w-4 text-[#f3a000]" aria-hidden="true" />
										{office.label}
									</p>
									<p className="mt-3 font-body text-sm leading-relaxed text-[#3d4758]">{office.address}</p>
								</article>

								<article className="rounded-2xl bg-[#f6f7f9] p-5 sm:p-6">
									<p className="flex items-center gap-2 font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8a93a3]">
										<Phone className="h-4 w-4 text-[#f3a000]" aria-hidden="true" />
										Contact Details
									</p>
									<ul className="mt-4 space-y-4">
										{deskContacts.map((contact) => (
											<li key={contact.email}>
												<p className="font-body text-[13px] text-[#8a93a3]">{contact.regions}</p>
												<p className="mt-0.5 font-body text-sm font-semibold text-[#152033]">{contact.name}</p>
												<p className="font-body text-sm text-[#3d4758]">
													<a href={`tel:${contact.phone}`} className="hover:text-[#f3a000]">
														{contact.phone}
													</a>
													{' / '}
													<a href={`mailto:${contact.email}`} className="break-all hover:text-[#f3a000]">
														{contact.email}
													</a>
												</p>
											</li>
										))}
									</ul>
								</article>
							</div>

							<div className="rounded-2xl bg-[#f6f7f9] p-5 sm:p-6">
								{sent ? (
									<div className="flex h-full min-h-[320px] flex-col justify-center" role="status">
										<p className="font-body text-[11px] font-semibold uppercase tracking-[0.18em] text-[#f3a000]">
											Noted on this page
										</p>
										<h2 className="mt-2 font-editorial text-3xl text-[#152033]">Thank you, {sent.name}.</h2>
										<p className="mt-3 font-body text-sm leading-relaxed text-[#5c6778]">
											This form only confirms what you typed. It is not emailed and it is not saved. Please reach the desk directly so a consultant can reply.
										</p>
										<dl className="mt-5 space-y-2 font-body text-sm text-[#3d4758]">
											<div>
												<dt className="text-[11px] uppercase tracking-[0.14em] text-[#8a93a3]">Email</dt>
												<dd>{sent.email}</dd>
											</div>
											<div>
												<dt className="text-[11px] uppercase tracking-[0.14em] text-[#8a93a3]">Phone</dt>
												<dd>{sent.phone}</dd>
											</div>
											<div>
												<dt className="text-[11px] uppercase tracking-[0.14em] text-[#8a93a3]">Message</dt>
												<dd className="whitespace-pre-wrap">{sent.message}</dd>
											</div>
										</dl>
										<a
											href="mailto:gelai.airmark@gmail.com"
											className="mt-6 inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-[#f3a000] px-5 font-body text-sm font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98]"
										>
											<Mail className="h-4 w-4" aria-hidden="true" />
											Email a consultant
										</a>
										<button
											type="button"
											onClick={() => setSent(null)}
											className="mt-3 w-fit font-body text-sm font-semibold text-[#152033] underline decoration-[#f3a000] underline-offset-4"
										>
											Write another note
										</button>
									</div>
								) : (
									<form onSubmit={onSubmit} className="space-y-4" noValidate>
										<div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
											<label className="block">
												<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">
													Full Name
												</span>
												<input
													name="name"
													type="text"
													autoComplete="name"
													value={fields.name}
													onChange={(event) => setFields((current) => ({ ...current, name: event.target.value }))}
													placeholder="Your name"
													className="mt-2 w-full rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
												/>
											</label>
											<label className="block">
												<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">
													Email
												</span>
												<input
													name="email"
													type="email"
													autoComplete="email"
													value={fields.email}
													onChange={(event) => setFields((current) => ({ ...current, email: event.target.value }))}
													placeholder="you@email.com"
													className="mt-2 w-full rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
												/>
											</label>
										</div>
										<label className="block">
											<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">
												Phone
											</span>
											<input
												name="phone"
												type="tel"
												autoComplete="tel"
												value={fields.phone}
												onChange={(event) => setFields((current) => ({ ...current, phone: event.target.value }))}
												placeholder="+63 9XX XXX XXXX"
												className="mt-2 w-full rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
											/>
										</label>
										<label className="block">
											<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">
												Message
											</span>
											<textarea
												name="message"
												rows={5}
												value={fields.message}
												onChange={(event) => setFields((current) => ({ ...current, message: event.target.value }))}
												placeholder="Tell us about your dream trip..."
												className="mt-2 w-full resize-y rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
											/>
										</label>
										{error ? (
											<p className="font-body text-sm text-red-700" role="alert">
												{error}
											</p>
										) : null}
										<button
											type="submit"
											className="flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#f3a000] font-body text-sm font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98]"
										>
											<Send className="h-4 w-4" aria-hidden="true" />
											Send Message
										</button>
										<p className="font-body text-xs leading-relaxed text-[#8a93a3]">
											Sending shows a confirmation here only. To reach Airmark, use the phone numbers and emails above.
										</p>
									</form>
								)}
							</div>
						</div>
					</section>
				</main>
			</div>
			<Footer />
		</div>
	);
}
