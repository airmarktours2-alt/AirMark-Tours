import { createContext, useCallback, useContext, useEffect, useState, type CSSProperties, type FormEvent, type ReactNode } from 'react';
import { MapPin, Phone, Send, X } from 'lucide-react';
import { deskContacts, office } from '@/data/contacts';

type Inquiry = {
	name: string;
	email: string;
	phone: string;
	message: string;
};

const empty: Inquiry = { name: '', email: '', phone: '', message: '' };

const ContactPanelContext = createContext<(() => void) | null>(null);

export function useContactPanel() {
	const open = useContext(ContactPanelContext);
	if (!open) {
		throw new Error('Contact panel is not available');
	}
	return open;
}

export function ContactTrigger({
	className,
	children,
	onClick,
	style,
}: {
	className?: string;
	children: ReactNode;
	onClick?: () => void;
	style?: CSSProperties;
}) {
	const open = useContactPanel();
	return (
		<button
			type="button"
			onClick={() => {
				onClick?.();
				open();
			}}
			className={className}
			style={style}
		>
			{children}
		</button>
	);
}

export function ContactPanelProvider({ children }: { children: ReactNode }) {
	const [open, setOpen] = useState(false);
	const close = useCallback(() => setOpen(false), []);
	const show = useCallback(() => setOpen(true), []);

	return (
		<ContactPanelContext.Provider value={show}>
			{children}
			{open ? <ContactDialog onClose={close} /> : null}
		</ContactPanelContext.Provider>
	);
}

function ContactDialog({ onClose }: { onClose: () => void }) {
	const [fields, setFields] = useState<Inquiry>(empty);
	const [error, setError] = useState('');
	const [sent, setSent] = useState<Inquiry | null>(null);
	const [submitting, setSubmitting] = useState(false);

	useEffect(() => {
		const onKey = (event: KeyboardEvent) => {
			if (event.key === 'Escape') onClose();
		};
		document.addEventListener('keydown', onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.removeEventListener('keydown', onKey);
			document.body.style.overflow = previous;
		};
	}, [onClose]);

	async function onSubmit(event: FormEvent<HTMLFormElement>) {
		event.preventDefault();
		if (submitting) return;
		const next = {
			name: fields.name.trim(),
			email: fields.email.trim(),
			phone: fields.phone.trim(),
			message: fields.message.trim(),
		};
		if (!next.name || !next.email || !next.phone || !next.message) {
			setError('Please fill in your name, email, phone, and message.');
			return;
		}
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.email)) {
			setError('Enter a valid email address.');
			return;
		}
		setError('');
		setSubmitting(true);
		try {
			const response = await fetch('/api/contact', {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify(next),
			});
			if (!response.ok) {
				const data = (await response.json().catch(() => null)) as { error?: string } | null;
				throw new Error(
					data?.error ||
						'We could not send your message right now. Please try again or email us directly.',
				);
			}
			setSent(next);
			setFields(empty);
		} catch (err) {
			setError(
				err instanceof Error
					? err.message
					: 'Something went wrong. Please try again or email us directly.',
			);
		} finally {
			setSubmitting(false);
		}
	}

	return (
		<div className="fixed inset-0 z-[120] flex items-start justify-center overflow-y-auto bg-[#0a192f]/55 p-3 sm:items-center sm:p-6">
			<button type="button" className="absolute inset-0 cursor-default" aria-label="Close contact panel" onClick={onClose} />
			<div
				role="dialog"
				aria-modal="true"
				aria-labelledby="contact-panel-title"
				className="relative z-10 my-4 w-full max-w-[1080px] rounded-[28px] border border-white/80 bg-white px-5 py-7 text-[#152033] shadow-[0_24px_60px_rgba(15,32,58,0.22)] sm:px-8 sm:py-9 lg:px-10"
			>
				<button
					type="button"
					onClick={onClose}
					aria-label="Close"
					className="absolute right-4 top-4 inline-flex h-11 w-11 items-center justify-center rounded-full border border-[#e6eaf1] bg-white text-[#152033] transition-colors hover:border-[#f3a000] hover:text-[#f3a000] active:scale-[0.98]"
				>
					<X className="h-4 w-4" aria-hidden="true" />
				</button>
				<p className="font-body text-[11px] font-semibold uppercase tracking-[0.28em] text-[#f3a000]">Ground Control</p>
				<h2 id="contact-panel-title" className="mt-2 font-editorial text-4xl text-[#152033] sm:text-5xl">
					Get In Touch
				</h2>
				<p className="mt-3 max-w-xl font-body text-sm leading-relaxed text-[#5c6778]">
					The Makati office and the same desk directory printed in the footer. Call or email the consultant who covers your destination.
				</p>

				<div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-2 lg:gap-6">
					<div className="space-y-4">
						<article className="rounded-2xl bg-[#f6f7f9] p-5 sm:p-6">
							<p className="flex items-center gap-2 font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8a93a3]">
								<MapPin className="h-4 w-4 text-[#f3a000]" aria-hidden="true" />
								{office.label}
							</p>
							<p className="mt-3 font-body text-sm leading-relaxed text-[#3d4758]">{office.address}</p>
						</article>
						<article className="rounded-2xl bg-[#f6f7f9] p-5 sm:p-6">
							<p className="flex items-center gap-2 font-body text-[11px] font-semibold uppercase tracking-[0.16em] text-[#8a93a3]">
								<Phone className="h-4 w-4 text-[#f3a000]" aria-hidden="true" />
								Contact Details
							</p>
							<ul className="mt-4 space-y-4">
								{deskContacts.map((contact) => (
									<li key={contact.email}>
										<p className="font-body text-[13px] text-[#8a93a3]">{contact.regions}</p>
										<p className="mt-0.5 font-body text-sm font-semibold text-[#152033]">{contact.name}</p>
										<p className="font-body text-sm text-[#3d4758]">
											<a href={`tel:${contact.phone}`} className="hover:text-[#f3a000]">
												{contact.phone}
											</a>
											{' / '}
											<a href={`mailto:${contact.email}`} className="break-all hover:text-[#f3a000]">
												{contact.email}
											</a>
										</p>
									</li>
								))}
							</ul>
						</article>
					</div>

					<div className="rounded-2xl bg-[#f6f7f9] p-5 sm:p-6">
						{sent ? (
							<div className="flex min-h-[280px] flex-col justify-center" role="status">
								<p className="font-body text-[11px] font-semibold uppercase tracking-[0.18em] text-[#f3a000]">Message Sent</p>
								<p className="mt-2 font-editorial text-3xl text-[#152033]">Thank you, {sent.name}.</p>
								<p className="mt-3 font-body text-sm leading-relaxed text-[#5c6778]">
									Your message has been delivered to our team at airmarktours2@gmail.com. A consultant will reply to your email shortly.
								</p>
								<button
									type="button"
									onClick={() => setSent(null)}
									className="mt-5 w-fit font-body text-sm font-semibold text-[#152033] underline decoration-[#f3a000] underline-offset-4"
								>
									Write another note
								</button>
							</div>
						) : (
							<form onSubmit={onSubmit} className="space-y-4" noValidate>
								<div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
									<label className="block">
										<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">Full Name</span>
										<input
											name="name"
											type="text"
											autoComplete="name"
											value={fields.name}
											onChange={(event) => setFields((current) => ({ ...current, name: event.target.value }))}
											placeholder="Your name"
											className="mt-2 w-full rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
										/>
									</label>
									<label className="block">
										<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">Email</span>
										<input
											name="email"
											type="email"
											autoComplete="email"
											value={fields.email}
											onChange={(event) => setFields((current) => ({ ...current, email: event.target.value }))}
											placeholder="you@email.com"
											className="mt-2 w-full rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
										/>
									</label>
								</div>
								<label className="block">
									<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">Phone</span>
									<input
										name="phone"
										type="tel"
										autoComplete="tel"
										value={fields.phone}
										onChange={(event) => setFields((current) => ({ ...current, phone: event.target.value }))}
										placeholder="+63 9XX XXX XXXX"
										className="mt-2 w-full rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
									/>
								</label>
								<label className="block">
									<span className="font-body text-[11px] font-semibold uppercase tracking-[0.14em] text-[#8a93a3]">Message</span>
									<textarea
										name="message"
										rows={5}
										value={fields.message}
										onChange={(event) => setFields((current) => ({ ...current, message: event.target.value }))}
										placeholder="Tell us about your dream trip..."
										className="mt-2 w-full resize-y rounded-xl border border-transparent bg-white px-4 py-3 font-body text-sm text-[#152033] outline-none ring-[#f3a000] placeholder:text-[#b0b7c3] focus:ring-2"
									/>
								</label>
								{error ? (
									<p className="font-body text-sm text-red-700" role="alert">
										{error}
									</p>
								) : null}
								<button
									type="submit"
									disabled={submitting}
									className="flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#f3a000] font-body text-sm font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-70"
								>
									<Send className="h-4 w-4" aria-hidden="true" />
									{submitting ? 'Sending…' : 'Send Message'}
								</button>
								<p className="font-body text-xs leading-relaxed text-[#8a93a3]">
									Your message is delivered to our team at airmarktours2@gmail.com. For urgent matters, call the desks listed above.
								</p>
							</form>
						)}
					</div>
				</div>
			</div>
		</div>
	);
}
