import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router';
import { ArrowLeft, Maximize2, Phone, X } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { japanPackages } from '@/data/japan';

const hero = 'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/3dff33621dbff24886cf910b55509aa1.png';

type Poster = { alt: string; src: string; title: string };

export function JapanPage() {
	const [activePoster, setActivePoster] = useState<Poster | null>(null);
	const closeLightbox = useCallback(() => setActivePoster(null), []);

	useEffect(() => {
		if (!activePoster) return;
		const onKey = (event: KeyboardEvent) => {
			if (event.key === 'Escape') closeLightbox();
		};
		document.addEventListener('keydown', onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = 'hidden';
		return () => {
			document.removeEventListener('keydown', onKey);
			document.body.style.overflow = previous;
		};
	}, [activePoster, closeLightbox]);

	return (
		<div className="bg-background text-foreground">
			<Navbar />
			<header className="relative min-h-[78dvh] overflow-hidden bg-[hsl(var(--navy))] text-white">
				<div className="absolute inset-y-0 right-0 w-full overflow-hidden lg:w-1/2">
					<img
						src={hero}
						alt=""
						aria-hidden="true"
						width={1568}
						height={730}
						fetchPriority="high"
						className="absolute inset-y-0 right-0 h-full w-[200%] max-w-none object-cover object-right"
					/>
				</div>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,22,43,0.45)_0%,hsl(var(--navy))_100%)] lg:bg-[linear-gradient(90deg,hsl(var(--navy))_0%,hsl(var(--navy))_42%,rgba(8,22,43,0.72)_56%,rgba(8,22,43,0.18)_75%,rgba(8,22,43,0.06)_100%)]" />
				<div className="relative mx-auto flex min-h-[78dvh] max-w-6xl flex-col justify-end px-6 pb-16 pt-28 lg:px-8">
					<Link
						to="/"
						className="mb-8 inline-flex min-h-11 w-fit items-center gap-2 rounded-full border border-white/25 bg-white/10 px-4 py-2 font-mono text-xs tracking-[0.2em] text-white uppercase backdrop-blur transition-colors hover:bg-white/20"
					>
						<ArrowLeft className="h-4 w-4" aria-hidden="true" />
						Back to Airmark Tours
					</Link>
					<p className="font-mono text-xs tracking-[0.32em] text-primary uppercase">Japan · 2026 & 2027</p>
					<h1 className="mt-3 max-w-3xl font-display text-5xl font-bold leading-none md:text-7xl">Japan tour packages</h1>
					<p className="mt-5 max-w-2xl font-body text-base leading-relaxed text-white/80 md:text-lg">
						Eight published Airmark departures — Osaka to Tokyo, Fukuoka and Hiroshima, Nagoya and the Alps, cherry blossom, autumn Tokyo, Disneyland, New Year’s Eve, and a Hokkaido winter — with fares, flights, hotels, and every day written out.
					</p>
					<p className="mt-6 font-display text-2xl text-white">
						From <span className="text-primary">USD 1,438</span> per person
					</p>
				</div>
			</header>

			<nav className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur">
				<div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-6 py-3 lg:px-8">
					{japanPackages.map((pkg) => (
						<a
							key={pkg.id}
							href={`#${pkg.id}`}
							className="shrink-0 rounded-full border border-border px-3 py-2 font-body text-xs text-foreground hover:border-primary hover:text-primary"
						>
							{pkg.tagline}
						</a>
					))}
				</div>
			</nav>

			<main className="mx-auto max-w-6xl space-y-16 px-6 py-14 lg:px-8">
				{japanPackages.map((pkg) => (
					<article id={pkg.id} key={pkg.id} className="scroll-mt-24 border-t border-border pt-12">
						<div className="grid items-start gap-8 lg:grid-cols-[minmax(0,280px)_1fr]">
							<figure className="group relative overflow-hidden rounded-2xl border border-border bg-secondary">
								<button
									type="button"
									onClick={() =>
										setActivePoster({
											alt: `${pkg.tagline} ${pkg.title} package flyer`,
											src: pkg.flyer,
											title: `${pkg.tagline} — ${pkg.title}`,
										})
									}
									className="block w-full cursor-zoom-in focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background"
									aria-label={`Open ${pkg.title} poster full screen`}
								>
									<img
										src={pkg.flyer}
										alt={`${pkg.tagline} ${pkg.title} package flyer`}
										width={800}
										height={1100}
										loading="lazy"
										className="h-auto w-full transition-transform duration-300 group-hover:scale-[1.02]"
									/>
									<span className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-gradient-to-t from-[hsl(var(--navy))]/85 to-transparent px-4 py-3 font-body text-xs font-semibold text-white opacity-100 sm:opacity-0 sm:transition-opacity sm:duration-300 sm:group-hover:opacity-100">
										<Maximize2 className="h-4 w-4" aria-hidden="true" />
										Tap to view full screen
									</span>
								</button>
							</figure>
							<div>
								<p className="font-mono text-[11px] tracking-[0.28em] text-primary uppercase">
									{pkg.season} · {pkg.year} · {pkg.days}
								</p>
								<p className="mt-2 font-body text-sm text-muted-foreground">{pkg.tagline}</p>
								<h2 className="mt-1 font-display text-3xl font-bold md:text-4xl">{pkg.title}</h2>
								<p className="mt-1 font-body text-sm text-muted-foreground">{pkg.region}</p>
								<p className="mt-3 font-display text-3xl text-[hsl(var(--navy))]">{pkg.price}</p>
								<p className="font-body text-sm text-muted-foreground">{pkg.priceNote}</p>
								<p className="mt-2 font-body text-sm">
									Airline: <strong>{pkg.airline}</strong>
								</p>

								{pkg.notes ? (
									<ul className="mt-4 flex flex-wrap gap-2">
										{pkg.notes.map((note) => (
											<li key={note} className="rounded-full bg-secondary px-3 py-1 font-body text-xs text-foreground">
												{note}
											</li>
										))}
									</ul>
								) : null}

								<h3 className="mt-8 font-display text-lg">{pkg.year} travel dates</h3>
								<ul className="mt-3 flex flex-wrap gap-2">
									{pkg.dates.map((date) => (
										<li key={date} className="rounded-full bg-secondary px-3 py-1.5 font-mono text-xs text-foreground">
											{date}
										</li>
									))}
								</ul>

								<h3 className="mt-8 font-display text-lg">Flight details</h3>
								<ul className="mt-2 space-y-1 font-mono text-sm">
									{pkg.flights.map((flight) => (
										<li key={flight}>{flight}</li>
									))}
								</ul>

								<div className="mt-8 grid gap-6 md:grid-cols-2">
									<div>
										<h3 className="font-display text-lg">Inclusions</h3>
										<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
											{pkg.inclusions.map((item) => (
												<li key={item}>{item}</li>
											))}
										</ul>
									</div>
									<div>
										<h3 className="font-display text-lg">Exclusions</h3>
										<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
											{pkg.exclusions.map((item) => (
												<li key={item}>{item}</li>
											))}
										</ul>
									</div>
								</div>

								<h3 className="mt-8 font-display text-lg">Visa requirements</h3>
								<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm leading-relaxed">
									{pkg.visa.map((item) => (
										<li key={item}>{item}</li>
									))}
								</ul>

								<p className="mt-6 font-body text-sm leading-relaxed">
									<span className="font-semibold">Hotel. </span>
									{pkg.hotel}
								</p>

								<h3 className="mt-8 font-display text-lg">Itinerary</h3>
								<ol className="mt-3 space-y-4">
									{pkg.itinerary.map((day) => (
										<li key={day.day} className="rounded-xl bg-secondary/70 p-4">
											<p className="font-mono text-[11px] tracking-[0.2em] text-primary uppercase">
												{day.day}
												{day.meals ? ` · ${day.meals}` : ''}
											</p>
											<p className="font-display text-lg">{day.title}</p>
											<ul className="mt-2 list-disc space-y-1 pl-5 font-body text-sm">
												{day.stops.map((stop) => (
													<li key={stop}>{stop}</li>
												))}
											</ul>
											{day.note ? <p className="mt-2 font-body text-sm text-muted-foreground">{day.note}</p> : null}
										</li>
									))}
								</ol>

								<h3 className="mt-8 font-display text-lg">Contact</h3>
								<ul className="mt-3 flex flex-wrap gap-3">
									{pkg.contacts.map((contact) => (
										<li key={`${pkg.id}-${contact.value}`}>
											<a
												href={contact.href}
												className="inline-flex min-h-11 items-center gap-2 rounded-full border border-border px-4 font-body text-sm hover:border-primary hover:text-primary"
											>
												{contact.label === 'Mobile' ? <Phone className="h-4 w-4" aria-hidden="true" /> : null}
												{contact.value}
											</a>
										</li>
									))}
								</ul>
							</div>
						</div>
					</article>
				))}
			</main>

			<section className="border-t border-white/10 bg-[hsl(var(--navy))] text-white">
				<div className="mx-auto max-w-3xl px-6 py-16 text-center">
					<h2 className="font-editorial text-4xl md:text-5xl">Your Japan departure starts here</h2>
					<p className="mx-auto mt-4 max-w-xl font-body text-sm leading-relaxed text-white/70">
						Send your preferred date and group size. The Japan desk confirms seats, hotel class, and a written quotation before any deposit.
					</p>
					<ContactTrigger className="mt-8 inline-flex min-h-12 items-center justify-center rounded-full bg-[#f3a000] px-7 font-body text-sm font-semibold text-[hsl(var(--navy))] transition-colors hover:bg-[#ffad0a] active:scale-[0.98]">
						Contact Us
					</ContactTrigger>
				</div>
			</section>
			<Footer />

			{activePoster ? (
				<div
					className="fixed inset-0 z-50 flex items-center justify-center bg-[hsl(var(--navy))]/90 p-4"
					role="dialog"
					aria-modal="true"
					aria-label={activePoster.title}
					onClick={closeLightbox}
				>
					<button
						type="button"
						onClick={closeLightbox}
						className="absolute right-4 top-4 inline-flex min-h-11 min-w-11 items-center justify-center rounded-full bg-white text-[hsl(var(--navy))]"
						aria-label="Close poster"
					>
						<X className="h-5 w-5" aria-hidden="true" />
					</button>
					<img
						src={activePoster.src}
						alt={activePoster.alt}
						className="max-h-[92dvh] w-auto max-w-full object-contain"
						onClick={(event) => event.stopPropagation()}
					/>
				</div>
			) : null}
		</div>
	);
}
