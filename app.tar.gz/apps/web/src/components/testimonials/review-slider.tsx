import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Quote, Star } from 'lucide-react';
import { customerReviews } from '@/data/testimonials';

export function ReviewSlider() {
	const [index, setIndex] = useState(0);
	const [perView, setPerView] = useState(3);

	useEffect(() => {
		const sync = () => {
			if (window.innerWidth < 640) setPerView(1);
			else if (window.innerWidth < 1024) setPerView(2);
			else setPerView(3);
		};
		sync();
		window.addEventListener('resize', sync);
		return () => window.removeEventListener('resize', sync);
	}, []);

	const maxIndex = Math.max(0, customerReviews.length - perView);
	const safeIndex = Math.min(index, maxIndex);
	const visible = customerReviews.slice(safeIndex, safeIndex + perView);
	const pageCount = maxIndex + 1;

	const go = (next: number) => {
		setIndex(Math.min(Math.max(next, 0), maxIndex));
	};

	return (
		<div>
			<div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
				{visible.map((review) => (
					<article
						key={review.id}
						className="relative flex min-h-[280px] flex-col rounded-[22px] border border-[#ece7df] bg-[#fffdfb] px-6 py-6 shadow-[0_10px_30px_rgba(16,36,64,0.05)]"
					>
						<div className="flex items-start justify-between">
							<div className="flex gap-0.5 text-[#f3a000]" aria-label="5 stars">
								{Array.from({ length: 5 }).map((_, star) => (
									<Star key={star} className="h-4 w-4 fill-[#f3a000] text-[#f3a000]" aria-hidden="true" />
								))}
							</div>
							<Quote className="h-7 w-7 text-[#e8d7a4]" strokeWidth={1.6} aria-hidden="true" />
						</div>
						<blockquote className="mt-4 flex-1 font-body text-[15px] leading-relaxed text-[#1e3a5f]">
							“{review.quote}”
						</blockquote>
						<footer className="mt-6 border-t border-[#ece7df] pt-4">
							<p className="font-body text-sm font-bold text-[#16324f]">{review.name}</p>
							<p className="mt-0.5 font-body text-[11px] font-semibold tracking-[0.16em] text-[#8a93a3] uppercase">
								{review.country}
							</p>
						</footer>
					</article>
				))}
			</div>

			<div className="mt-8 flex items-center justify-center gap-4">
				<button
					type="button"
					onClick={() => go(safeIndex - 1)}
					disabled={safeIndex === 0}
					aria-label="Previous reviews"
					className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[#e6e1d8] bg-white text-[#16324f] shadow-sm transition-transform enabled:hover:-translate-y-px enabled:active:scale-[0.98] disabled:opacity-40"
				>
					<ChevronLeft className="h-4 w-4" aria-hidden="true" />
				</button>
				<div className="flex items-center gap-1.5" role="tablist" aria-label="Review pages">
					{Array.from({ length: pageCount }).map((_, page) => (
						<button
							key={page}
							type="button"
							role="tab"
							aria-selected={page === safeIndex}
							aria-label={`Show reviews starting at ${page + 1}`}
							onClick={() => go(page)}
							className={
								page === safeIndex
									? 'h-2 w-7 rounded-full bg-[#f3a000]'
									: 'h-2 w-2 rounded-full bg-[#d9d4cc]'
							}
						/>
					))}
				</div>
				<button
					type="button"
					onClick={() => go(safeIndex + 1)}
					disabled={safeIndex >= maxIndex}
					aria-label="Next reviews"
					className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[#e6e1d8] bg-white text-[#16324f] shadow-sm transition-transform enabled:hover:-translate-y-px enabled:active:scale-[0.98] disabled:opacity-40"
				>
					<ChevronRight className="h-4 w-4" aria-hidden="true" />
				</button>
			</div>
		</div>
	);
}
