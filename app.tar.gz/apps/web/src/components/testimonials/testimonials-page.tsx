import { Link } from 'react-router';
import { ArrowLeft } from 'lucide-react';
import { ContactTrigger } from '@/components/contact/contact-panel';
import { Navbar } from '@/components/home/navbar';
import { Footer } from '@/components/home/footer';
import { ReviewSlider } from '@/components/testimonials/review-slider';

const hero =
	'https://images.hostinger.com/56bf1933-3bfe-4b16-9a17-abe8d37757cc.png';

export function TestimonialsPage() {
	return (
		<div className="bg-background text-foreground">
			<Navbar />
			<header className="relative min-h-[72dvh] overflow-hidden bg-[hsl(var(--navy))] text-white sm:min-h-[78dvh]">
				<img
					src={hero}
					alt=""
					aria-hidden="true"
					width={1600}
					height={900}
					fetchPriority="high"
					className="absolute inset-0 h-full w-full object-cover object-center"
				/>
				<div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(12,28,52,0.55)_0%,rgba(16,36,64,0.42)_38%,rgba(14,32,58,0.72)_100%)]" />
				<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,rgba(8,20,40,0.35)_70%)]" />

				<div className="relative mx-auto flex min-h-[72dvh] max-w-[1320px] flex-col px-4 pt-[92px] sm:min-h-[78dvh] sm:px-8 lg:px-10">
					<Link
						to="/"
						className="inline-flex min-h-11 w-fit items-center gap-2 rounded-full bg-white px-4 py-2 font-body text-[11px] font-semibold tracking-[0.16em] text-[hsl(var(--navy))] uppercase shadow-sm transition-transform hover:-translate-y-px active:scale-[0.98]"
					>
						<ArrowLeft className="h-3.5 w-3.5 text-[#f3a000]" aria-hidden="true" />
						Back Home
					</Link>

					<div className="flex flex-1 flex-col items-center justify-center px-2 pb-16 text-center">
						<p className="font-body text-[11px] font-semibold tracking-[0.42em] text-[#f3a000] uppercase">
							Customer comments
						</p>
						<h1 className="mt-5 max-w-4xl font-editorial text-5xl font-medium leading-[1.05] text-white sm:text-6xl md:text-7xl">
							What Our Travelers Say
						</h1>
						<p className="mt-5 max-w-xl font-body text-sm leading-relaxed text-white/85 sm:text-base">
							Comments from travelers who joined Airmark tours, shown under the names they left with their reviews.
						</p>
					</div>
				</div>
			</header>

			<main>
				<section className="bg-[#f7f6f4]" aria-labelledby="reviews-heading">
					<div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
						<div className="mb-10 text-center">
							<p className="font-body text-[11px] font-semibold tracking-[0.32em] text-[#f3a000] uppercase">
								Our customers
							</p>
							<h2 id="reviews-heading" className="mt-3 font-editorial text-3xl text-[hsl(var(--navy))] md:text-4xl">
								Five-star notes from the desk
							</h2>
						</div>
						<ReviewSlider />
					</div>
				</section>

				<section className="border-t border-border bg-white">
					<div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-6 py-10 sm:flex-row sm:items-center lg:px-8">
						<div>
							<p className="font-mono text-[11px] tracking-[0.28em] text-primary uppercase">Plan your own departure</p>
							<p className="mt-2 max-w-xl font-editorial text-2xl text-[hsl(var(--navy))] md:text-3xl">
								Tell the desk where you want to go.
							</p>
						</div>
						<ContactTrigger className="inline-flex min-h-11 items-center justify-center rounded-full bg-[#f3a000] px-6 font-body text-sm font-semibold text-white transition-colors hover:bg-[#ffad0a] active:scale-[0.98]">
							Contact Us
						</ContactTrigger>
					</div>
				</section>
			</main>
			<Footer />
		</div>
	);
}
