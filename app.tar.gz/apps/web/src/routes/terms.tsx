import type { Route } from './+types/terms';
import { seo } from '@/lib/seo';
import { PolicyPage } from '@/components/legal/policy-page';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo(
		{ matches, location },
		{
			title: 'Terms of Service — Airmark Tour and Dev’t Inc.',
			description:
				'Terms for inquiries, quotations, and travel arrangements with Airmark Tour and Dev’t Inc.',
		},
	);
}

export default function Terms() {
	return (
		<PolicyPage
			title="Terms of Service"
			intro="These terms apply to travel inquiries and arrangements made with Airmark Tour and Dev’t Inc., engineering extraordinary travel experiences since 2014."
			sections={[
				{
					heading: 'Quotations',
					body: 'Package prices and inclusions are confirmed in writing by the assigned specialist. A quotation is not a confirmed booking until deposits and passenger details are accepted.',
				},
				{
					heading: 'Bookings',
					body: 'Airline, hotel, and visa rules of the supplier apply once a reservation is ticketed. Changes and cancellations follow those supplier policies plus any service fee stated in your confirmation.',
				},
				{
					heading: 'Your responsibilities',
					body: 'Travelers are responsible for valid passports, visas, and accurate passenger names matching travel documents.',
				},
			]}
		/>
	);
}
