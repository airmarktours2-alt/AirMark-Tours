import type { Route } from './+types/privacy';
import { seo } from '@/lib/seo';
import { PolicyPage } from '@/components/legal/policy-page';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo(
		{ matches, location },
		{
			title: 'Privacy Policy — Airmark Tour and Dev’t Inc.',
			description:
				'How Airmark Tour and Dev’t Inc. collects, uses, and protects personal information shared through inquiries and bookings.',
		},
	);
}

export default function Privacy() {
	return (
		<PolicyPage
			title="Privacy Policy"
			intro="Airmark Tour and Dev’t Inc. respects the privacy of travelers, partners, and visitors who share information with our Makati office and sales team."
			sections={[
				{
					heading: 'Information we collect',
					body: 'When you inquire about a package, we may collect your name, contact number, email address, travel dates, and destination preferences so the assigned specialist can respond.',
				},
				{
					heading: 'How we use it',
					body: 'Details are used to prepare quotations, confirm bookings, and follow up on the destinations listed for each specialist — Korea, Japan, Europe, Thailand, China, Indonesia, Hong Kong, Singapore, Vietnam, Taiwan, Dubai, cruises, and domestic packages.',
				},
				{
					heading: 'Sharing',
					body: 'We share traveler details only with airlines, hotels, and ground operators needed to deliver the trip you requested. We do not sell personal information.',
				},
				{
					heading: 'Contact',
					body: 'Privacy questions can be sent to the specialist handling your destination, or to the Makati office at Unit 407, SEDCCO I Building, 120 Rada Street, Legaspi Village, Makati City.',
				},
			]}
		/>
	);
}
