import type { Route } from './+types/cookies';
import { seo } from '@/lib/seo';
import { PolicyPage } from '@/components/legal/policy-page';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo(
		{ matches, location },
		{
			title: 'Cookie Policy — Airmark Tour and Dev’t Inc.',
			description: 'How this Airmark Tours website uses cookies and similar technologies.',
		},
	);
}

export default function Cookies() {
	return (
		<PolicyPage
			title="Cookie Policy"
			intro="This site uses a small set of cookies so pages load correctly and the language selector can remember a choice."
			sections={[
				{
					heading: 'Essential cookies',
					body: 'These keep the site working, including session and security cookies required to serve pages.',
				},
				{
					heading: 'Language',
					body: 'The Google Translate selector may store a language preference in your browser so the page stays in the language you chose.',
				},
				{
					heading: 'Managing cookies',
					body: 'You can clear or block cookies in your browser settings. Blocking essential cookies may stop parts of the site from loading.',
				},
			]}
		/>
	);
}
