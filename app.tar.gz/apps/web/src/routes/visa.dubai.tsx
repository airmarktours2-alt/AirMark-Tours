import type { Route } from './+types/visa.dubai';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { DubaiVisaPage } from '@/components/visa/dubai-visa-page';
import { dubaiVisaHero } from '@/data/dubai-visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Dubai Visa Questionnaire — Airmark',
			description:
				'Dubai visa requirements, inclusions, and terms for Filipino applicants, plus the Airmark questionnaire. Confirm documents and timing with consultants before you apply.',
			image: dubaiVisaHero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Visa', item: absoluteUrl(origin, '/visa') },
					{ '@type': 'ListItem', position: 3, name: 'Dubai Visa Questionnaire', item: url },
				],
			},
		},
	);
}

export default function DubaiVisaRoute() {
	return <DubaiVisaPage />;
}
