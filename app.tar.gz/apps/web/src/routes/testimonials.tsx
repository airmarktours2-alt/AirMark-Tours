import type { Route } from './+types/testimonials';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { TestimonialsPage } from '@/components/testimonials/testimonials-page';

const hero = 'https://images.hostinger.com/56bf1933-3bfe-4b16-9a17-abe8d37757cc.png';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'What Our Travelers Say — Airmark Tours',
			description:
				'Customer comments from Airmark Tours travelers, including Ms. Lei, Ms. Miriam, Mr. Sojordane, and other guests who shared their trip notes.',
			image: hero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Testimonials', item: url },
				],
			},
		},
	);
}

export default function TestimonialsRoute() {
	return <TestimonialsPage />;
}
