import type { Route } from './+types/taiwan';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { TaiwanPage } from '@/components/taiwan/taiwan-page';
import { taiwanHero, taiwanPackages } from '@/data/taiwan';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Taiwan Tour Packages — Airmark Tours',
			description:
				'Airmark Taiwan packages on EVA Air: Love in Taiwan from $620 per person and Christmas Adventure in Taiwan from $610, with printed dates, flights, hotels, and day plans.',
			image: taiwanHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark Taiwan tour packages',
					url,
					itemListElement: taiwanPackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Taiwan', item: url },
					],
				},
			],
		},
	);
}

export default function TaiwanRoute() {
	return <TaiwanPage />;
}
