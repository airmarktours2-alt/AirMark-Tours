import type { Route } from './+types/visa.us';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { UsVisaPage } from '@/components/visa/us-visa-page';
import { usVisaHero } from '@/data/us-visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'US Visa Requirements — Airmark',
			description:
				'US B1/B2 visa assistance for Filipino applicants: new and renewal rates, inclusions, document checklist, and fee notes. Confirm the current total with Airmark.',
			image: usVisaHero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Visa', item: absoluteUrl(origin, '/visa') },
					{ '@type': 'ListItem', position: 3, name: 'US Visa Requirements', item: url },
				],
			},
		},
	);
}

export default function UsVisaRoute() {
	return <UsVisaPage />;
}
