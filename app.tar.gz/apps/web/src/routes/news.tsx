import type { Route } from './+types/news';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { NewsPage } from '@/components/news/news-page';

const hero = 'https://images.hostinger.com/ab498fe5-998f-412a-9449-0614e4861046.png';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Travel News — Airmark Tours',
			description:
				'Ongoing Airmark desk briefings: Aero K weekly schedules, fuel surcharge notes, and travel industry headlines for Korea and Asia departures.',
			image: hero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'News', item: url },
				],
			},
		},
	);
}

export default function NewsRoute() {
	return <NewsPage />;
}
