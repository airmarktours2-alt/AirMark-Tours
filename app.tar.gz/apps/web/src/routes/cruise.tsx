import type { Route } from './+types/cruise';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { CruisePage } from '@/components/cruise/cruise-page';
import { cruiseHero, cruisePackages } from '@/data/cruise';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Cruise Packages — Airmark Tours',
			description:
				'Airmark cruise flyers: Costa Serena from Kaohsiung, a Keelung sailing from $260, and Disney Adventure from Singapore with printed fares and dates.',
			image: cruiseHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark cruise packages',
					url,
					itemListElement: cruisePackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Cruise', item: url },
					],
				},
			],
		},
	);
}

export default function CruiseRoute() {
	return <CruisePage />;
}
