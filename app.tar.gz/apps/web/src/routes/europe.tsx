import type { Route } from './+types/europe';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { EuropePage } from '@/components/europe/europe-page';
import { europeHero, europePackages } from '@/data/europe';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Europe Tour Packages — Airmark Tours',
			description:
				'Airmark Europe flyers from USD 1,198, including UK and Ireland, Switzerland, Iceland and the Baltics, Greece and Türkiye, the Balkans, and a Holy Land circuit. Each card keeps the fare, dates, and day plan printed on the flyer.',
			image: europeHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark Europe tour packages',
					url,
					itemListElement: europePackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Europe', item: url },
					],
				},
			],
		},
	);
}

export default function EuropeRoute() {
	return <EuropePage />;
}
