import type { Route } from './+types/vietnam';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { VietnamPage } from '@/components/vietnam/vietnam-page';
import { vietnamPackages } from '@/data/vietnam';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Vietnam Tour Packages — Airmark Tours',
			description:
				'Airmark Vietnam Premium Escape from ₱37,888: Hanoi, Sapa, Cat Cat Village, and Fansipan with Vietnam Airlines, hotels, transfers, and a day-by-day itinerary.',
			image: 'https://images.hostinger.com/7b7110de-c33a-4cad-b904-c43d0f8733ba.png',
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark Vietnam tour packages',
					url,
					itemListElement: vietnamPackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} per person · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Vietnam', item: url },
					],
				},
			],
		},
	);
}

export default function VietnamRoute() {
	return <VietnamPage />;
}
