import type { Route } from './+types/hong-kong';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { HongKongPage } from '@/components/hong-kong/hong-kong-page';
import { hongKongHero, hongKongPackages } from '@/data/hong-kong';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Hong Kong Tour Packages — Airmark Tours',
			description:
				'Airmark Hong Kong flyers from $488 per person: Shop & Play at Nina Hotel Tsuen Wan West, and Hong Kong & Macau 2026 with Cebu Pacific, dates, and day plans.',
			image: hongKongHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark Hong Kong tour packages',
					url,
					itemListElement: hongKongPackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Hong Kong', item: url },
					],
				},
			],
		},
	);
}

export default function HongKongRoute() {
	return <HongKongPage />;
}
