import type { Route } from './+types/faq';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { FaqPage } from '@/components/faq/faq-page';
import { faqHero, faqSections } from '@/data/faq';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'FAQ — Airmark Tours',
			description:
				'Answers on booking a tour with Airmark, deposits and payments, visa assistance, and what tour packages include. Confirm final terms with the Airmark desk.',
			image: faqHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'FAQPage',
					mainEntity: faqSections.flatMap((section) =>
						section.items.map((item) => ({
							'@type': 'Question',
							name: item.question,
							acceptedAnswer: { '@type': 'Answer', text: item.answer },
						})),
					),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'FAQ', item: url },
					],
				},
			],
		},
	);
}

export default function FaqRoute() {
	return <FaqPage />;
}
