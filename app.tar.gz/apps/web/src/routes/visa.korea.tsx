import type { Route } from './+types/visa.korea';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { KoreaVisaPage } from '@/components/visa/korea-visa-page';
import { koreaVisaHero } from '@/data/korea-visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Korea Visa Requirements — Airmark',
			description:
				'Korea Group E-Visa checklist: tour operator papers, company documents, the tour leader file, and what the rest of the group must prepare.',
			image: koreaVisaHero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Visa', item: absoluteUrl(origin, '/visa') },
					{ '@type': 'ListItem', position: 3, name: 'Korea Visa Requirements', item: url },
				],
			},
		},
	);
}

export default function KoreaVisaRoute() {
	return <KoreaVisaPage />;
}
