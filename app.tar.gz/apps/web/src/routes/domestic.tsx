import type { Route } from './+types/domestic';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { DomesticFlightsPage } from '@/components/domestic/domestic-flights-page';
import { domesticHero } from '@/data/domestic-flights';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Domestic Flights — Airmark Tours',
			description:
				'Request domestic flights across the Philippines. Share your route, dates, and passengers — Airmark searches island fares and sends options. A request is not a confirmed booking.',
			image: domesticHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Domestic Flights', item: url },
					],
				},
			],
		},
	);
}

export default function DomesticRoute() {
	return <DomesticFlightsPage />;
}
