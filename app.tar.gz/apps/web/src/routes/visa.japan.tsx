import type { Route } from './+types/visa.japan';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { JapanVisaPage } from '@/components/visa/japan-visa-page';
import { japanVisaHero } from '@/data/japan-visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Japan Visa Requirements — Airmark',
			description:
				'Japan multiple-entry visa checklist for tourism, business, or visiting relatives: common documents and the four listed conditions. Confirm the current list with Airmark.',
			image: japanVisaHero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Visa', item: absoluteUrl(origin, '/visa') },
					{ '@type': 'ListItem', position: 3, name: 'Japan Visa Requirements', item: url },
				],
			},
		},
	);
}

export default function JapanVisaRoute() {
	return <JapanVisaPage />;
}
