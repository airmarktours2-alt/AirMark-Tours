import type { Route } from './+types/contact';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { ContactPage } from '@/components/contact/contact-page';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Contact Us — Airmark Tours',
			description:
				'Reach Airmark Tour and Dev\'t Inc. at the Makati office. Desk contacts for Korea, Japan, China, Europe, Vietnam, Taiwan, cruise, and domestic packages.',
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'TravelAgency',
					name: "Airmark Tour and Dev't Inc.",
					url,
					address: {
						'@type': 'PostalAddress',
						streetAddress: 'Unit 407, SEDCCO I Building, 120 Rada Street, Legaspi Village',
						addressLocality: 'Makati City',
						addressCountry: 'PH',
					},
					telephone: '+639171006026',
					email: 'salescha.airmark@gmail.com',
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Contact Us', item: url },
					],
				},
			],
		},
	);
}

export default function ContactRoute() {
	return <ContactPage />;
}
