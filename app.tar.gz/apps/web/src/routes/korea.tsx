import type { Route } from './+types/korea';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { KoreaPage } from '@/components/korea/korea-page';
import { koreaPackages } from '@/data/korea-packages';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'South Korea Tour Packages — Airmark Tours',
			description:
				'Airmark Korea packages from ₱34,199: Korean Air, Cebu Pacific, Aero K, and Jeju Air departures with 2026 dates, inclusions, hotels, and day-by-day itineraries.',
			image: 'https://images.hostinger.com/d2d19f87-fbd9-4f48-ba0f-ac425b9b8044.png',
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'ItemList',
				name: 'Airmark South Korea tour packages',
				url,
				itemListElement: koreaPackages.map((pkg, index) => ({
					'@type': 'ListItem',
					position: index + 1,
					name: pkg.title,
					description: `${pkg.price} ${pkg.priceNote} via ${pkg.airline}`,
				})),
			},
		},
	);
}

export default function KoreaRoute() {
	return <KoreaPage />;
}
