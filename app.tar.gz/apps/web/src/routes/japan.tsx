import type { Route } from './+types/japan';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { JapanPage } from '@/components/japan/japan-page';
import { japanPackages } from '@/data/japan';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Japan Tour Packages — Airmark Tours',
			description:
				'Eight Airmark Japan packages from USD 1,438: Osaka–Tokyo, Fukuoka–Hiroshima, Nagoya, cherry blossom 2027, autumn and summer Tokyo, New Year’s Eve, and Hokkaido, with flights, hotels, and day-by-day itineraries.',
			image: 'https://images.hostinger.com/2a41367d-41b6-4f5c-86eb-6d5a62723b5f.png',
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark Japan tour packages',
					url,
					itemListElement: japanPackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} per person · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Japan', item: url },
					],
				},
			],
		},
	);
}

export default function JapanRoute() {
	return <JapanPage />;
}
