import type { Route } from './+types/flights';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { FlightsPage } from '@/components/flights/flights-page';
import { flightHero } from '@/data/flights';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'International Flights — Airmark Tours',
			description:
				'Request international flights from Manila. Share your route, dates, and passengers — Airmark searches fares and sends options. A request is not a confirmed booking.',
			image: flightHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'International Flights', item: url },
					],
				},
			],
		},
	);
}

export default function FlightsRoute() {
	return <FlightsPage />;
}
