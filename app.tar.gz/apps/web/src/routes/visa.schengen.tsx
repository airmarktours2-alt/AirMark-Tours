import type { Route } from './+types/visa.schengen';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { SchengenVisaPage } from '@/components/visa/schengen-visa-page';
import { schengenVisaHero } from '@/data/schengen-visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Schengen Visa Requirements — Airmark',
			description:
				'Schengen visa checklist for Filipino applicants: 29 countries, document list, minor applicants, and timing notes. Confirm the current requirements with Airmark.',
			image: schengenVisaHero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Visa', item: absoluteUrl(origin, '/visa') },
					{ '@type': 'ListItem', position: 3, name: 'Schengen Visa Requirements', item: url },
				],
			},
		},
	);
}

export default function SchengenVisaRoute() {
	return <SchengenVisaPage />;
}
