import type { Route } from './+types/china';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { ChinaPage } from '@/components/china/china-page';
import { chinaPackages } from '@/data/china';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'China Tour Packages — Airmark Tours',
			description:
				'Ten Airmark China packages from USD 399: Zhangjiajie Avatar, Harbin ski, Beijing–Shanghai, Disneyland, Chengdu pandas, and Xi’an, with flights, hotels, and day-by-day itineraries.',
			image: 'https://images.hostinger.com/ff15c007-b0db-469a-81ed-378a7302793a.png',
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark China tour packages',
					url,
					itemListElement: chinaPackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} per person · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'China', item: url },
					],
				},
			],
		},
	);
}

export default function ChinaRoute() {
	return <ChinaPage />;
}
