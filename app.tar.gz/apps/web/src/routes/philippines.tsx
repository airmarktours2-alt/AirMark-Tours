import type { Route } from './+types/philippines';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { PhilippinesPage } from '@/components/philippines/philippines-page';
import { philippinesHero, philippinesPackages } from '@/data/philippines';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Philippines Tour Packages — Airmark Tours',
			description:
				'Airmark Philippines island packages, including the 4D3N Coron departure from Php 22,998 per person on Cebu Pacific, with Tag Resort Coron, island tours, and the printed flyer details.',
			image: philippinesHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'ItemList',
					name: 'Airmark Philippines tour packages',
					url,
					itemListElement: philippinesPackages.map((pkg, index) => ({
						'@type': 'ListItem',
						position: index + 1,
						name: pkg.title,
						description: `${pkg.tagline}. ${pkg.price} · ${pkg.days} · ${pkg.region}`,
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Philippines', item: url },
					],
				},
			],
		},
	);
}

export default function PhilippinesRoute() {
	return <PhilippinesPage />;
}
