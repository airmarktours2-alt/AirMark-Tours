import type { Route } from './+types/visa';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { VisaPage } from '@/components/visa/visa-page';
import { visaFaqs, visaHero } from '@/data/visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Visa Assistance — Airmark Tours',
			description:
				'Starting visa assistance rates for Korea, China, Dubai, the US, Japan, and Schengen. Confirm documents, timing, and the final fee with Airmark before you apply.',
			image: visaHero,
			jsonLd: [
				{
					'@context': 'https://schema.org',
					'@type': 'FAQPage',
					mainEntity: visaFaqs.map((item) => ({
						'@type': 'Question',
						name: item.question,
						acceptedAnswer: { '@type': 'Answer', text: item.answer },
					})),
				},
				{
					'@context': 'https://schema.org',
					'@type': 'BreadcrumbList',
					itemListElement: [
						{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
						{ '@type': 'ListItem', position: 2, name: 'Visa', item: url },
					],
				},
			],
		},
	);
}

export default function VisaRoute() {
	return <VisaPage />;
}
