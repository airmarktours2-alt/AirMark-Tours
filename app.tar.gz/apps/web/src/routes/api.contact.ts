import { apiError, json, readJsonBody, withApi } from '@/lib/api.server';
import { pocketbaseAdmin } from '@/lib/pocketbase-client.server';
import logger from '@/lib/logger.server';

type ContactPayload = {
	name?: unknown;
	email?: unknown;
	phone?: unknown;
	message?: unknown;
};

const asString = (value: unknown): string =>
	typeof value === 'string' ? value.trim() : '';

export const action = withApi(async ({ request }) => {
	if (request.method !== 'POST') {
		return apiError(405, 'Method not allowed');
	}

	const body = await readJsonBody<ContactPayload>(request);
	const name = asString(body.name);
	const email = asString(body.email);
	const phone = asString(body.phone);
	const message = asString(body.message);

	if (!name || !email || !phone || !message) {
		return apiError(422, 'Please fill in your name, email, phone, and message.');
	}
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
		return apiError(422, 'Enter a valid email address.');
	}
	if (name.length > 200 || phone.length > 60 || message.length > 5000) {
		return apiError(422, 'One of the fields is too long. Please shorten it and try again.');
	}

	try {
		await pocketbaseAdmin.createRecord('contact_messages', { name, email, phone, message });
	} catch (error) {
		logger.error(
			'contact message save failed',
			error instanceof Error ? error.stack : String(error),
		);
		return apiError(
			500,
			'We could not send your message right now. Please try again or email us directly.',
		);
	}

	return json({ ok: true });
});
