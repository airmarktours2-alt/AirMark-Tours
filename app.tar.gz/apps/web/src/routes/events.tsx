import type { Route } from './+types/events';
import { seo, siteOriginFrom, absoluteUrl } from '@/lib/seo';
import { EventsPage } from '@/components/events/events-page';

const hero =
	'https://horizons-cdn.hostinger.com/42b40b61-fab7-4055-8153-d9d58f7aec0e/7ea2c21ebfcd37f1e7d924fbae513788.png';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'Upcoming Events — Airmark Tours',
			description:
				'Airmark Korea events: JIMFF on September 4–5, 2026, Grace in Korea pilgrimage from ₱46,699, and Run Korea Run on October 7–11, 2026 from ₱48,888.',
			image: hero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Events', item: url },
				],
			},
		},
	);
}

export default function EventsRoute() {
	return <EventsPage />;
}
