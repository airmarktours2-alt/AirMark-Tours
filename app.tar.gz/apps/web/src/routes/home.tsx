import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { Navbar } from '@/components/home/navbar';
import { Hero } from '@/components/home/hero';
import { Destinations } from '@/components/home/destinations';
import { Services } from '@/components/home/services';
import { About } from '@/components/home/about';
import { Contact } from '@/components/home/contact';
import { Footer } from '@/components/home/footer';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Airmark Tours — Your Passport to Possibilities',
		description:
			'Airmark Tour and Dev\'t Inc. — world-class destinations with precision-crafted itineraries. Flights, hotels, visa assistance, and customized tours across Asia and Europe since 2016.',
	});
}

export default function HomePage() {
	return (
		<div className="min-h-screen bg-background">
			<Navbar />
			<Hero />
			<Destinations />
			<Services />
			<About />
			<Contact />
			<Footer />
		</div>
	);
}
