import type { Route } from './+types/about';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { AboutPage } from '@/components/about/about-page';
import { palaceBackdrop } from '@/data/about';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'About Us — Airmark Tours',
			description:
				'Airmark Tour & Dev\'t, Inc. and Airmark Aviation Services — DOT-accredited travel, Korea and Japan tours, visa assistance, and GSA airline representation from Makati.',
			image: palaceBackdrop,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'About Us', item: url },
				],
			},
		},
	);
}

export default function AboutRoute() {
	return <AboutPage />;
}
