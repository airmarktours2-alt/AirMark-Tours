import type { Route } from './+types/visa.china';
import { absoluteUrl, seo, siteOriginFrom } from '@/lib/seo';
import { ChinaVisaPage } from '@/components/visa/china-visa-page';
import { chinaVisaHero } from '@/data/china-visa';

export function meta({ matches, location }: Route.MetaArgs) {
	const origin = siteOriginFrom(matches);
	const url = absoluteUrl(origin, location.pathname);

	return seo(
		{ matches, location },
		{
			title: 'China Visa Requirements — Airmark',
			description:
				'China visa checklist for Filipino applicants: basic documents for every file, plus first-time and re-application requirements. Confirm the current list with Airmark.',
			image: chinaVisaHero,
			jsonLd: {
				'@context': 'https://schema.org',
				'@type': 'BreadcrumbList',
				itemListElement: [
					{ '@type': 'ListItem', position: 1, name: 'Home', item: absoluteUrl(origin, '/') },
					{ '@type': 'ListItem', position: 2, name: 'Visa', item: absoluteUrl(origin, '/visa') },
					{ '@type': 'ListItem', position: 3, name: 'China Visa Requirements', item: url },
				],
			},
		},
	);
}

export default function ChinaVisaRoute() {
	return <ChinaVisaPage />;
}
