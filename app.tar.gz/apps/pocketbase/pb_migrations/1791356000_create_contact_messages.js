/// <reference path="../pb_data/types.d.ts" />

migrate(
	(app) => {
		let collection;
		try {
			collection = app.findCollectionByNameOrId('contact_messages');
		} catch (_) {
			collection = new Collection({
				type: 'base',
				name: 'contact_messages',
				// Public create (anonymous visitors submit the contact form);
				// reads/updates/deletes are superuser-only so submissions stay private.
				listRule: null,
				viewRule: null,
				createRule: '',
				updateRule: null,
				deleteRule: null,
				fields: [
					{ name: 'name', type: 'text', required: true, max: 200 },
					{ name: 'email', type: 'email', required: true },
					{ name: 'phone', type: 'text', required: true, max: 60 },
					{ name: 'message', type: 'text', required: true, max: 5000 },
					{ name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
					{ name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
				],
			});
			app.save(collection);
		}
	},
	(app) => {
		try {
			const collection = app.findCollectionByNameOrId('contact_messages');
			app.delete(collection);
		} catch (e) {
			if (e.message.includes('no rows in result set')) {
				return;
			}
			throw e;
		}
	},
);
