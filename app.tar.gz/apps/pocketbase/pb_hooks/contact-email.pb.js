/// <reference path="../pb_data/types.d.ts" />

onRecordAfterCreateSuccess((e) => {
	const escapeHtml = (str) =>
		String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');

	const name = e.record.get('name') || '';
	const email = e.record.get('email') || '';
	const phone = e.record.get('phone') || '';
	const message = e.record.get('message') || '';

	const html =
		'<h2 style="margin:0 0 16px;color:#0a192f;">New contact form message</h2>' +
		'<p style="margin:0 0 8px;"><strong>Name:</strong> ' +
		escapeHtml(name) +
		'</p>' +
		'<p style="margin:0 0 8px;"><strong>Email:</strong> <a href="mailto:' +
		escapeHtml(email) +
		'">' +
		escapeHtml(email) +
		'</a></p>' +
		'<p style="margin:0 0 8px;"><strong>Phone:</strong> ' +
		escapeHtml(phone) +
		'</p>' +
		'<p style="margin:16px 0 8px;"><strong>Message:</strong></p>' +
		'<div style="white-space:pre-wrap;border-left:3px solid #f3a000;padding:8px 14px;color:#3d4758;">' +
		escapeHtml(message) +
		'</div>';

	const text =
		'New contact form message\n\n' +
		'Name: ' +
		name +
		'\n' +
		'Email: ' +
		email +
		'\n' +
		'Phone: ' +
		phone +
		'\n\n' +
		'Message:\n' +
		message;

	const mailMessage = new MailerMessage({
		from: { name: 'Airmark Tours Website' },
		to: [{ address: 'airmarktours2@gmail.com' }],
		replyTo: { address: email },
		subject: 'New website enquiry — ' + (name || 'Visitor'),
		html: html,
		text: text,
	});

	try {
		$app.newMailClient().send(mailMessage);
	} catch (err) {
		$app.logger().error('contact email failed', 'from', email, 'err', String(err));
	}

	e.next();
}, 'contact_messages');
